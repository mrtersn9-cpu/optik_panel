<?php
/**
 * ExamService
 * Sınav iş mantığı - sonuç hesaplama, analiz
 */

declare(strict_types=1);

class ExamService
{
    private PDO $pdo;

    public function __construct(PDO $pdo)
    {
        $this->pdo = $pdo;
    }

    /**
     * QR'dan sınav ID'sini decode et
     */
    public function decodeExamId(int $encodedId): int
    {
        return (int)($encodedId / 12345);
    }

    /**
     * Sınavı ID ile getir
     */
    public function getExam(int $examId): ?array
    {
        if ($examId <= 0) {
            return null;
        }

        $stmt = $this->pdo->prepare("SELECT * FROM exams WHERE id = ?");
        $stmt->execute([$examId]);
        $exam = $stmt->fetch();

        return $exam ?: null;
    }

    /**
     * Sınava ait branşları getir
     */
    public function getBranches(int $examId): array
    {
        $stmt = $this->pdo->prepare(
            "SELECT * FROM exam_branches WHERE exam_id = ? ORDER BY id ASC"
        );
        $stmt->execute([$examId]);
        return $stmt->fetchAll();
    }

    /**
     * Sınava ait kitapçıkları getir
     */
    public function getBooklets(int $examId): array
    {
        $stmt = $this->pdo->prepare(
            "SELECT * FROM exam_booklets WHERE exam_id = ? ORDER BY id ASC"
        );
        $stmt->execute([$examId]);
        return $stmt->fetchAll();
    }

    /**
     * Video çözümleri getir
     */
    public function getVideoSolutions(int $examId, string $baseUrl): array
    {
        $videos = [];
        
        try {
            $stmt = $this->pdo->prepare(
                "SELECT branch_id, question_no, video_path, video_link 
                 FROM exam_question_videos 
                 WHERE exam_id = ?"
            );
            $stmt->execute([$examId]);
            
            while ($v = $stmt->fetch()) {
                $bId = (int)$v['branch_id'];
                $qNo = (int)$v['question_no'];
                
                if ($bId <= 0 || $qNo <= 0) {
                    continue;
                }
                
                // Öncelik: video_link (Google Drive vb.)
                $videoLink = trim((string)($v['video_link'] ?? ''));
                if (!empty($videoLink)) {
                    $videos[$bId][$qNo] = $videoLink;
                    continue;
                }
                
                // İkinci öncelik: video_path (yüklenmiş dosya)
                $videoPath = trim((string)($v['video_path'] ?? ''));
                if (!empty($videoPath)) {
                    // Absolute URL kontrolü
                    if (strpos($videoPath, 'http://') === 0 || strpos($videoPath, 'https://') === 0) {
                        $videos[$bId][$qNo] = $videoPath;
                    } else {
                        // Relative path - optik_panel/uploads/ altında
                        $videoPath = ltrim($videoPath, '/');
                        
                        // Eğer zaten optik_panel ile başlıyorsa
                        if (strpos($videoPath, 'optik_panel/') === 0) {
                            $videos[$bId][$qNo] = rtrim($baseUrl, '/') . '/' . $videoPath;
                        } else {
                            // optik_panel/uploads/ ekle
                            $videos[$bId][$qNo] = rtrim($baseUrl, '/') . '/optik_panel/' . $videoPath;
                        }
                    }
                }
            }
        } catch (Exception $e) {
            // Tablo yoksa boş array dön
        }
        
        return $videos;
    }

    /**
     * Kazanımları getir
     */
    public function getOutcomes(int $examId): array
    {
        $stmt = $this->pdo->prepare("
            SELECT eo.*, eb.name AS branch_name
            FROM exam_outcomes eo
            JOIN exam_branches eb ON eo.branch_id = eb.id
            WHERE eo.exam_id = ?
        ");
        $stmt->execute([$examId]);
        return $stmt->fetchAll();
    }

    /**
     * Cevap anahtarı ve kazanım eşlemesi
     */
    public function prepareAnswerKeyAndOutcomes(
        int $examId, 
        array $booklets, 
        array $outcomes
    ): array {
        $answerKey = [];
        $outcomeByQuestion = [];

        if (empty($booklets) || empty($outcomes)) {
            return [$answerKey, $outcomeByQuestion];
        }

        $outcomeIds = array_column($outcomes, 'id');
        if (empty($outcomeIds)) {
            return [$answerKey, $outcomeByQuestion];
        }

        $inQuery = implode(',', array_fill(0, count($outcomeIds), '?'));
        $params  = array_merge([$examId], $outcomeIds);

        $sql = "
            SELECT m.*, b.code AS booklet_code, eo.branch_id, eo.id AS outcome_id
            FROM exam_outcome_booklet_map m
            JOIN exam_booklets b ON m.booklet_id = b.id
            JOIN exam_outcomes eo ON m.outcome_id = eo.id
            WHERE eo.exam_id = ? AND m.outcome_id IN ($inQuery)
        ";
        
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        
        while ($row = $stmt->fetch()) {
            $code     = $row['booklet_code'];
            $branchId = (int)$row['branch_id'];
            $qno      = (int)$row['question_no'];
            $ans      = strtoupper(trim((string)$row['answer_option']));

            if (!in_array($ans, ['A','B','C','D','E'], true)) {
                continue;
            }

            if (!isset($answerKey[$code])) {
                $answerKey[$code] = [];
            }
            if (!isset($answerKey[$code][$branchId])) {
                $answerKey[$code][$branchId] = [];
            }
            $answerKey[$code][$branchId][$qno] = $ans;

            if (!isset($outcomeByQuestion[$code])) {
                $outcomeByQuestion[$code] = [];
            }
            if (!isset($outcomeByQuestion[$code][$branchId])) {
                $outcomeByQuestion[$code][$branchId] = [];
            }
            if (!isset($outcomeByQuestion[$code][$branchId][$qno])) {
                $outcomeByQuestion[$code][$branchId][$qno] = [];
            }
            $outcomeByQuestion[$code][$branchId][$qno][] = (int)$row['outcome_id'];
        }

        return [$answerKey, $outcomeByQuestion];
    }

    /**
     * Net hesaplama
     */
    public function calculateNet(
        int $correct, 
        int $wrong, 
        int $useNegativeScoring, 
        int $wrongPerMinus
    ): float {
        if (!$useNegativeScoring) {
            return (float)$correct;
        }
        
        $den = max(1, $wrongPerMinus);
        return (float)$correct - ((float)$wrong / $den);
    }

    /**
     * Sınav sonucunu hesapla
     */
    public function calculateResults(
        array $exam,
        array $branches,
        array $postData,
        string $bookletCode,
        array $answerKey,
        array $outcomeByQuestion,
        array $outcomeInfo
    ): array {
        $useNegativeScoring = isset($exam['use_negative_scoring']) 
            ? (int)$exam['use_negative_scoring'] : 1;
        $wrongPerMinus = isset($exam['wrong_per_minus']) && (int)$exam['wrong_per_minus'] > 0
            ? (int)$exam['wrong_per_minus'] : 4;

        $totalCorrect = 0;
        $totalWrong   = 0;
        $totalBlank   = 0;

        // Branş bazlı
        $branchStats = [];
        foreach ($branches as $br) {
            $branchStats[$br['id']] = [
                'name'    => $br['name'],
                'correct' => 0,
                'wrong'   => 0,
                'blank'   => 0,
            ];
        }

        // Kazanım bazlı
        $outcomeStats = [];
        foreach ($outcomeInfo as $oid => $info) {
            $outcomeStats[$oid] = [
                'name'       => $info['outcome_name'],
                'code'       => $info['outcome_code'],
                'branch_id'  => $info['branch_id'],
                'alt_branch' => $info['alt_branch_name'] ?? '',
                'correct'    => 0,
                'wrong'      => 0,
                'blank'      => 0,
                'questions'  => [], // Soru numaralarını saklamak için
            ];
        }

        $anyAnswered    = false;
        $questionReview = [];
        $answersMap     = [];

        // Her branşı gez
        foreach ($branches as $br) {
            $branchId = (int)$br['id'];
            $qCount   = (int)$br['question_count'];

            for ($q = 1; $q <= $qCount; $q++) {
                $fieldName  = "q_{$branchId}_{$q}";
                $studentAns = isset($postData[$fieldName]) 
                    ? strtoupper(trim($postData[$fieldName])) : '';
                
                if (!isset($answersMap[$branchId])) {
                    $answersMap[$branchId] = [];
                }
                $answersMap[$branchId][$q] = $studentAns;
                
                if ($studentAns !== '') {
                    $anyAnswered = true;
                }

                $correctAns  = $answerKey[$bookletCode][$branchId][$q] ?? null;
                $outcomeList = $outcomeByQuestion[$bookletCode][$branchId][$q] ?? [];

                // Soru bazlı durum
                $status = 'blank';
                if ($studentAns !== '') {
                    if ($correctAns === null) {
                        $status = 'no_key';
                    } elseif ($studentAns === $correctAns) {
                        $status = 'correct';
                    } else {
                        $status = 'wrong';
                    }
                }

                if (!isset($questionReview[$branchId])) {
                    $questionReview[$branchId] = [];
                }
                $questionReview[$branchId][$q] = [
                    'student' => $studentAns,
                    'correct' => $correctAns,
                    'status'  => $status,
                ];

                // Boş cevap
                if ($studentAns === '') {
                    $totalBlank++;
                    $branchStats[$branchId]['blank']++;
                    foreach ($outcomeList as $oid) {
                        if (isset($outcomeStats[$oid])) {
                            $outcomeStats[$oid]['blank']++;
                            $outcomeStats[$oid]['questions'][] = $q;
                        }
                    }
                    continue;
                }

                // Anahtar yok
                if ($correctAns === null) {
                    $totalBlank++;
                    $branchStats[$branchId]['blank']++;
                    foreach ($outcomeList as $oid) {
                        if (isset($outcomeStats[$oid])) {
                            $outcomeStats[$oid]['blank']++;
                            $outcomeStats[$oid]['questions'][] = $q;
                        }
                    }
                    continue;
                }

                // Doğru/Yanlış
                if ($studentAns === $correctAns) {
                    $totalCorrect++;
                    $branchStats[$branchId]['correct']++;
                    foreach ($outcomeList as $oid) {
                        if (isset($outcomeStats[$oid])) {
                            $outcomeStats[$oid]['correct']++;
                            $outcomeStats[$oid]['questions'][] = $q;
                        }
                    }
                } else {
                    $totalWrong++;
                    $branchStats[$branchId]['wrong']++;
                    foreach ($outcomeList as $oid) {
                        if (isset($outcomeStats[$oid])) {
                            $outcomeStats[$oid]['wrong']++;
                            $outcomeStats[$oid]['questions'][] = $q;
                        }
                    }
                }
            }
        }

        // Net hesaplama
        $totalNet = $this->calculateNet(
            $totalCorrect, 
            $totalWrong, 
            $useNegativeScoring, 
            $wrongPerMinus
        );
        
        $totalAnswered = $totalCorrect + $totalWrong;
        $successRate   = $totalAnswered > 0 
            ? ($totalCorrect / $totalAnswered) * 100.0 : 0.0;

        // Branş net'leri
        foreach ($branchStats as $bid => &$bs) {
            $bs['net'] = $this->calculateNet(
                $bs['correct'], 
                $bs['wrong'], 
                $useNegativeScoring, 
                $wrongPerMinus
            );
        }
        unset($bs);

        // Kazanım net'leri
        foreach ($outcomeStats as $oid => &$os) {
            $os['net'] = $this->calculateNet(
                $os['correct'], 
                $os['wrong'], 
                $useNegativeScoring, 
                $wrongPerMinus
            );
        }
        unset($os);

        // Konu bazlı birleştirme
        $aggregatedOutcomeStats = $this->aggregateOutcomesByTopic($outcomeStats);

        // Güçlü ve zayıf konular
        list($strongTopics, $weakTopics) = $this->identifyStrongWeakTopics(
            $aggregatedOutcomeStats
        );

        return [
            'totalCorrect'           => $totalCorrect,
            'totalWrong'             => $totalWrong,
            'totalBlank'             => $totalBlank,
            'totalNet'               => $totalNet,
            'successRate'            => $successRate,
            'branchStats'            => array_values($branchStats),
            'outcomeStats_raw'       => $outcomeStats,
            'aggregatedOutcomeStats' => $aggregatedOutcomeStats,
            'strongTopics'           => $strongTopics,
            'weakTopics'             => $weakTopics,
            'bookletCode'            => $bookletCode,
            'anyAnswered'            => $anyAnswered,
            'questionReview'         => $questionReview,
        ];
    }

    /**
     * Kazanımları konu adına göre birleştir
     */
    private function aggregateOutcomesByTopic(array $outcomeStats): array
    {
        $aggregated = [];
        $outcomeToAggKey = [];

        foreach ($outcomeStats as $oid => $os) {
            $topicName = trim((string)$os['name']);
            if ($topicName === '') {
                $topicName = 'İsimsiz Konu';
            }

            $branchId = (int)$os['branch_id'];
            $altBranch = trim((string)($os['alt_branch'] ?? ''));
            $key = $branchId . '|' . mb_strtolower($topicName, 'UTF-8');

            $outcomeToAggKey[$oid] = $key;

            if (!isset($aggregated[$key])) {
                $aggregated[$key] = [
                    'branch_id'  => $branchId,
                    'alt_branch' => $altBranch,
                    'topic'      => $topicName,
                    'codes'      => [],
                    'correct'    => 0,
                    'wrong'      => 0,
                    'blank'      => 0,
                    'net'        => 0.0,
                    'questions'  => [], // Soru numaraları
                ];
            }

            $aggregated[$key]['correct'] += $os['correct'];
            $aggregated[$key]['wrong']   += $os['wrong'];
            $aggregated[$key]['blank']   += $os['blank'];
            $aggregated[$key]['net']     += $os['net'];

            if (!in_array($os['code'], $aggregated[$key]['codes'], true)) {
                $aggregated[$key]['codes'][] = $os['code'];
            }
            
            // Soru numaralarını birleştir
            if (!empty($os['questions'])) {
                foreach ($os['questions'] as $qno) {
                    if (!in_array($qno, $aggregated[$key]['questions'], true)) {
                        $aggregated[$key]['questions'][] = $qno;
                    }
                }
            }
        }

        // Soru numaralarını sırala
        foreach ($aggregated as &$item) {
            if (!empty($item['questions'])) {
                sort($item['questions'], SORT_NUMERIC);
            }
        }
        unset($item);

        return array_values($aggregated);
    }

    /**
     * Güçlü ve zayıf konuları belirle
     */
    private function identifyStrongWeakTopics(array $aggregated): array
    {
        $strong = [];
        $weak = [];

        foreach ($aggregated as $item) {
            $total = $item['correct'] + $item['wrong'] + $item['blank'];
            if ($total === 0) {
                continue;
            }

            $rate = $item['correct'] / $total;

            if ($rate >= 0.70 && $item['correct'] > 0) {
                $strong[] = $item;
            } elseif ($rate < 0.50) {
                $weak[] = $item;
            }
        }

        return [$strong, $weak];
    }
}
