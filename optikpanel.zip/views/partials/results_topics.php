<?php

// Güçlü ve zayıf konuları branş + alt branşa göre grupla
$strongByBranchAlt = [];
foreach ($results['strongTopics'] as $st) {
  $bid = (int)$st['branch_id'];
  $alt = trim($st['alt_branch'] ?? '');
  if ($alt === '') $alt = 'Genel';
  if (!isset($strongByBranchAlt[$bid])) $strongByBranchAlt[$bid] = [];
  if (!isset($strongByBranchAlt[$bid][$alt])) $strongByBranchAlt[$bid][$alt] = [];
  $strongByBranchAlt[$bid][$alt][] = $st;
}

$weakByBranchAlt = [];
foreach ($results['weakTopics'] as $wt) {
  $bid = (int)$wt['branch_id'];
  $alt = trim($wt['alt_branch'] ?? '');
  if ($alt === '') $alt = 'Genel';
  if (!isset($weakByBranchAlt[$bid])) $weakByBranchAlt[$bid] = [];
  if (!isset($weakByBranchAlt[$bid][$alt])) $weakByBranchAlt[$bid][$alt] = [];
  $weakByBranchAlt[$bid][$alt][] = $wt;
}

// Branch name -> id map (branchStats'tan gelen name ile id bulmak için)
$branchNameToId = [];
foreach ($branches as $br) {
  $branchNameToId[(string)$br['name']] = (int)$br['id'];
}

$accId = 'accStrongWeakBranches';
?>

<!-- GÜÇLÜ & GELİŞİME AÇIK KONULAR -->
<div class="results-card" id="result-card-strongweak">
  <div class="results-header">
    <div class="results-title mb-0">Güçlü ve Gelişime Açık Konular</div>
  </div>

  <div id="<?php echo $accId; ?>" class="accordion omc-acc mt-3">

    <?php $i = 0; foreach ($results['branchStats'] as $bs): $i++; ?>
      <?php
        $bname = (string)($bs['name'] ?? '');
        $bid   = $branchNameToId[$bname] ?? null;
        if ($bid === null) continue;

        $branchStrongGroups = $strongByBranchAlt[$bid] ?? [];
        $branchWeakGroups   = $weakByBranchAlt[$bid] ?? [];

        // Bu branşta hiç veri yoksa atla
        if (empty($branchStrongGroups) && empty($branchWeakGroups)) continue;

        // alt branş isimlerini birleştir
        $altNames = [];
        if (!empty($branchStrongGroups)) $altNames = array_merge($altNames, array_keys($branchStrongGroups));
        if (!empty($branchWeakGroups))   $altNames = array_merge($altNames, array_keys($branchWeakGroups));
        $altNames = array_values(array_unique($altNames));

        // Header için toplamlar (opsiyonel ama güzel durur)
        $sumStrong = 0; $sumWeak = 0;
        foreach ($branchStrongGroups as $alts) $sumStrong += count($alts);
        foreach ($branchWeakGroups as $alts)   $sumWeak += count($alts);

        $headingId  = "h-{$accId}-{$bid}";
        $collapseId = "c-{$accId}-{$bid}";
        $isOpen     = ($i === 1); // ilk branş açık gelsin istersen
      ?>

      <div class="card omc-acc-card mb-2">
        <div class="card-header omc-acc-header" id="<?php echo $headingId; ?>">

          <button
            class="btn btn-link btn-block text-left omc-acc-btn <?php echo $isOpen ? '' : 'collapsed'; ?>"
            type="button"
            data-toggle="collapse"
            data-target="#<?php echo $collapseId; ?>"
            aria-expanded="<?php echo $isOpen ? 'true' : 'false'; ?>"
            aria-controls="<?php echo $collapseId; ?>"
          >
            <div class="omc-acc-row">
              <div class="omc-acc-title"><?php echo h($bname); ?></div>

              <div class="omc-acc-metrics">
                <span class="mchip ok">✔ Güçlü : <?php echo (int)$sumStrong; ?></span>
                <span class="mchip bad">✖ Gelişime Açık : <?php echo (int)$sumWeak; ?></span>
              </div>
            </div>

            <!-- Sağ ok -->
            <span class="omc-acc-caret" aria-hidden="true"></span>
          </button>

        </div>

        <div
          id="<?php echo $collapseId; ?>"
          class="collapse <?php echo $isOpen ? 'show' : ''; ?>"
          aria-labelledby="<?php echo $headingId; ?>"
          data-parent="#<?php echo $accId; ?>"
        >
          <div class="card-body omc-acc-body">

            <?php foreach ($altNames as $altName): ?>
              <?php
                $strongList = $branchStrongGroups[$altName] ?? [];
                $weakList   = $branchWeakGroups[$altName] ?? [];
              ?>

              <div class="topic-alt-block mb-3">
                <div class="topic-subtitle-big">
                  Alt Branş: <?php echo h($altName); ?>
                </div>

                <!-- Güçlü Konular -->
                <div class="topic-box topic-box-strong">
                  <div class="topic-box-title">Güçlü Konular (≥ %70)</div>

                  <?php if (!empty($strongList)): ?>
                    <?php foreach ($strongList as $os): ?>
                      <?php $totalQs = (int)$os['correct'] + (int)$os['wrong'] + (int)$os['blank']; ?>
                      <div class="topic-pill">
                        <span><?php echo h($os['topic']); ?></span>
                        <small>
                          Soru: <?php echo (int)$totalQs; ?> ·
                          Doğru: <?php echo (int)$os['correct']; ?> ·
                          Yanlış: <?php echo (int)$os['wrong']; ?> ·
                          Net: <?php echo number_format((float)$os['net'], 2, ',', '.'); ?>
                        </small>
                      </div>
                    <?php endforeach; ?>
                  <?php else: ?>
                    <small class="text-muted">Bu alt branşta güçlü konu bulunmuyor.</small>
                  <?php endif; ?>
                </div>

                <!-- Gelişime Açık Konular -->
                <div class="topic-box topic-box-weak mb-0">
                  <div class="topic-box-title">Gelişime Açık Konular (&lt; %50)</div>

                  <?php if (!empty($weakList)): ?>
                    <?php foreach ($weakList as $os): ?>
                      <?php $totalQs = (int)$os['correct'] + (int)$os['wrong'] + (int)$os['blank']; ?>
                      <div class="topic-pill">
                        <span><?php echo h($os['topic']); ?></span>
                        <small>
                          Soru: <?php echo (int)$totalQs; ?> ·
                          Doğru: <?php echo (int)$os['correct']; ?> ·
                          Yanlış: <?php echo (int)$os['wrong']; ?> ·
                          Net: <?php echo number_format((float)$os['net'], 2, ',', '.'); ?>
                        </small>
                      </div>
                    <?php endforeach; ?>
                  <?php else: ?>
                    <small class="text-muted">Bu alt branşta gelişime açık konu bulunmuyor.</small>
                  <?php endif; ?>
                </div>

              </div>
            <?php endforeach; ?>

          </div>
        </div>
      </div>

    <?php endforeach; ?>

  </div>
</div>
