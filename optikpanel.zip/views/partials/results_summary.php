<?php
/**
 * Sonuç Özeti View
 * Toplam doğru/yanlış/net gösterimi
 */
?>

<div class="results-card" id="result-card-summary">
    <div class="results-header">
        <div class="results-title mb-0">Sınav Sonucu</div>
    </div>
    
    <p class="text-muted mb-2 mt-2">
        Kitapçık: <strong><?php echo h($results['bookletCode']); ?></strong>
        <?php if (!$results['anyAnswered']): ?>
            <br><span class="text-danger">Hiç işaretleme yapmadığınız için tüm sorular boş kabul edildi.</span>
        <?php endif; ?>
    </p>

    <div class="row mb-3">
        <div class="col-md-3 col-6 mb-2">
            <span class="badge badge-success badge-stat">
                Doğru: <?php echo (int)$results['totalCorrect']; ?>
            </span>
        </div>
        <div class="col-md-3 col-6 mb-2">
            <span class="badge badge-danger badge-stat">
                Yanlış: <?php echo (int)$results['totalWrong']; ?>
            </span>
        </div>
        <div class="col-md-3 col-6 mb-2">
            <span class="badge badge-secondary badge-stat">
                Boş: <?php echo (int)$results['totalBlank']; ?>
            </span>
        </div>
        <div class="col-md-3 col-6 mb-2">
            <span class="badge badge-primary badge-stat">
                Net: <?php echo number_format($results['totalNet'], 2, ',', '.'); ?>
            </span>
        </div>
    </div>

    <p class="mb-0">
        Genel Başarı Oranı:
        <strong><?php echo number_format($results['successRate'], 1, ',', '.'); ?>%</strong>
    </p>
</div>
