<!-- SORU BAZLI OPTİK GÖRÜNÜMÜ -->
<div class="results-card" id="result-card-review">
    <div class="results-header">
        <div class="results-title mb-0">Soru Bazlı Optik Görünümü</div>
    </div>
    <p class="text-muted mb-2 mt-2">
        Aşağıda işaretlediğin optik formu; doğru ve yanlış seçenekler renklendirilmiş olarak görebilirsin.
    </p>

    <?php foreach ($branches as $br): ?>
        <?php
        $branchId = (int)$br['id'];
        $qCount   = (int)$br['question_count'];
        if ($qCount <= 0) continue;
        $branchReview = $results['questionReview'][$branchId] ?? [];
        ?>
        <div class="branch-card">
            <div class="branch-title"><?php echo h($br['name']); ?></div>
            <div class="branch-info">
                Soru Sayısı: <?php echo $qCount; ?>
            </div>
            <div class="table-responsive">
                <table class="optical-table">
                    <tbody>
                    <?php for ($q = 1; $q <= $qCount; $q++): ?>
                        <?php
                        $qr = $branchReview[$q] ?? ['student' => '', 'correct' => null, 'status' => 'blank'];
                        $studentAns = $qr['student'];
                        $correctAns = $qr['correct'];
                        $status     = $qr['status'];
                        ?>
                        <tr>
                            <?php $vUrl = $video_by_branch_q[$branchId][$q] ?? null; ?>
                            <td class="optical-qno">
                                <?php if ($vUrl): ?>
                                    <button type="button"
                                            class="video-icon"
                                            onclick="openVideoSolution('<?php echo h($vUrl); ?>')"
                                            title="Video çözüm"
                                            aria-label="Video çözüm">
                                        <svg viewBox="0 0 24 24" aria-hidden="true">
                                            <path d="M8 5v14l11-7z"></path>
                                        </svg>
                                    </button>
                                <?php endif; ?>
                                <?php echo $q; ?>
                            </td>
                            <?php foreach (['A','B','C','D','E'] as $opt): ?>
                                <?php
                                $classes = 'review-bubble';
                                if ($correctAns === $opt && $studentAns === $opt) {
                                    $classes .= ' rb-correct-chosen';
                                } elseif ($correctAns === $opt) {
                                    $classes .= ' rb-correct-only';
                                } elseif ($studentAns === $opt && $correctAns !== null && $studentAns !== $correctAns) {
                                    $classes .= ' rb-wrong-chosen';
                                } elseif ($status === 'blank') {
                                    $classes .= ' rb-blank';
                                }
                                ?>
                                <td class="optical-cell">
                                    <div class="<?php echo $classes; ?>">
                                        <?php echo $opt; ?>
                                    </div>
                                </td>
                            <?php endforeach; ?>
                        </tr>
                    <?php endfor; ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php endforeach; ?>
</div>
