<?php
/**
 * Konu Bazlı Analiz (Kazanım Tablosu) View
 * Tüm kazanımları tablo formatında gösterir - Mobil uyumlu
 */
?>

<!-- KONU BAZLI ANALİZ -->
<div class="results-card" id="result-card-topic">
  <div class="results-header">
    <div class="results-title mb-0">Konu Bazlı Analiz</div>
  </div>

  <!-- Masaüstü: Geliştirilmiş Tablo -->
  <div class="d-none d-lg-block">
    <div class="table-responsive mt-3 topic-table-wrap">
      <table class="table table-sm topic-table">
        <thead>
          <tr>
            <th class="col-topic">Konu</th>
            <th class="col-branch">Branş</th>
            <th class="col-questions">Soru No</th>
            <th class="col-count text-center">Soru</th>
            <th class="col-c text-center">D</th>
            <th class="col-w text-center">Y</th>
            <th class="col-b text-center">B</th>
            <th class="col-net text-right">Net</th>
          </tr>
        </thead>
        <tbody>
        <?php if (!empty($results['aggregatedOutcomeStats'])): ?>
          <?php foreach ($results['aggregatedOutcomeStats'] as $os): ?>
            <?php
              // Branş adını bul
              $bname = '';
              foreach ($branches as $br) {
                if ((int)$br['id'] === (int)$os['branch_id']) {
                  $bname = $br['name'];
                  break;
                }
              }

              $totalQs = (int)$os['correct'] + (int)$os['wrong'] + (int)$os['blank'];
              $qList   = $os['questions'] ?? [];
              $qText   = !empty($qList) ? implode(' - ', $qList) : '—';

              $c = (int)$os['correct'];
              $w = (int)$os['wrong'];
              $b = (int)$os['blank'];
              $net = (float)$os['net'];
            ?>
            <tr>
              <td class="cell-topic">
                <div class="topic-name"><?php echo h($os['topic']); ?></div>
              </td>

              <td class="cell-branch">
                <span class="branch-badge"><?php echo h($bname); ?></span>
              </td>

              <td class="cell-questions">
                <span class="q-badge"><?php echo h($qText); ?></span>
              </td>

              <td class="text-center">
                <span class="num-badge num-muted"><?php echo $totalQs; ?></span>
              </td>

              <td class="text-center">
                <span class="num-badge num-ok"><?php echo $c; ?></span>
              </td>

              <td class="text-center">
                <span class="num-badge num-bad"><?php echo $w; ?></span>
              </td>

              <td class="text-center">
                <span class="num-badge num-empty"><?php echo $b; ?></span>
              </td>

              <td class="text-right">
                <span class="net-pill"><?php echo number_format($net, 2, ',', '.'); ?></span>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php else: ?>
          <tr>
            <td colspan="8" class="text-center text-muted py-4">
              Bu sınav için konu bazlı analiz bulunmuyor.
            </td>
          </tr>
        <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>

  <!-- Tablet & Mobil: Kartlar (SENİN MEVCUT YAPIN) -->
  <div class="d-lg-none mt-2">
    <?php if (!empty($results['aggregatedOutcomeStats'])): ?>

      <?php
      // Branch map (id => name)
      $branchMap = [];
      foreach ($branches as $br) {
        $branchMap[(int)$br['id']] = $br['name'];
      }

      // Outcome'ları branch_id'ye göre grupla
      $grouped = [];
      foreach ($results['aggregatedOutcomeStats'] as $os) {
        $bid = (int)($os['branch_id'] ?? 0);
        if (!isset($grouped[$bid])) $grouped[$bid] = [];
        $grouped[$bid][] = $os;
      }

      // Branch adına göre sırala
      uksort($grouped, function($a, $b) use ($branchMap) {
        $an = $branchMap[$a] ?? ('Branş '.$a);
        $bn = $branchMap[$b] ?? ('Branş '.$b);
        return strcasecmp($an, $bn);
      });

      $accId = 'accOutcomeBranches4';
      ?>

      <div id="<?php echo $accId; ?>" class="accordion omc-acc">

        <?php $i = 0; foreach ($grouped as $bid => $items): $i++; ?>
          <?php
            $bname = $branchMap[$bid] ?? ('Branş '.$bid);

            $sumC = $sumW = $sumB = 0;
            $sumNet = 0;

            foreach ($items as $it) {
              $sumC   += (int)($it['correct'] ?? 0);
              $sumW   += (int)($it['wrong'] ?? 0);
              $sumB   += (int)($it['blank'] ?? 0);
              $sumNet += (float)($it['net'] ?? 0);
            }

            $headingId  = "h-{$accId}-{$bid}";
            $collapseId = "c-{$accId}-{$bid}";
            $isOpen     = ($i === 1);
          ?>

          <div class="card omc-acc-card">

            <div class="card-header omc-acc-header" id="<?php echo $headingId; ?>">
              <button
                class="btn btn-link btn-block text-left omc-acc-btn <?php echo $isOpen ? '' : 'collapsed'; ?>"
                type="button"
                data-toggle="collapse"
                data-target="#<?php echo $collapseId; ?>"
                aria-expanded="<?php echo $isOpen ? 'true' : 'false'; ?>"
                aria-controls="<?php echo $collapseId; ?>"
              >
                <div class="omc-acc-row">
                  <div class="omc-acc-title"><?php echo h($bname); ?></div>

                  <div class="omc-acc-metrics">
                    <span class="mchip ok">✔ <?php echo $sumC; ?></span>
                    <span class="mchip bad">✖ <?php echo $sumW; ?></span>
                    <span class="mchip emp">○ <?php echo $sumB; ?></span>
                    <span class="mchip net">Net <?php echo number_format($sumNet, 2, ',', '.'); ?></span>
                  </div>
                </div>

                <span class="omc-acc-caret" aria-hidden="true"></span>
              </button>
            </div>

            <div
              id="<?php echo $collapseId; ?>"
              class="collapse <?php echo $isOpen ? 'show' : ''; ?>"
              aria-labelledby="<?php echo $headingId; ?>"
              data-parent="#<?php echo $accId; ?>"
            >
              <div class="card-body omc-acc-body">

                <?php foreach ($items as $os): ?>
                  <?php
                    $qList = $os['questions'] ?? [];
                    $qText = !empty($qList) ? implode(', ', $qList) : '';
                  ?>

                  <div class="outcome-mini-card">
                    <div class="omc-header">
                      <div class="omc-title"><?php echo h($os['topic']); ?></div>
                      <div class="omc-branch"><?php echo h($bname); ?></div>
                    </div>

                    <?php if ($qText): ?>
                      <div class="omc-questions">
                        Soru Numarası: <strong><?php echo h($qText); ?></strong>
                      </div>
                    <?php endif; ?>

                    <div class="omc-stats">
                      <span class="omc-chip omc-chip-ok"><span class="omc-ico">✔</span> <?php echo (int)$os['correct']; ?></span>
                      <span class="omc-chip omc-chip-bad"><span class="omc-ico">✖</span> <?php echo (int)$os['wrong']; ?></span>
                      <span class="omc-chip omc-chip-empty"><span class="omc-ico">○</span> <?php echo (int)$os['blank']; ?></span>
                      <span class="omc-net-pill">Net <?php echo number_format((float)$os['net'], 2, ',', '.'); ?></span>
                    </div>
                  </div>

                <?php endforeach; ?>

              </div>
            </div>

          </div>
        <?php endforeach; ?>

      </div>

    <?php else: ?>
      <div class="text-center text-muted p-2">
        Konu bazlı analiz bulunmuyor.
      </div>
    <?php endif; ?>
  </div>

</div>
