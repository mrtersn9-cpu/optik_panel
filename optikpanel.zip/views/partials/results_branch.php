<!-- BRANŞA GÖRE TABLO -->
<div class="results-card" id="result-card-branch">
  <div class="results-header">
    <div class="results-title mb-0">Branşa Göre Detaylı Analiz</div>
  </div>

  <!-- Masaüstü: Geliştirilmiş Tablo -->
  <div class="d-none d-md-block">
    <div class="table-responsive mt-3 branch-table-wrap">
      <table class="table table-sm branch-table">
        <thead>
          <tr>
            <th class="col-branch">Branş</th>
            <th class="col-c text-center">D</th>
            <th class="col-w text-center">Y</th>
            <th class="col-b text-center">B</th>
            <th class="col-net text-right">Net</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($results['branchStats'] as $bs): ?>
            <?php
              $c   = (int)$bs['correct'];
              $w   = (int)$bs['wrong'];
              $b   = (int)$bs['blank'];
              $net = (float)$bs['net'];
            ?>
            <tr>
              <td class="cell-branch">
                <span class="branch-name-pill"><?php echo h($bs['name']); ?></span>
              </td>
              <td class="text-center">
                <span class="num-badge num-ok"><?php echo $c; ?></span>
              </td>
              <td class="text-center">
                <span class="num-badge num-bad"><?php echo $w; ?></span>
              </td>
              <td class="text-center">
                <span class="num-badge num-empty"><?php echo $b; ?></span>
              </td>
              <td class="text-right">
                <span class="net-pill"><?php echo number_format($net, 2, ',', '.'); ?></span>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>

  <!-- Mobil: Kartlar -->
  <div class="d-md-none mt-3">
    <?php foreach ($results['branchStats'] as $bs): ?>
      <div class="branch-result-card mb-3">
        <div class="branch-result-name"><?php echo h($bs['name']); ?></div>
        <div class="row">
          <div class="col-6 mb-2">
            <div class="branch-stat-item">
              <span class="branch-stat-label">Doğru</span>
              <span class="branch-stat-value text-success"><?php echo (int)$bs['correct']; ?></span>
            </div>
          </div>
          <div class="col-6 mb-2">
            <div class="branch-stat-item">
              <span class="branch-stat-label">Yanlış</span>
              <span class="branch-stat-value text-danger"><?php echo (int)$bs['wrong']; ?></span>
            </div>
          </div>
          <div class="col-6">
            <div class="branch-stat-item">
              <span class="branch-stat-label">Boş</span>
              <span class="branch-stat-value text-secondary"><?php echo (int)$bs['blank']; ?></span>
            </div>
          </div>
          <div class="col-6">
            <div class="branch-stat-item">
              <span class="branch-stat-label">Net</span>
              <span class="branch-stat-value text-primary font-weight-bold"><?php echo number_format($bs['net'], 2, ',', '.'); ?></span>
            </div>
          </div>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
</div>
