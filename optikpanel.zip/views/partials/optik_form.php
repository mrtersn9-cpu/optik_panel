<?php if ($errorMsg): ?>
    <div class="alert alert-danger exam-card"><?php echo h($errorMsg); ?></div>
<?php endif; ?>

<?php if (!$booklets): ?>
    <div class="alert alert-warning exam-card">
        Bu deneme için kitapçık tanımlı değil.
    </div>
<?php else: ?>
    <form method="post" id="exam-form">
        <div class="exam-card">
            <div class="d-flex justify-content-between align-items-center mb-3 flex-wrap">
                <h5 class="mb-2 mb-md-0">Optik Form</h5>
                <div class="form-inline">
                    <label class="mr-2 mb-0"><strong>Kitapçık:</strong></label>
                    <select name="booklet_code" class="form-control form-control-sm">
                        <?php foreach ($booklets as $b): ?>
                            <option value="<?php echo h($b['code']); ?>"
                                <?php echo ($selectedBookletCode === $b['code']) ? 'selected' : ''; ?>>
                                <?php echo h($b['code']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>

            <p class="text-muted mb-3">
                Aşağıdaki optik formda cevaplarınızı işaretleyebilirsiniz.
            </p>

            <?php foreach ($branches as $br): ?>
                <?php
                $branchId = (int)$br['id'];
                $qCount   = (int)$br['question_count'];
                if ($qCount <= 0) continue;
                ?>
                <div class="branch-card">
                    <div class="branch-title"><?php echo h($br['name']); ?></div>
                    <div class="branch-info">
                        Soru Sayısı: <?php echo $qCount; ?>
                    </div>

                    <div class="table-responsive">
                        <table class="optical-table">
                            <tbody>
                            <?php for ($q = 1; $q <= $qCount; $q++): ?>
                                <tr>
                                    <td class="optical-qno"><?php echo $q; ?></td>
                                    <?php foreach (['A','B','C','D','E'] as $opt): ?>
                                        <?php
                                        $inputName = "q_{$branchId}_{$q}";
                                        $inputId   = "q_{$branchId}_{$q}_{$opt}";
                                        ?>
                                        <td class="optical-cell">
                                            <input type="radio"
                                                   id="<?php echo h($inputId); ?>"
                                                   name="<?php echo h($inputName); ?>"
                                                   value="<?php echo $opt; ?>">
                                            <label for="<?php echo h($inputId); ?>" class="optical-bubble">
                                                <?php echo $opt; ?>
                                            </label>
                                        </td>
                                    <?php endforeach; ?>
                                </tr>
                            <?php endfor; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            <?php endforeach; ?>

            <div class="text-right mt-3">
                <button type="submit" name="submit_exam" class="btn btn-primary">
                    Sınavı Bitir
                </button>
            </div>
        </div>
    </form>
<?php endif; ?>
