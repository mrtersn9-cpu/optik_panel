<?php
require_once __DIR__ . '/config.php';
require_login();

$errors = [];

$exam_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($exam_id <= 0) die('Geçersiz deneme ID.');

// ---------- Helpers ----------
function h($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

function make_booklet_codes(int $count): array {
    $codes = [];
    $alphabet = range('A', 'Z');
    for ($i = 0; $i < $count; $i++) {
        $codes[] = $alphabet[$i] ?? ('K' . ($i + 1));
    }
    return $codes;
}

/**
 * MariaDB/MySQL: SHOW TABLES LIKE ? placeholder bazı ortamlarda 1064 verir.
 * Bu yüzden information_schema üzerinden kontrol ediyoruz.
 */
function table_exists(PDO $pdo, string $table): bool {
    $sql = "SELECT COUNT(*)
            FROM information_schema.tables
            WHERE table_schema = DATABASE() AND table_name = ?";
    $st = $pdo->prepare($sql);
    $st->execute([$table]);
    return (int)$st->fetchColumn() > 0;
}

function delete_outcomes_by_exam(PDO $pdo, int $exam_id): void {
    // Kitapçık sayısı değişince tüm kazanımlar silinsin (istenen kural)
    if (table_exists($pdo, 'exam_outcomes')) {
        $pdo->prepare("DELETE FROM exam_outcomes WHERE exam_id = ?")->execute([$exam_id]);
    }
}

function delete_outcomes_by_branch(PDO $pdo, int $branch_id): void {
    // Branş silinince / soru sayısı değişince ilgili branşın kazanımları silinsin (seçilen mantık)
    if (table_exists($pdo, 'exam_outcomes')) {
        $pdo->prepare("DELETE FROM exam_outcomes WHERE branch_id = ?")->execute([$branch_id]);
    }
}

// ---------- Load current data ----------
$stmt = $pdo->prepare("SELECT * FROM exams WHERE id = ?");
$stmt->execute([$exam_id]);
$exam = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$exam) die('Deneme bulunamadı.');

// Current branches (keep ID)
$stmtBr = $pdo->prepare("SELECT id, name, question_count FROM exam_branches WHERE exam_id = ? ORDER BY id ASC");
$stmtBr->execute([$exam_id]);
$branches_db = $stmtBr->fetchAll(PDO::FETCH_ASSOC);
$branches_db_map = [];
foreach ($branches_db as $b) {
    $branches_db_map[(int)$b['id']] = $b;
}

// Current booklets
$stmtB = $pdo->prepare("SELECT id, code FROM exam_booklets WHERE exam_id = ? ORDER BY id ASC");
$stmtB->execute([$exam_id]);
$booklets_db = $stmtB->fetchAll(PDO::FETCH_ASSOC);
$current_booklet_count = count($booklets_db);
if ($current_booklet_count < 1) $current_booklet_count = 1;

// ---------- POST: Update ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $name          = trim($_POST['name'] ?? '');
    $exam_number   = trim($_POST['exam_number'] ?? '');
    $barcode       = trim($_POST['barcode'] ?? '');
    $booklet_count = (int)($_POST['booklet_count'] ?? $current_booklet_count);

    $branch_ids       = $_POST['branch_id'] ?? [];
    $branch_names     = $_POST['branch_name'] ?? [];
    $branch_questions = $_POST['branch_question_count'] ?? [];

    if ($name === '') $errors[] = 'Deneme adı zorunludur.';
    if ($exam_number === '') $errors[] = 'Deneme numarası zorunludur.';
    if ($barcode === '') $errors[] = 'Barkod zorunludur.';
    if ($booklet_count < 1) $errors[] = 'En az 1 kitapçık seçmelisiniz.';

    // Parse branches
    $submitted_rows = [];
    $max = max(count($branch_ids), count($branch_names), count($branch_questions));
    for ($i = 0; $i < $max; $i++) {
        $bid = isset($branch_ids[$i]) ? (int)$branch_ids[$i] : 0;
        $bname = trim((string)($branch_names[$i] ?? ''));
        $qcount = (int)($branch_questions[$i] ?? 0);

        // completely empty row -> ignore
        if ($bid <= 0 && $bname === '' && $qcount <= 0) continue;

        if ($bname === '' || $qcount <= 0) {
            $errors[] = 'Branş satırlarında branş adı ve soru sayısı zorunludur.';
            break;
        }

        $submitted_rows[] = [
            'id' => $bid,
            'name' => $bname,
            'question_count' => $qcount
        ];
    }

    if (empty($submitted_rows)) $errors[] = 'En az bir branş ve soru sayısı girmelisiniz.';

    if (empty($errors)) {
        $pdo->beginTransaction();
        try {

            // 1) exams update (KAZANIM SİLME YOK)
            $st = $pdo->prepare("UPDATE exams SET name = ?, exam_number = ?, barcode = ? WHERE id = ?");
            $st->execute([$name, $exam_number, $barcode, $exam_id]);

            // 2) Kitapçık sayısı değişti mi?
            $booklet_changed = ((int)$booklet_count !== (int)$current_booklet_count);

            if ($booklet_changed) {
                // İSTEK: kitapçık sayısı değişince kazanımları sil
                delete_outcomes_by_exam($pdo, $exam_id);

                // Kitapçıkları hedef sayıya göre ayarla (azaltma da silsin)
                $desired_codes = make_booklet_codes($booklet_count);
                $existing_codes = array_map(fn($r) => (string)$r['code'], $booklets_db);

                // Fazla olanları sil (azaltma)
                foreach ($existing_codes as $code) {
                    if (!in_array($code, $desired_codes, true)) {
                        $pdo->prepare("DELETE FROM exam_booklets WHERE exam_id = ? AND code = ?")
                            ->execute([$exam_id, $code]);
                    }
                }

                // Eksik olanları ekle (artırma)
                foreach ($desired_codes as $code) {
                    if (!in_array($code, $existing_codes, true)) {
                        $pdo->prepare("INSERT INTO exam_booklets (exam_id, code) VALUES (?, ?)")
                            ->execute([$exam_id, $code]);
                    }
                }
            }

            // 3) Branş güncelleme (ID KORU)
            // - mevcutlar: update
            // - yeni: insert
            // - kaldırılan: delete (ve o branşın kazanımlarını da sil)
            // - soru sayısı değişen: sadece o branşın kazanımlarını sil

            $submitted_ids = [];
            foreach ($submitted_rows as $r) {
                $bid = (int)$r['id'];

                if ($bid > 0 && isset($branches_db_map[$bid])) {
                    $submitted_ids[$bid] = true;

                    // soru sayısı değiştiyse: sadece o branşın kazanımlarını sil
                    $old_q = (int)$branches_db_map[$bid]['question_count'];
                    $new_q = (int)$r['question_count'];
                    if ($old_q !== $new_q) {
                        delete_outcomes_by_branch($pdo, $bid);
                    }

                    $pdo->prepare("UPDATE exam_branches SET name = ?, question_count = ? WHERE id = ? AND exam_id = ?")
                        ->execute([$r['name'], $r['question_count'], $bid, $exam_id]);

                } else {
                    // yeni branş
                    $pdo->prepare("INSERT INTO exam_branches (exam_id, name, question_count) VALUES (?, ?, ?)")
                        ->execute([$exam_id, $r['name'], $r['question_count']]);
                }
            }

            // kaldırılan branşlar = db - submitted
            foreach ($branches_db_map as $bid => $b) {
                if (!isset($submitted_ids[(int)$bid])) {
                    // Bu branş kaldırılmış -> kazanımlarını sil + branşı sil
                    delete_outcomes_by_branch($pdo, (int)$bid);
                    $pdo->prepare("DELETE FROM exam_branches WHERE id = ? AND exam_id = ?")
                        ->execute([(int)$bid, $exam_id]);
                }
            }

            $pdo->commit();
            header('Location: exam_detail.php?id=' . $exam_id);
            exit;

        } catch (Exception $e) {
            $pdo->rollBack();
            $errors[] = 'Veritabanı hatası: ' . $e->getMessage();
        }
    }
}

include __DIR__ . '/admin_header.php';

// Form values
$old_name = $_POST['name'] ?? ($exam['name'] ?? '');
$old_exam_number = $_POST['exam_number'] ?? ($exam['exam_number'] ?? '');
$old_barcode = $_POST['barcode'] ?? ($exam['barcode'] ?? '');
$old_booklet_count = $_POST['booklet_count'] ?? (string)$current_booklet_count;

// Branch form rows
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $old_branch_ids = $_POST['branch_id'] ?? [];
    $old_branches   = $_POST['branch_name'] ?? [''];
    $old_qcounts    = $_POST['branch_question_count'] ?? [''];
} else {
    if (!empty($branches_db)) {
        $old_branch_ids = array_map(fn($r) => (int)$r['id'], $branches_db);
        $old_branches   = array_map(fn($r) => (string)$r['name'], $branches_db);
        $old_qcounts    = array_map(fn($r) => (string)$r['question_count'], $branches_db);
    } else {
        $old_branch_ids = [0,0,0,0];
        $old_branches   = ['Türkçe', 'Sosyal Bilimler','Matematik','Fen Bilimleri'];
        $old_qcounts    = ['40','25','40','20'];
    }
}

if (!is_array($old_branch_ids)) $old_branch_ids = [];
if (!is_array($old_branches)) $old_branches = [];
if (!is_array($old_qcounts)) $old_qcounts = [];
if (empty($old_branches)) { $old_branches = ['']; $old_qcounts = ['']; $old_branch_ids = [0]; }
?>

<h2>Deneme Düzenle</h2>

<div class="text-right mb-2">
    <a href="exams.php" class="btn btn-secondary btn-sm">← Denemelere Dön</a>
</div>

<?php if (!empty($errors)): ?>
    <div style="background:#ffebee; padding:10px; border-radius:4px; margin-bottom:10px; color:#b71c1c;">
        <strong>Hata:</strong>
        <ul>
            <?php foreach ($errors as $e): ?>
                <li><?php echo htmlspecialchars($e); ?></li>
            <?php endforeach; ?>
        </ul>
        <div style="margin-top:8px; font-size:12px; opacity:.9;">
            Kural: Deneme adı/no/barkod güncellenince kazanımlar silinmez.
            Kitapçık sayısı değişirse tüm kazanımlar silinir.
            Branş silinirse / soru sayısı değişirse ilgili branşın kazanımları silinir.
        </div>
    </div>
<?php endif; ?>

<form method="post">
    <div class="row">
        <div class="col-4">
            <div class="form-group">
                <label>Deneme Adı</label>
                <input type="text" name="name" value="<?php echo htmlspecialchars($old_name); ?>">
            </div>
        </div>
        <div class="col-4">
            <div class="form-group">
                <label>Deneme Numarası</label>
                <input type="text" name="exam_number" value="<?php echo htmlspecialchars($old_exam_number); ?>">
            </div>
        </div>
        <div class="col-4">
            <div class="form-group">
                <label>Barkod</label>
                <input type="text" name="barcode" value="<?php echo htmlspecialchars($old_barcode); ?>">
            </div>
        </div>
    </div>

    <div class="row mt-3">
        <div class="col-4">
            <div class="form-group">
                <label>Kaç Farklı Kitapçık?</label>
                <input type="number" name="booklet_count" min="1" max="10" value="<?php echo htmlspecialchars($old_booklet_count); ?>">
                <div class="muted">Kitapçık sayısı değişirse: kitapçıklar hedef sayıya göre güncellenir ve kazanımlar silinir.</div>
            </div>
        </div>
    </div>

    <h3 class="mt-3">Denemedeki Branşlar</h3>

    <table class="table-sm" id="branches-table">
        <thead>
            <tr>
                <th>Branş Adı</th>
                <th>Soru Sayısı</th>
                <th style="width:60px;">Sil</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($old_branches as $i => $bname):
                $qcount = $old_qcounts[$i] ?? '';
                $bid = (int)($old_branch_ids[$i] ?? 0);
            ?>
            <tr>
                <td>
                    <input type="hidden" name="branch_id[]" value="<?php echo (int)$bid; ?>">
                    <input type="text" name="branch_name[]" value="<?php echo htmlspecialchars($bname); ?>">
                </td>
                <td><input type="number" name="branch_question_count[]" min="1" value="<?php echo htmlspecialchars($qcount); ?>"></td>
                <td class="text-center">
                    <button type="button" class="btn btn-danger btn-sm" onclick="removeBranchRow(this)">X</button>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <button type="button" class="btn btn-secondary btn-sm mt-2" onclick="addBranchRow()">+ Branş Ekle</button>

    <div class="mt-4 text-right">
        <button type="submit" class="btn btn-primary">Güncellemeyi Kaydet</button>
    </div>
</form>

<script>
function addBranchRow() {
    const tbody = document.querySelector('#branches-table tbody');
    const tr = document.createElement('tr');
    tr.innerHTML = `
        <td>
            <input type="hidden" name="branch_id[]" value="0">
            <input type="text" name="branch_name[]" value="">
        </td>
        <td><input type="number" name="branch_question_count[]" min="1" value=""></td>
        <td class="text-center"><button type="button" class="btn btn-danger btn-sm" onclick="removeBranchRow(this)">X</button></td>
    `;
    tbody.appendChild(tr);
}

// Bu satırı kaldırmak DB'den silme anlamına gelecek.
// Kaydet'te "DB'de olup formda olmayan branşlar" silinir ve o branşın kazanımları da silinir.
function removeBranchRow(btn) {
    const tr = btn.closest('tr');
    const tbody = tr.parentNode;
    if (tbody.children.length > 1) {
        tbody.removeChild(tr);
    } else {
        tr.querySelectorAll('input[type="text"], input[type="number"]').forEach(i => i.value = '');
        tr.querySelector('input[name="branch_id[]"]').value = '0';
    }
}
</script>

<?php include __DIR__ . '/admin_footer.php'; ?>
