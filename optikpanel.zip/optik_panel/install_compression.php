<?php
/**
 * Database Migration: Video Compression Settings
 * Bu dosyayı tarayıcıdan bir kez çalıştırın: http://yourdomain.com/optik_panel/install_compression.php
 * Başarılı olduktan sonra bu dosyayı silin!
 */

require_once __DIR__ . '/config.php';

// Admin kontrolü
require_login();
$user = current_user();
if (!$user || $user['role'] !== 'admin') {
    die('Bu işlem için admin yetkisi gereklidir.');
}

echo "<h2>Video Compression Ayarları Kurulumu</h2>";
echo "<p>Database migration başlatılıyor...</p>";

try {
    // 1. Kolonlar var mı kontrol et
    $check = $pdo->query("SHOW COLUMNS FROM admin_users LIKE 'video_compression_enabled'");
    $exists = $check->rowCount() > 0;
    
    if ($exists) {
        echo "<p style='color:orange'>⚠️ Kolonlar zaten mevcut. Migration atlanıyor.</p>";
    } else {
        echo "<p>✓ Kolonlar ekleniyor...</p>";
        
        // 2. Kolonları ekle
        $pdo->exec("
            ALTER TABLE admin_users 
            ADD COLUMN video_compression_enabled TINYINT(1) DEFAULT 1 COMMENT 'Video sıkıştırma aktif mi',
            ADD COLUMN video_compression_quality VARCHAR(10) DEFAULT 'medium' COMMENT 'Kalite: low, medium, high',
            ADD COLUMN video_compression_percentage INT DEFAULT 80 COMMENT 'Hedef sıkıştırma yüzdesi (50-90)'
        ");
        
        echo "<p style='color:green'>✓ Kolonlar başarıyla eklendi</p>";
        
        // 3. Mevcut kullanıcılar için default değerleri ayarla (KAPALI olarak)
        $pdo->exec("
            UPDATE admin_users 
            SET video_compression_enabled = 0,
                video_compression_quality = 'medium',
                video_compression_percentage = 80
            WHERE video_compression_enabled IS NULL
        ");
        
        echo "<p style='color:green'>✓ Varsayılan değerler ayarlandı (Compression kapalı - profilde açabilirsiniz)</p>";
        
        // 4. Index ekle
        $pdo->exec("
            ALTER TABLE admin_users 
            ADD INDEX idx_compression (video_compression_enabled)
        ");
        
        echo "<p style='color:green'>✓ Index eklendi</p>";
    }
    
    // 5. Kontrol et
    $userCount = $pdo->query("SELECT COUNT(*) FROM admin_users WHERE video_compression_enabled = 1")->fetchColumn();
    
    echo "<hr>";
    echo "<h3 style='color:green'>✅ Kurulum Başarılı!</h3>";
    echo "<p><strong>$userCount</strong> kullanıcı için video sıkıştırma etkinleştirildi.</p>";
    echo "<p>Şimdi yapmanız gerekenler:</p>";
    echo "<ol>";
    echo "<li>FFmpeg kurulumunu kontrol edin: <code>ffmpeg -version</code></li>";
    echo "<li>Kullanıcı düzenleme sayfasına gidin ve ayarları görüntüleyin</li>";
    echo "<li><strong style='color:red'>Bu dosyayı (install_compression.php) silin!</strong></li>";
    echo "</ol>";
    
    echo "<p><a href='users.php' style='background:#4CAF50;color:white;padding:10px 20px;text-decoration:none;border-radius:4px;display:inline-block;margin-top:10px;'>Kullanıcı Listesine Git</a></p>";
    
} catch (Exception $e) {
    echo "<p style='color:red'>❌ HATA: " . htmlspecialchars($e->getMessage()) . "</p>";
    echo "<p>Manuel olarak SQL çalıştırmanız gerekebilir:</p>";
    echo "<pre style='background:#f5f5f5;padding:15px;border-radius:4px;'>";
    echo htmlspecialchars("
ALTER TABLE admin_users 
ADD COLUMN video_compression_enabled TINYINT(1) DEFAULT 1,
ADD COLUMN video_compression_quality VARCHAR(10) DEFAULT 'medium',
ADD COLUMN video_compression_percentage INT DEFAULT 80;

UPDATE admin_users 
SET video_compression_enabled = 1,
    video_compression_quality = 'medium',
    video_compression_percentage = 80;

ALTER TABLE admin_users 
ADD INDEX idx_compression (video_compression_enabled);
    ");
    echo "</pre>";
}
?>
