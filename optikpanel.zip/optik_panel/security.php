<?php
/**
 * Güvenlik Modülü - CSRF, Rate Limiting, Session Hijacking Koruması
 * 
 * Bu modül projenin güvenlik katmanını sağlar.
 */

declare(strict_types=1);

// ----------------- CSRF Koruması -----------------

/**
 * CSRF token oluştur
 */
function csrf_token(): string {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return (string)$_SESSION['csrf_token'];
}

/**
 * CSRF token doğrula
 */
function csrf_validate(?string $token): bool {
    return is_string($token) && 
           !empty($_SESSION['csrf_token']) && 
           hash_equals($_SESSION['csrf_token'], $token);
}

/**
 * API için CSRF kontrolü - başarısız olursa exit eder
 */
function require_csrf_api(): void {
    $token = $_POST['csrf_token'] ?? $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
    
    if (!csrf_validate($token)) {
        http_response_code(403);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode([
            'success' => false, 
            'message' => 'Güvenlik doğrulaması başarısız. Sayfayı yenileyin.'
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }
}

// ----------------- Rate Limiting -----------------

/**
 * Rate limit kontrolü
 * 
 * @param string $key Unique key (örn: 'login_' . $ip)
 * @param int $maxAttempts Maksimum deneme sayısı
 * @param int $windowSeconds Zaman penceresi (saniye)
 * @return bool True = izin ver, False = engelle
 */
function check_rate_limit(string $key, int $maxAttempts = 5, int $windowSeconds = 300): bool {
    $cacheKey = 'rate_limit_' . $key;
    
    // Mevcut veriyi al
    $data = $_SESSION[$cacheKey] ?? null;
    $now = time();
    
    // İlk deneme veya zaman aşımı
    if (!$data || ($now - (int)$data['first_attempt']) > $windowSeconds) {
        $_SESSION[$cacheKey] = [
            'count' => 1,
            'first_attempt' => $now,
            'last_attempt' => $now
        ];
        return true;
    }
    
    // Limit aşıldı mı?
    if ((int)$data['count'] >= $maxAttempts) {
        $remaining = $windowSeconds - ($now - (int)$data['first_attempt']);
        $_SESSION[$cacheKey]['blocked_until'] = $now + $remaining;
        return false;
    }
    
    // Sayacı artır
    $_SESSION[$cacheKey]['count']++;
    $_SESSION[$cacheKey]['last_attempt'] = $now;
    
    return true;
}

/**
 * Rate limit kalan süreyi getir (saniye)
 */
function get_rate_limit_remaining(string $key): int {
    $cacheKey = 'rate_limit_' . $key;
    $data = $_SESSION[$cacheKey] ?? null;
    
    if (!$data || empty($data['blocked_until'])) {
        return 0;
    }
    
    $remaining = (int)$data['blocked_until'] - time();
    return max(0, $remaining);
}

/**
 * Rate limit sıfırla (başarılı işlemde)
 */
function reset_rate_limit(string $key): void {
    $cacheKey = 'rate_limit_' . $key;
    unset($_SESSION[$cacheKey]);
}

// ----------------- Session Hijacking Koruması -----------------

/**
 * Session'ı doğrula (hijacking kontrolü)
 */
function validate_session(): bool {
    // IP adresi kontrolü (opsiyonel - proxy kullanımında sorun olabilir)
    // Strict mod için açılabilir
    $checkIp = false; // config'den alınabilir
    
    if ($checkIp) {
        $currentIp = client_ip_address();
        if (isset($_SESSION['_security']['ip']) && $_SESSION['_security']['ip'] !== $currentIp) {
            return false;
        }
        $_SESSION['_security']['ip'] = $currentIp;
    }
    
    // User Agent kontrolü
    $currentUA = client_user_agent();
    if (isset($_SESSION['_security']['ua']) && $_SESSION['_security']['ua'] !== $currentUA) {
        return false;
    }
    $_SESSION['_security']['ua'] = $currentUA;
    
    // Session timeout kontrolü (30 dakika)
    $timeout = 1800; // 30 dakika
    if (isset($_SESSION['_security']['last_activity'])) {
        if (time() - $_SESSION['_security']['last_activity'] > $timeout) {
            return false;
        }
    }
    $_SESSION['_security']['last_activity'] = time();
    
    // Session başlangıç zamanı (maksimum 24 saat)
    $maxLifetime = 86400; // 24 saat
    if (!isset($_SESSION['_security']['created_at'])) {
        $_SESSION['_security']['created_at'] = time();
    } elseif (time() - $_SESSION['_security']['created_at'] > $maxLifetime) {
        return false;
    }
    
    return true;
}

/**
 * Session güvenlik verilerini başlat
 */
function init_session_security(): void {
    if (!isset($_SESSION['_security'])) {
        $_SESSION['_security'] = [
            'ip' => client_ip_address(),
            'ua' => client_user_agent(),
            'created_at' => time(),
            'last_activity' => time()
        ];
    }
}

// ----------------- Dosya Upload Güvenliği -----------------

/**
 * Video dosyasını güvenli şekilde doğrula
 * 
 * @param array $file $_FILES array element
 * @return array ['success' => bool, 'message' => string]
 */
function validate_video_upload(array $file): array {
    // Dosya var mı?
    if (empty($file) || !is_uploaded_file($file['tmp_name'])) {
        return ['success' => false, 'message' => 'Dosya bulunamadı.'];
    }
    
    // Upload hatası var mı?
    if (!empty($file['error'])) {
        return ['success' => false, 'message' => 'Yükleme hatası: ' . (int)$file['error']];
    }
    
    // Dosya boyutu kontrolü (200MB)
    $maxBytes = 200 * 1024 * 1024;
    if ((int)$file['size'] > $maxBytes) {
        return ['success' => false, 'message' => 'Dosya boyutu çok büyük (max 200MB).'];
    }
    
    // Minimum boyut kontrolü (boş dosya)
    if ((int)$file['size'] < 1024) {
        return ['success' => false, 'message' => 'Dosya çok küçük veya boş.'];
    }
    
    // Uzantı kontrolü
    $allowedExt = ['mp4', 'webm', 'mov'];
    $origName = (string)($file['name'] ?? '');
    $ext = strtolower(pathinfo($origName, PATHINFO_EXTENSION));
    
    if (!in_array($ext, $allowedExt, true)) {
        return ['success' => false, 'message' => 'Desteklenmeyen format. (mp4/webm/mov)'];
    }
    
    // MIME type kontrolü
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mimeType = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);
    
    $allowedMimes = ['video/mp4', 'video/webm', 'video/quicktime'];
    if (!in_array($mimeType, $allowedMimes, true)) {
        return ['success' => false, 'message' => 'Geçersiz video formatı (MIME check).'];
    }
    
    // Video header kontrolü (magic bytes)
    $handle = fopen($file['tmp_name'], 'rb');
    if ($handle === false) {
        return ['success' => false, 'message' => 'Dosya okunamadı.'];
    }
    
    $header = fread($handle, 12);
    fclose($handle);
    
    // MP4: contains 'ftyp' in first 12 bytes
    // WebM: starts with 0x1A 0x45 0xDF 0xA3
    $isValidVideo = false;
    
    if (strpos($header, 'ftyp') !== false) {
        $isValidVideo = true; // MP4
    } elseif (substr($header, 0, 4) === "\x1A\x45\xDF\xA3") {
        $isValidVideo = true; // WebM
    } elseif (strpos($header, 'moov') !== false || strpos($header, 'mdat') !== false) {
        $isValidVideo = true; // MOV
    }
    
    if (!$isValidVideo) {
        return ['success' => false, 'message' => 'Dosya geçerli bir video değil.'];
    }
    
    return ['success' => true, 'message' => 'OK', 'extension' => $ext];
}

/**
 * Güvenli dosya adı oluştur
 */
function generate_safe_filename(string $prefix = '', string $extension = 'mp4'): string {
    $random = bin2hex(random_bytes(16));
    $timestamp = time();
    
    if ($prefix !== '') {
        return $prefix . '_' . $timestamp . '_' . $random . '.' . $extension;
    }
    
    return $timestamp . '_' . $random . '.' . $extension;
}

// ----------------- Input Validation -----------------

/**
 * Integer ID doğrulama
 */
function validate_id($value, string $name = 'ID'): int {
    $id = filter_var($value, FILTER_VALIDATE_INT);
    if ($id === false || $id <= 0) {
        throw new InvalidArgumentException("Geçersiz {$name}");
    }
    return $id;
}

/**
 * String sanitization
 */
function sanitize_string(string $value, int $maxLength = 255): string {
    $value = trim($value);
    $value = strip_tags($value);
    if (strlen($value) > $maxLength) {
        $value = substr($value, 0, $maxLength);
    }
    return $value;
}

/**
 * Email validation
 */
function validate_email(string $email): bool {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

// ----------------- Error Logging -----------------

/**
 * Güvenlik olayını logla
 */
function log_security_event(string $type, string $message, array $context = []): void {
    $logDir = __DIR__ . '/logs';
    $logFile = $logDir . '/security.log';
    
    // Dizin yoksa oluştur
    if (!is_dir($logDir)) {
        @mkdir($logDir, 0755, true);
    }
    
    $entry = [
        'timestamp' => date('Y-m-d H:i:s'),
        'type' => $type,
        'message' => $message,
        'context' => $context,
        'ip' => client_ip_address(),
        'user_agent' => client_user_agent(),
        'user_id' => $_SESSION['optik_admin_user_id'] ?? null,
        'url' => $_SERVER['REQUEST_URI'] ?? '',
        'method' => $_SERVER['REQUEST_METHOD'] ?? ''
    ];
    
    $line = json_encode($entry, JSON_UNESCAPED_UNICODE) . "\n";
    @file_put_contents($logFile, $line, FILE_APPEND | LOCK_EX);
}

/**
 * Genel hata logla
 */
function log_error(string $message, array $context = []): void {
    $logDir = __DIR__ . '/logs';
    $logFile = $logDir . '/error.log';
    
    if (!is_dir($logDir)) {
        @mkdir($logDir, 0755, true);
    }
    
    $entry = [
        'timestamp' => date('Y-m-d H:i:s'),
        'message' => $message,
        'context' => $context,
        'ip' => client_ip_address(),
        'user_id' => $_SESSION['optik_admin_user_id'] ?? null,
        'url' => $_SERVER['REQUEST_URI'] ?? ''
    ];
    
    $line = json_encode($entry, JSON_UNESCAPED_UNICODE) . "\n";
    @file_put_contents($logFile, $line, FILE_APPEND | LOCK_EX);
}

// ----------------- Helper Functions -----------------

/**
 * Client IP adresi (config.php'deki ile aynı)
 */
if (!function_exists('client_ip_address')) {
    function client_ip_address(): string {
        return (string)($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0');
    }
}

/**
 * Client User Agent (config.php'deki ile aynı)
 */
if (!function_exists('client_user_agent')) {
    function client_user_agent(): string {
        $ua = (string)($_SERVER['HTTP_USER_AGENT'] ?? '');
        if (strlen($ua) > 255) {
            $ua = substr($ua, 0, 255);
        }
        return $ua;
    }
}
