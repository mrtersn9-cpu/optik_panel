<?php
ob_start();
require_once __DIR__ . '/admin_header.php';

function h($s): string { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

// ---- Tarih filtreleri ----
$today = new DateTime('now');
$defaultStart = (clone $today)->modify('-30 days')->format('Y-m-d');
$defaultEnd   = $today->format('Y-m-d');

$start = isset($_GET['start']) ? trim((string)$_GET['start']) : $defaultStart;
$end   = isset($_GET['end']) ? trim((string)$_GET['end']) : $defaultEnd;
$examFilter = isset($_GET['exam_id']) ? (int)$_GET['exam_id'] : 0;

if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $start)) $start = $defaultStart;
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $end))   $end   = $defaultEnd;

$startDT = $start . ' 00:00:00';
$endDT   = $end . ' 23:59:59';

// ---- Deneme listesi ----
$exams = [];
try {
    $st = $pdo->query("SELECT id, name FROM exams ORDER BY id DESC");
    $exams = $st->fetchAll();
} catch (Throwable $e) {
    $exams = [];
}

$examTitle = "Tümü";
if ($examFilter > 0) {
    foreach ($exams as $ex) {
        if ((int)$ex['id'] === $examFilter) {
            $examTitle = "#" . (int)$ex['id'] . " - " . (string)$ex['name'];
            break;
        }
    }
}

/**
 * AJAX (modal / datatable)
 * - action=recent_views
 * - action=top_exams
 */
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['ajax']) && $_GET['ajax'] === '1' && isset($_GET['action'])) {
    ob_clean();
    header('Content-Type: application/json; charset=utf-8');

    $action = (string)$_GET['action'];

    $qsStart = isset($_GET['start']) ? (string)$_GET['start'] : $start;
    $qsEnd   = isset($_GET['end']) ? (string)$_GET['end'] : $end;
    $qsExam  = isset($_GET['exam_id']) ? (int)$_GET['exam_id'] : $examFilter;

    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $qsStart)) $qsStart = $start;
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $qsEnd))   $qsEnd   = $end;

    $qsStartDT = $qsStart . ' 00:00:00';
    $qsEndDT   = $qsEnd   . ' 23:59:59';

    try {
        if ($action === 'recent_views') {
            if ($qsExam > 0) {
                $st = $pdo->prepare("
                    SELECT v.completed_at, e.name AS exam_name, v.ip_address
                    FROM exam_view_logs v
                    JOIN exams e ON e.id = v.exam_id
                    WHERE v.exam_id = ? AND v.completed_at BETWEEN ? AND ?
                    ORDER BY v.completed_at DESC
                ");
                $st->execute([$qsExam, $qsStartDT, $qsEndDT]);
            } else {
                $st = $pdo->prepare("
                    SELECT v.completed_at, e.name AS exam_name, v.ip_address
                    FROM exam_view_logs v
                    JOIN exams e ON e.id = v.exam_id
                    WHERE v.completed_at BETWEEN ? AND ?
                    ORDER BY v.completed_at DESC
                ");
                $st->execute([$qsStartDT, $qsEndDT]);
            }
            echo json_encode(['success' => true, 'rows' => $st->fetchAll()], JSON_UNESCAPED_UNICODE);
            exit;
        }

        if ($action === 'top_exams') {
            if ($qsExam > 0) {
                $st = $pdo->prepare("
                    SELECT e.name AS exam_name, COUNT(*) AS cnt
                    FROM exam_view_logs v
                    JOIN exams e ON e.id = v.exam_id
                    WHERE v.exam_id = ? AND v.completed_at BETWEEN ? AND ?
                    GROUP BY e.name
                    ORDER BY cnt DESC
                ");
                $st->execute([$qsExam, $qsStartDT, $qsEndDT]);
            } else {
                $st = $pdo->prepare("
                    SELECT e.name AS exam_name, COUNT(*) AS cnt
                    FROM exam_view_logs v
                    JOIN exams e ON e.id = v.exam_id
                    WHERE v.completed_at BETWEEN ? AND ?
                    GROUP BY e.id, e.name
                    ORDER BY cnt DESC
                ");
                $st->execute([$qsStartDT, $qsEndDT]);
            }
            echo json_encode(['success' => true, 'rows' => $st->fetchAll()], JSON_UNESCAPED_UNICODE);
            exit;
        }

        echo json_encode(['success' => false, 'message' => 'Geçersiz action.'], JSON_UNESCAPED_UNICODE);
        exit;

    } catch (Throwable $e) {
        echo json_encode(['success' => false, 'message' => 'Veri alınamadı.'], JSON_UNESCAPED_UNICODE);
        exit;
    }
}

// ---- Özet + Grafikler ----
$tablesOk = true;
$tablesMsg = '';

$viewCount = 0;
$uniqueViewIPs = 0;

$topViewedExams_10 = [];
$recentViews_10 = [];

$dailyTotalViews = [];
$dailyUniqueViews = [];
$dailyNewUniqueViews = [];

try {
    if ($examFilter > 0) {
        // Toplam / tekil ip
        $st = $pdo->prepare("SELECT COUNT(*) FROM exam_view_logs WHERE exam_id = ? AND completed_at BETWEEN ? AND ?");
        $st->execute([$examFilter, $startDT, $endDT]);
        $viewCount = (int)$st->fetchColumn();

        $st = $pdo->prepare("SELECT COUNT(DISTINCT ip_address) FROM exam_view_logs WHERE exam_id = ? AND completed_at BETWEEN ? AND ?");
        $st->execute([$examFilter, $startDT, $endDT]);
        $uniqueViewIPs = (int)$st->fetchColumn();

        // Top 10 deneme (filtreli ise tek deneme görünebilir, yine de kalsın)
        $st = $pdo->prepare("
            SELECT e.name AS exam_name, COUNT(*) AS cnt
            FROM exam_view_logs v
            JOIN exams e ON e.id = v.exam_id
            WHERE v.exam_id = ? AND v.completed_at BETWEEN ? AND ?
            GROUP BY e.name
            ORDER BY cnt DESC
            LIMIT 10
        ");
        $st->execute([$examFilter, $startDT, $endDT]);
        $topViewedExams_10 = $st->fetchAll();

        // Son 10
        $st = $pdo->prepare("
            SELECT v.completed_at, e.name AS exam_name, v.ip_address
            FROM exam_view_logs v
            JOIN exams e ON e.id = v.exam_id
            WHERE v.exam_id = ? AND v.completed_at BETWEEN ? AND ?
            ORDER BY v.completed_at DESC
            LIMIT 10
        ");
        $st->execute([$examFilter, $startDT, $endDT]);
        $recentViews_10 = $st->fetchAll();

        // Günlük toplam (SUBSTR fix)
        $st = $pdo->prepare("
            SELECT SUBSTR(completed_at,1,10) AS d, COUNT(*) AS cnt
            FROM exam_view_logs
            WHERE exam_id = ? AND completed_at BETWEEN ? AND ?
            GROUP BY SUBSTR(completed_at,1,10)
            ORDER BY d ASC
        ");
        $st->execute([$examFilter, $startDT, $endDT]);
        foreach ($st->fetchAll() as $r) {
            $dailyTotalViews[(string)$r['d']] = (int)$r['cnt'];
        }

        // Günlük tekil IP (SUBSTR fix)
        $st = $pdo->prepare("
            SELECT SUBSTR(completed_at,1,10) AS d, COUNT(DISTINCT ip_address) AS cnt
            FROM exam_view_logs
            WHERE exam_id = ? AND completed_at BETWEEN ? AND ?
            GROUP BY SUBSTR(completed_at,1,10)
            ORDER BY d ASC
        ");
        $st->execute([$examFilter, $startDT, $endDT]);
        foreach ($st->fetchAll() as $r) {
            $dailyUniqueViews[(string)$r['d']] = (int)$r['cnt'];
        }

        // Günlük yeni okutma (SUBSTR fix)
        $st = $pdo->prepare("
            SELECT SUBSTR(first_time,1,10) AS d, COUNT(*) AS cnt
            FROM (
                SELECT ip_address, MIN(completed_at) AS first_time
                FROM exam_view_logs
                WHERE exam_id = ?
                GROUP BY ip_address
            ) t
            WHERE first_time BETWEEN ? AND ?
            GROUP BY SUBSTR(first_time,1,10)
            ORDER BY d ASC
        ");
        $st->execute([$examFilter, $startDT, $endDT]);
        foreach ($st->fetchAll() as $r) {
            $dailyNewUniqueViews[(string)$r['d']] = (int)$r['cnt'];
        }

    } else {
        // Toplam / tekil ip
        $st = $pdo->prepare("SELECT COUNT(*) FROM exam_view_logs WHERE completed_at BETWEEN ? AND ?");
        $st->execute([$startDT, $endDT]);
        $viewCount = (int)$st->fetchColumn();

        $st = $pdo->prepare("SELECT COUNT(DISTINCT ip_address) FROM exam_view_logs WHERE completed_at BETWEEN ? AND ?");
        $st->execute([$startDT, $endDT]);
        $uniqueViewIPs = (int)$st->fetchColumn();

        // Top 10 deneme
        $st = $pdo->prepare("
            SELECT e.name AS exam_name, COUNT(*) AS cnt
            FROM exam_view_logs v
            JOIN exams e ON e.id = v.exam_id
            WHERE v.completed_at BETWEEN ? AND ?
            GROUP BY e.id, e.name
            ORDER BY cnt DESC
            LIMIT 10
        ");
        $st->execute([$startDT, $endDT]);
        $topViewedExams_10 = $st->fetchAll();

        // Son 10
        $st = $pdo->prepare("
            SELECT v.completed_at, e.name AS exam_name, v.ip_address
            FROM exam_view_logs v
            JOIN exams e ON e.id = v.exam_id
            WHERE v.completed_at BETWEEN ? AND ?
            ORDER BY v.completed_at DESC
            LIMIT 10
        ");
        $st->execute([$startDT, $endDT]);
        $recentViews_10 = $st->fetchAll();

        // Günlük toplam (SUBSTR fix)
        $st = $pdo->prepare("
            SELECT SUBSTR(completed_at,1,10) AS d, COUNT(*) AS cnt
            FROM exam_view_logs
            WHERE completed_at BETWEEN ? AND ?
            GROUP BY SUBSTR(completed_at,1,10)
            ORDER BY d ASC
        ");
        $st->execute([$startDT, $endDT]);
        foreach ($st->fetchAll() as $r) {
            $dailyTotalViews[(string)$r['d']] = (int)$r['cnt'];
        }

        // Günlük tekil IP (SUBSTR fix)
        $st = $pdo->prepare("
            SELECT SUBSTR(completed_at,1,10) AS d, COUNT(DISTINCT ip_address) AS cnt
            FROM exam_view_logs
            WHERE completed_at BETWEEN ? AND ?
            GROUP BY SUBSTR(completed_at,1,10)
            ORDER BY d ASC
        ");
        $st->execute([$startDT, $endDT]);
        foreach ($st->fetchAll() as $r) {
            $dailyUniqueViews[(string)$r['d']] = (int)$r['cnt'];
        }

        // Günlük yeni okutma (genel) (SUBSTR fix)
        $st = $pdo->prepare("
            SELECT SUBSTR(first_time,1,10) AS d, COUNT(*) AS cnt
            FROM (
                SELECT ip_address, MIN(completed_at) AS first_time
                FROM exam_view_logs
                GROUP BY ip_address
            ) t
            WHERE first_time BETWEEN ? AND ?
            GROUP BY SUBSTR(first_time,1,10)
            ORDER BY d ASC
        ");
        $st->execute([$startDT, $endDT]);
        foreach ($st->fetchAll() as $r) {
            $dailyNewUniqueViews[(string)$r['d']] = (int)$r['cnt'];
        }
    }

} catch (Throwable $e) {
    $tablesOk = false;
    $tablesMsg = 'Analytics tabloları okunamadı. (exam_view_logs / exams)';
}

// Label listesi (start-end arası tüm günler)
$labels = [];
$cursor = new DateTime($start);
$endObj = new DateTime($end);
while ($cursor <= $endObj) {
    $labels[] = $cursor->format('Y-m-d');
    $cursor->modify('+1 day');
}

// Grafik serileri (label ile eşle)
$seriesDailyTotal = [];
$seriesDailyUnique = [];
$seriesDailyNew = [];
foreach ($labels as $d) {
    $seriesDailyTotal[]  = isset($dailyTotalViews[$d]) ? (int)$dailyTotalViews[$d] : 0;
    $seriesDailyUnique[] = isset($dailyUniqueViews[$d]) ? (int)$dailyUniqueViews[$d] : 0;
    $seriesDailyNew[]    = isset($dailyNewUniqueViews[$d]) ? (int)$dailyNewUniqueViews[$d] : 0;
}
?>

<style>
.analytics-shell{
    max-width:1200px;margin:6px auto 26px;padding:16px;border-radius:18px;
    background:
        radial-gradient(1200px 500px at 10% 0%, rgba(99,102,241,.18), transparent 60%),
        radial-gradient(900px 480px at 90% 10%, rgba(34,211,238,.14), transparent 60%),
        radial-gradient(900px 520px at 60% 100%, rgba(244,114,182,.12), transparent 60%),
        linear-gradient(180deg, #ffffff 0%, #fbfbff 100%);
    border:1px solid #e5e7eb;box-shadow:0 10px 28px rgba(17,24,39,.08);color:#111827;
}
.h1{margin:0;font-size:22px;letter-spacing:.2px;font-weight:900;}
.sub{margin-top:6px;color:#6b7280;font-size:13px;}
.form-grid{margin-top:14px;display:grid;grid-template-columns:1fr 1fr 1.4fr;gap:12px;}
@media (max-width:980px){.form-grid{grid-template-columns:1fr;}}
.form-group label{color:#374151;font-size:12px;margin-bottom:6px;display:block;font-weight:700;}
.form-group input,.form-group select{width:100%;padding:10px 12px;border-radius:12px;border:1px solid #e5e7eb;background:#fff;color:#111827;outline:none;box-sizing:border-box;}
.btnrow{display:flex;gap:10px;margin-top:10px;flex-wrap:wrap;}
.btnrow .btn{border-radius:12px;}
.note{color:#6b7280;font-size:12px;margin-top:8px;}
.grid-3{display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px;margin-top:14px;}
@media (max-width:980px){.grid-3{grid-template-columns:1fr;}}
.kpi{border-radius:16px;padding:14px;border:1px solid #e5e7eb;background:rgba(255,255,255,.75);box-shadow:0 8px 18px rgba(17,24,39,.06);overflow:hidden;position:relative;}
.kpi:before{content:"";position:absolute;inset:-2px;background:
        radial-gradient(400px 120px at 20% 0%, rgba(99,102,241,.18), transparent 60%),
        radial-gradient(400px 120px at 80% 20%, rgba(34,211,238,.14), transparent 60%);pointer-events:none;}
.kpi .inner{position:relative;z-index:1;}
.kpi .lbl{color:#374151;font-size:12px;font-weight:800;}
.kpi .val{font-size:30px;font-weight:950;margin-top:6px;}
.kpi .hint{color:#6b7280;font-size:12px;margin-top:6px;}
.card{border-radius:16px;border:1px solid #e5e7eb;background:rgba(255,255,255,.80);box-shadow:0 8px 18px rgba(17,24,39,.06);overflow:hidden;margin-top:12px;}
.card-h{padding:12px 14px;border-bottom:1px solid #eef2f7;display:flex;align-items:center;justify-content:space-between;gap:10px;}
.card-title{font-weight:950;letter-spacing:.2px;}
.card-actions{display:flex;gap:8px;align-items:center;flex-wrap:wrap;}
.badge{padding:6px 10px;border-radius:999px;background:#f3f4f6;border:1px solid #e5e7eb;color:#374151;font-size:12px;font-weight:700;}
.btn-mini{padding:6px 10px;border-radius:10px;border:1px solid #e5e7eb;background:#fff;cursor:pointer;font-size:12px;font-weight:800;}
.btn-mini:hover{background:#f9fafb;}
.card-b{padding:12px 14px;}
.canvas{height:320px;}
.table-light{width:100%;border-collapse:separate;border-spacing:0;overflow:hidden;border-radius:12px;border:1px solid #e5e7eb;background:#fff;}
.table-light thead th{background:#f8fafc;color:#111827;font-size:12px;text-align:left;padding:10px 10px;border-bottom:1px solid #e5e7eb;font-weight:900;}
.table-light td{padding:10px 10px;color:#111827;border-bottom:1px solid #f1f5f9;font-size:13px;}
.table-light tr:last-child td{border-bottom:none;}
.small-muted{color:#6b7280;font-size:12px;}
.alert-warn{margin-top:12px;padding:12px 14px;border-radius:14px;background:#fffbeb;border:1px solid #fde68a;color:#92400e;}
/* Modal */
.modal-backdrop{display:none;position:fixed;inset:0;background:rgba(17,24,39,.45);z-index:9990;}
.modal{display:none;position:fixed;inset:6% 50% auto 50%;transform:translateX(-50%);width:min(1100px,calc(100% - 28px));max-height:88%;overflow:hidden;border-radius:16px;background:#fff;border:1px solid #e5e7eb;box-shadow:0 20px 60px rgba(17,24,39,.25);z-index:9991;}
.modal-h{padding:12px 14px;border-bottom:1px solid #eef2f7;display:flex;justify-content:space-between;align-items:center;gap:10px;}
.modal-title{font-weight:950;}
.modal-close{border:1px solid #e5e7eb;background:#fff;border-radius:10px;padding:6px 10px;cursor:pointer;font-weight:900;}
.modal-b{padding:12px 14px;overflow:auto;max-height:calc(88vh - 60px);}
.dataTables_wrapper .dataTables_filter input{border:1px solid #e5e7eb !important;border-radius:10px !important;padding:6px 10px !important;outline:none !important;}
.dataTables_wrapper .dataTables_length select{border:1px solid #e5e7eb !important;border-radius:10px !important;padding:4px 8px !important;}
</style>

<div class="analytics-shell">
    <div>
        <div class="h1">Analytics</div>
        <div class="sub">
            Aralık: <strong><?php echo h($start); ?></strong> – <strong><?php echo h($end); ?></strong>
            &nbsp;•&nbsp; Deneme: <strong><?php echo h($examTitle); ?></strong>
        </div>
    </div>

    <form method="get">
        <div class="form-grid">
            <div class="form-group">
                <label>Başlangıç</label>
                <input type="date" name="start" value="<?php echo h($start); ?>">
            </div>
            <div class="form-group">
                <label>Bitiş</label>
                <input type="date" name="end" value="<?php echo h($end); ?>">
            </div>
            <div class="form-group">
                <label>Deneme (opsiyonel)</label>
                <select name="exam_id">
                    <option value="0">Tümü</option>
                    <?php foreach ($exams as $ex): ?>
                        <option value="<?php echo (int)$ex['id']; ?>" <?php echo ($examFilter === (int)$ex['id']) ? 'selected' : ''; ?>>
                            #<?php echo (int)$ex['id']; ?> - <?php echo h($ex['name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>
        <div class="btnrow">
            <button type="submit" class="btn btn-primary">Filtrele</button>
            <a class="btn btn-secondary" href="analytics.php">Sıfırla</a>
        </div>
        <div class="note">
            “Günlük yeni okutma”: IP’nin seçili deneme için <strong>ilk</strong> okutma günü sayılır (eski okutmaları tekrar saymaz).
        </div>
    </form>

    <?php if (!$tablesOk): ?>
        <div class="alert-warn">
            <strong>Uyarı:</strong> <?php echo h($tablesMsg); ?>
        </div>
    <?php endif; ?>

    <div class="grid-3">
        <div class="kpi"><div class="inner">
            <div class="lbl">Toplam okutma (kayıt)</div>
            <div class="val"><?php echo (int)$viewCount; ?></div>
            <div class="hint">Seçili tarih aralığındaki tüm kayıtlar</div>
        </div></div>

        <div class="kpi"><div class="inner">
            <div class="lbl">Tekil IP okutma</div>
            <div class="val"><?php echo (int)$uniqueViewIPs; ?></div>
            <div class="hint">Seçili aralıkta benzersiz IP</div>
        </div></div>

        <div class="kpi"><div class="inner">
            <div class="lbl">Deneme filtresi</div>
            <div class="val" style="font-size:18px;font-weight:950;margin-top:10px;"><?php echo h($examTitle); ?></div>
            <div class="hint">Tümü veya tek deneme</div>
        </div></div>
    </div>

    <div class="card">
        <div class="card-h">
            <div class="card-title">Günlük Okutma</div>
            <div class="card-actions"><span class="badge">Toplam (kayıt) + Tekil IP</span></div>
        </div>
        <div class="card-b">
            <div class="canvas"><canvas id="chartDailyTotalVsUnique"></canvas></div>
            <div class="small-muted" style="margin-top:8px;">Toplam = kayıt sayısı, Tekil IP = aynı gün aynı IP 1 sayılır.</div>
        </div>
    </div>

    <div class="card">
        <div class="card-h">
            <div class="card-title">Günlük Yeni Okutma</div>
            <div class="card-actions"><span class="badge">İlk okutma günü</span></div>
        </div>
        <div class="card-b">
            <div class="canvas"><canvas id="chartDailyNew"></canvas></div>
            <div class="small-muted" style="margin-top:8px;">IP daha önce okuttuysa, sonraki günlerde “yeni” sayılmaz.</div>
        </div>
    </div>

    <div class="card">
        <div class="card-h">
            <div class="card-title">En çok okutulan denemeler (Son 10)</div>
            <div class="card-actions">
                <button class="btn-mini" type="button" onclick="openDataModal('top_exams')">Tümünü Gör</button>
            </div>
        </div>
        <div class="card-b">
            <table class="table-light">
                <thead><tr><th>Deneme</th><th style="width:120px;">Okutma</th></tr></thead>
                <tbody>
                <?php if (!$topViewedExams_10): ?>
                    <tr><td colspan="2" class="small-muted">Kayıt yok.</td></tr>
                <?php else: foreach ($topViewedExams_10 as $r): ?>
                    <tr><td><?php echo h($r['exam_name']); ?></td><td><?php echo (int)$r['cnt']; ?></td></tr>
                <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="card">
        <div class="card-h">
            <div class="card-title">Son optik okutmalar (Son 10)</div>
            <div class="card-actions">
                <button class="btn-mini" type="button" onclick="openDataModal('recent_views')">Tümünü Gör</button>
            </div>
        </div>
        <div class="card-b">
            <table class="table-light">
                <thead><tr><th>Zaman</th><th>Deneme</th><th>IP</th></tr></thead>
                <tbody>
                <?php if (!$recentViews_10): ?>
                    <tr><td colspan="3" class="small-muted">Kayıt yok.</td></tr>
                <?php else: foreach ($recentViews_10 as $r): ?>
                    <tr>
                        <td><?php echo h($r['completed_at']); ?></td>
                        <td><?php echo h($r['exam_name']); ?></td>
                        <td><?php echo h($r['ip_address']); ?></td>
                    </tr>
                <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modal -->
<div id="modalBackdrop" class="modal-backdrop" onclick="closeDataModal()"></div>
<div id="dataModal" class="modal" role="dialog" aria-modal="true">
    <div class="modal-h">
        <div class="modal-title" id="modalTitle">Detay</div>
        <button class="modal-close" type="button" onclick="closeDataModal()">Kapat</button>
    </div>
    <div class="modal-b">
        <table id="dtTable" class="display" style="width:100%"></table>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.8/css/jquery.dataTables.min.css">
<script src="https://cdn.datatables.net/1.13.8/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>

<script>
(function(){
    const labels = <?php echo json_encode($labels, JSON_UNESCAPED_UNICODE); ?>;
    const dailyTotal  = <?php echo json_encode($seriesDailyTotal, JSON_UNESCAPED_UNICODE); ?>;
    const dailyUnique = <?php echo json_encode($seriesDailyUnique, JSON_UNESCAPED_UNICODE); ?>;
    const dailyNew    = <?php echo json_encode($seriesDailyNew, JSON_UNESCAPED_UNICODE); ?>;

    Chart.defaults.font.family = "ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, Arial";

    function gradient(ctx, area, c1, c2){
        const g = ctx.createLinearGradient(0, area.top, 0, area.bottom);
        g.addColorStop(0, c1);
        g.addColorStop(1, c2);
        return g;
    }

    // Günlük Okutma (Toplam vs Tekil)
    (function(){
        const el = document.getElementById('chartDailyTotalVsUnique');
        if(!el) return;

        new Chart(el, {
            type: 'line',
            data: {
                labels,
                datasets: [
                    { label: 'Toplam Okutma (Kayıt)', data: dailyTotal, borderWidth: 2, pointRadius: 2, tension: 0.28 },
                    { label: 'Tekil IP Okutma', data: dailyUnique, borderWidth: 2, pointRadius: 2, tension: 0.28 }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                interaction: { mode: 'index', intersect: false },
                scales: {
                    x: { ticks: { maxRotation: 0, autoSkip: true, maxTicksLimit: 10 } },
                    y: { beginAtZero: true, ticks: { precision: 0 } }
                }
            },
            plugins: [{
                id:'niceGrad',
                beforeDatasetsDraw(chart){
                    const {ctx, chartArea} = chart;
                    if(!chartArea) return;
                    chart.data.datasets[0].borderColor = "rgba(99,102,241,.95)";
                    chart.data.datasets[0].backgroundColor = gradient(ctx, chartArea, "rgba(99,102,241,.22)", "rgba(99,102,241,0)");
                    chart.data.datasets[0].fill = true;

                    chart.data.datasets[1].borderColor = "rgba(34,211,238,.95)";
                    chart.data.datasets[1].backgroundColor = gradient(ctx, chartArea, "rgba(34,211,238,.18)", "rgba(34,211,238,0)");
                    chart.data.datasets[1].fill = true;
                }
            }]
        });
    })();

    // Günlük Yeni Okutma
    (function(){
        const el = document.getElementById('chartDailyNew');
        if(!el) return;

        new Chart(el, {
            type: 'bar',
            data: {
                labels,
                datasets: [{
                    label: 'Günlük Yeni Okutma (Tekil IP)',
                    data: dailyNew,
                    borderWidth: 1,
                    borderColor: "rgba(244,114,182,.9)"
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    x: { ticks: { maxRotation: 0, autoSkip: true, maxTicksLimit: 10 } },
                    y: { beginAtZero: true, ticks: { precision: 0 } }
                }
            },
            plugins: [{
                id:'barGrad',
                beforeDatasetsDraw(chart){
                    const {ctx, chartArea} = chart;
                    if(!chartArea) return;
                    const g = ctx.createLinearGradient(0, chartArea.top, 0, chartArea.bottom);
                    g.addColorStop(0, "rgba(244,114,182,.45)");
                    g.addColorStop(1, "rgba(244,114,182,.12)");
                    chart.data.datasets[0].backgroundColor = g;
                    chart.data.datasets[0].borderRadius = 10;
                }
            }]
        });
    })();
})();
</script>

<script>
let dtInstance = null;

function openDataModal(type){
    const backdrop = document.getElementById('modalBackdrop');
    const modal = document.getElementById('dataModal');
    const title = document.getElementById('modalTitle');

    const params = new URLSearchParams(window.location.search);
    const start = params.get('start') || '<?php echo h($start); ?>';
    const end = params.get('end') || '<?php echo h($end); ?>';
    const exam_id = params.get('exam_id') || '<?php echo (int)$examFilter; ?>';

    title.textContent = (type === 'recent_views') ? 'Son Optik Okutmalar (Tümü)' : 'En Çok Okutulan Denemeler (Tümü)';

    backdrop.style.display = 'block';
    modal.style.display = 'block';

    if(dtInstance){
        dtInstance.destroy();
        $('#dtTable').empty();
        dtInstance = null;
    }

    const baseUrl = window.location.pathname;

    fetch(`${baseUrl}?ajax=1&action=${encodeURIComponent(type)}&start=${encodeURIComponent(start)}&end=${encodeURIComponent(end)}&exam_id=${encodeURIComponent(exam_id)}`)
        .then(async r => {
            const text = await r.text();
            try { return JSON.parse(text); }
            catch(e){ return {success:false, raw:text}; }
        })
        .then(j => {
            if(!j || !j.success){
                const raw = (j && j.raw) ? String(j.raw).slice(0, 300) : '';
                $('#dtTable').html('<thead><tr><th>Hata</th></tr></thead><tbody><tr><td>Veri alınamadı.' + (raw ? ('<br><small style="color:#6b7280">Yanıt: '+escapeHtml(raw)+'</small>') : '') + '</td></tr></tbody>');
                return;
            }

            if(type === 'recent_views'){
                $('#dtTable').html('<thead><tr><th>Zaman</th><th>Deneme</th><th>IP</th></tr></thead><tbody></tbody>');
                const tb = $('#dtTable tbody');
                j.rows.forEach(r => tb.append(`<tr><td>${escapeHtml(r.completed_at)}</td><td>${escapeHtml(r.exam_name)}</td><td>${escapeHtml(r.ip_address)}</td></tr>`));

                dtInstance = $('#dtTable').DataTable({
                    pageLength: 25,
                    order: [[0,'desc']],
                    language: { search: "Ara:", lengthMenu: "_MENU_ kayıt", info: "_TOTAL_ kayıttan _START_-_END_", paginate:{ previous:"‹", next:"›" } }
                });
            } else {
                $('#dtTable').html('<thead><tr><th>Deneme</th><th>Okutma</th></tr></thead><tbody></tbody>');
                const tb = $('#dtTable tbody');
                j.rows.forEach(r => tb.append(`<tr><td>${escapeHtml(r.exam_name)}</td><td>${Number(r.cnt||0)}</td></tr>`));

                dtInstance = $('#dtTable').DataTable({
                    pageLength: 25,
                    order: [[1,'desc']],
                    language: { search: "Ara:", lengthMenu: "_MENU_ kayıt", info: "_TOTAL_ kayıttan _START_-_END_", paginate:{ previous:"‹", next:"›" } }
                });
            }
        })
        .catch(() => {
            $('#dtTable').html('<thead><tr><th>Hata</th></tr></thead><tbody><tr><td>Veri alınamadı.</td></tr></tbody>');
        });
}

function closeDataModal(){
    document.getElementById('modalBackdrop').style.display = 'none';
    document.getElementById('dataModal').style.display = 'none';
}

function escapeHtml(s){
    return String(s ?? '').replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));
}
</script>

<?php require_once __DIR__ . '/admin_footer.php'; ?>
