#!/bin/bash
# Otomatik Exam Detail Güncelleme Scripti
# Video Link + Toplu İşlemler

echo "🚀 Exam Detail Güncelleme Başlıyor..."

cd /var/www/optik_panel

# Yedek al
cp exam_detail.php exam_detail.php.backup_$(date +%Y%m%d_%H%M%S)
echo "✅ Yedek alındı"

# Database migration
echo "📊 Database migration çalıştırılıyor..."
mysql -u root -p optik_panel_db < migrations/add_video_link.sql
echo "✅ Database güncellendi"

# API dosyalarını kopyala
cp api/save_video_link.php /var/www/optik_panel/api/
cp api/bulk_delete_videos.php /var/www/optik_panel/api/
chmod 644 /var/www/optik_panel/api/save_video_link.php
chmod 644 /var/www/optik_panel/api/bulk_delete_videos.php
echo "✅ API dosyaları eklendi"

echo ""
echo "⚠️  ÖNEMLİ: exam_detail.php dosyasını MANUEL güncellemen gerekiyor!"
echo ""
echo "Detaylar için: EXAM_DETAIL_GUNCELLEMELERI.md dosyasına bak"
echo ""
echo "Veya tam güncellenmiş exam_detail.php dosyasını ister misin? (y/n)"

