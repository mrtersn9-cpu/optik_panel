<?php
declare(strict_types=1);

require_once __DIR__ . '/admin_header.php';

// h() yoksa burada güvenli tanımla
if (!function_exists('h')) {
    function h($s): string {
        return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
    }
}

// Tek admin: ilk kullanıcıyı al
try {
    $st = $pdo->query("SELECT id, username, role, is_active, video_compression_enabled, video_compression_quality, video_compression_percentage, last_login_at FROM admin_users ORDER BY id ASC LIMIT 1");
    $st = $pdo->query("SELECT id, username, role, is_active, last_login_at FROM admin_users ORDER BY id ASC LIMIT 1");
    $user = $st->fetch(PDO::FETCH_ASSOC);
} catch (Throwable $e) {
    echo '<div class="card" style="max-width:980px;margin:22px auto;padding:18px;">';
    echo '<h2>Admin Kullanıcısı</h2>';
    echo '<div style="background:#fff1f2;border:1px solid #fecdd3;color:#b91c1c;padding:10px 12px;border-radius:10px;margin-top:10px;">';
    echo 'Kullanıcı bilgisi okunamadı. admin_users tablosu/kolonları kontrol edilmeli.';
    echo '</div></div>';
    require_once __DIR__ . '/admin_footer.php';
    exit;
}

if (!$user) {
    echo '<div class="card" style="max-width:980px;margin:22px auto;padding:18px;">';
    echo '<h2>Admin Kullanıcısı</h2>';
    echo '<div style="background:#fff1f2;border:1px solid #fecdd3;color:#b91c1c;padding:10px 12px;border-radius:10px;margin-top:10px;">';
    echo 'Sistemde admin kullanıcı kaydı bulunamadı.';
    echo '</div></div>';
    require_once __DIR__ . '/admin_footer.php';
    exit;
}

$success = null;
$error = null;

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    // CSRF
    $token = (string)($_POST['csrf_token'] ?? '');
    if (function_exists('csrf_validate') && !csrf_validate($token)) {
        $error = 'Güvenlik doğrulaması başarısız (CSRF).';
    } else {
        $newUsername = trim((string)($_POST['username'] ?? ''));

        $pass1 = (string)($_POST['password'] ?? '');
        $pass2 = (string)($_POST['password2'] ?? '');

        if ($newUsername === '') {
            $error = 'Kullanıcı adı boş olamaz.';
        } elseif ($pass1 !== '' && $pass1 !== $pass2) {
            $error = 'Şifreler eşleşmiyor.';
        } else {
            try {
                $pdo->beginTransaction();

                // Kullanıcı adını güncelle
                $upd = $pdo->prepare("UPDATE admin_users SET username=? WHERE id=?");
                $upd->execute([$newUsername, (int)$user['id']]);

                if ($pass1 !== '') {
                    $hash = password_hash($pass1, PASSWORD_DEFAULT);
                    $upd2 = $pdo->prepare("UPDATE admin_users SET password_hash=? WHERE id=?");
                    $upd2->execute([$hash, (int)$user['id']]);
                }

                $pdo->commit();

                // yeniden çek
                $st = $pdo->prepare("SELECT id, username, role, is_active, last_login_at FROM admin_users WHERE id=? LIMIT 1");
                $st->execute([(int)$user['id']]);
                $user = $st->fetch(PDO::FETCH_ASSOC);

                $success = 'Bilgiler kaydedildi.';
            } catch (Throwable $e) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                $error = 'Kayıt sırasında hata oluştu.';
            }
        }
    }
}

$csrf = function_exists('csrf_token') ? csrf_token() : '';
?>

<div style="max-width: 980px; margin: 22px auto;">
  <div class="card" style="padding:18px;">

    <?php if ($success): ?>
      <div style="background:#ecfdf3;border:1px solid #bbf7d0;color:#166534;padding:10px 12px;border-radius:10px;margin:10px 0;">
        <?= h($success) ?>
      </div>
    <?php endif; ?>

    <?php if ($error): ?>
      <div style="background:#fff1f2;border:1px solid #fecdd3;color:#b91c1c;padding:10px 12px;border-radius:10px;margin:10px 0;">
        <?= h($error) ?>
      </div>
    <?php endif; ?>

    <form method="post" action="users.php" autocomplete="off">
      <input type="hidden" name="csrf_token" value="<?= h($csrf) ?>">

      <!-- Satır 1: Kullanıcı adı + Son giriş -->
      <div style="display:flex; gap:18px; align-items:flex-end; flex-wrap:wrap;">
        <div style="flex:1; min-width:320px;">
          <label style="display:block;font-size:13px;font-weight:600;margin-bottom:6px;">Kullanıcı Adı</label>
          <input
            type="text"
            name="username"
            value="<?= h($user['username'] ?? '') ?>"
            style="width:100%; box-sizing:border-box; padding:10px 12px; border:1px solid #d1d5db; border-radius:10px; outline:none;"
          >
        </div>

        <div style="min-width:220px; padding-bottom:2px;">
          <div style="font-size:12px; color:#6b7280;">Son giriş</div>
          <div style="font-size:13px; font-weight:600; color:#111827;">
            <?= h($user['last_login_at'] ?? '-') ?>
          </div>
        </div>
      </div>

      <hr style="border:0;border-top:1px solid #e5e7eb;margin:16px 0;">

      <!-- Satır 2: Şifre + Şifre tekrar -->
      <div style="display:flex; gap:18px; flex-wrap:wrap;">
        <div style="flex:1; min-width:320px;">
          <label style="display:block;font-size:13px;font-weight:600;margin-bottom:6px;">Yeni Şifre</label>
          <input
            type="password"
            name="password"
            placeholder="Boş bırakırsan değişmez"
            autocomplete="new-password"
            style="width:100%; box-sizing:border-box; padding:10px 12px; border:1px solid #d1d5db; border-radius:10px; outline:none;"
          >
        </div>

        <div style="flex:1; min-width:320px;">
          <label style="display:block;font-size:13px;font-weight:600;margin-bottom:6px;">Yeni Şifre (Tekrar)</label>
          <input
            type="password"
            name="password2"
            placeholder="Boş bırakırsan değişmez"
            autocomplete="new-password"
            style="width:100%; box-sizing:border-box; padding:10px 12px; border:1px solid #d1d5db; border-radius:10px; outline:none;"
          >
        </div>
      </div>

      <div style="margin-top:14px; display:flex; justify-content:flex-end; gap:10px;">
        <button type="submit" class="btn btn-primary">Kaydet</button>
      </div>
    </form>
  </div>
</div>

<?php require_once __DIR__ . '/admin_footer.php'; ?>
