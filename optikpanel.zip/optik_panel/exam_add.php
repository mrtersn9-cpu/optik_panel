<?php
require_once __DIR__ . '/config.php';

require_login();

$errors = [];
$success = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $exam_number = trim($_POST['exam_number'] ?? '');
    $barcode = trim($_POST['barcode'] ?? '');
    $booklet_count = (int)($_POST['booklet_count'] ?? 1);

    $branch_names = $_POST['branch_name'] ?? [];
    $branch_questions = $_POST['branch_question_count'] ?? [];

    if ($name === '') $errors[] = 'Deneme adı zorunludur.';
    if ($exam_number === '') $errors[] = 'Deneme numarası zorunludur.';
    if ($barcode === '') $errors[] = 'Barkod zorunludur.';
    if ($booklet_count < 1) $errors[] = 'En az 1 kitapçık seçmelisiniz.';

    // En az bir branş
    $valid_branches = [];
    foreach ($branch_names as $idx => $bname) {
        $bname = trim($bname);
        $qcount = (int)($branch_questions[$idx] ?? 0);
        if ($bname !== '' && $qcount > 0) {
            $valid_branches[] = [
                'name' => $bname,
                'question_count' => $qcount
            ];
        }
    }
    if (empty($valid_branches)) {
        $errors[] = 'En az bir branş ve soru sayısı girmelisiniz.';
    }

    if (empty($errors)) {
        $pdo->beginTransaction();
        try {
            $stmt = $pdo->prepare("INSERT INTO exams (name, exam_number, barcode) VALUES (?, ?, ?)");
            $stmt->execute([$name, $exam_number, $barcode]);
            $exam_id = (int)$pdo->lastInsertId();

            // Kitapçıklar (A, B, C ...)
            $booklet_codes = [];
            $alphabet = range('A', 'Z');
            for ($i = 0; $i < $booklet_count; $i++) {
                $code = $alphabet[$i] ?? ('K' . ($i+1));
                $booklet_codes[] = $code;
                $stmtB = $pdo->prepare("INSERT INTO exam_booklets (exam_id, code) VALUES (?, ?)");
                $stmtB->execute([$exam_id, $code]);
            }

            // Branşlar
            foreach ($valid_branches as $br) {
                $stmtBr = $pdo->prepare("INSERT INTO exam_branches (exam_id, name, question_count) VALUES (?, ?, ?)");
                $stmtBr->execute([$exam_id, $br['name'], $br['question_count']]);
            }

            $pdo->commit();
            header('Location: exam_detail.php?id=' . $exam_id);
            exit;
        } catch (Exception $e) {
            $pdo->rollBack();
            $errors[] = 'Veritabanı hatası: ' . $e->getMessage();
        }
    }
}

include __DIR__ . '/admin_header.php';
?>
<h2>Yeni Deneme Ekle</h2>

<?php if (!empty($errors)): ?>
    <div style="background:#ffebee; padding:10px; border-radius:4px; margin-bottom:10px; color:#b71c1c;">
        <strong>Hata:</strong>
        <ul>
            <?php foreach ($errors as $e): ?>
                <li><?php echo htmlspecialchars($e); ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
<?php endif; ?>

<form method="post">
    <div class="row">
        <div class="col-4">
            <div class="form-group">
                <label>Deneme Adı</label>
                <input type="text" name="name" value="<?php echo htmlspecialchars($_POST['name'] ?? ''); ?>">
            </div>
        </div>
        <div class="col-4">
            <div class="form-group">
                <label>Deneme Numarası</label>
                <input type="text" name="exam_number" value="<?php echo htmlspecialchars($_POST['exam_number'] ?? ''); ?>">
            </div>
        </div>
        <div class="col-4">
            <div class="form-group">
                <label>Barkod</label>
                <input type="text" name="barcode" value="<?php echo htmlspecialchars($_POST['barcode'] ?? ''); ?>">
            </div>
        </div>
    </div>

    <div class="row mt-3">
        <div class="col-4">
            <div class="form-group">
                <label>Kaç Farklı Kitapçık?</label>
                <input type="number" name="booklet_count" min="1" max="10" value="<?php echo htmlspecialchars($_POST['booklet_count'] ?? '1'); ?>">
                <div class="muted">Kitapçıklar otomatik A, B, C... olarak oluşturulur.</div>
            </div>
        </div>
    </div>

    <h3 class="mt-3">Denemedeki Branşlar</h3>
    <table class="table-sm" id="branches-table">
        <thead>
            <tr>
                <th>Branş Adı</th>
                <th>Soru Sayısı</th>
                <th style="width:60px;">Sil</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $old_branches = $_POST['branch_name'] ?? ['Türkçe', 'Sosyal Bilimler','Matematik','Fen Bilimleri'];
            $old_qcounts = $_POST['branch_question_count'] ?? [40, 25,40,20];
            if (!is_array($old_branches)) $old_branches = [];
            if (!is_array($old_qcounts)) $old_qcounts = [];
            if (empty($old_branches)) {
                $old_branches = [''];
                $old_qcounts = [''];
            }
            foreach ($old_branches as $i => $bname):
                $qcount = $old_qcounts[$i] ?? '';
            ?>
            <tr>
                <td><input type="text" name="branch_name[]" value="<?php echo htmlspecialchars($bname); ?>"></td>
                <td><input type="number" name="branch_question_count[]" min="1" value="<?php echo htmlspecialchars($qcount); ?>"></td>
                <td class="text-center"><button type="button" class="btn btn-danger btn-sm" onclick="removeBranchRow(this)">X</button></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <button type="button" class="btn btn-secondary btn-sm mt-2" onclick="addBranchRow()">+ Branş Ekle</button>

    <div class="mt-4 text-right">
        <button type="submit" class="btn btn-primary">Denemeyi Kaydet</button>
    </div>
</form>

<script>
function addBranchRow() {
    const tbody = document.querySelector('#branches-table tbody');
    const tr = document.createElement('tr');
    tr.innerHTML = `
        <td><input type="text" name="branch_name[]" value=""></td>
        <td><input type="number" name="branch_question_count[]" min="1" value=""></td>
        <td class="text-center"><button type="button" class="btn btn-danger btn-sm" onclick="removeBranchRow(this)">X</button></td>
    `;
    tbody.appendChild(tr);
}
function removeBranchRow(btn) {
    const tr = btn.closest('tr');
    const tbody = tr.parentNode;
    if (tbody.children.length > 1) {
        tbody.removeChild(tr);
    } else {
        tr.querySelectorAll('input').forEach(i => i.value = '');
    }
}
</script>

<?php
include __DIR__ . '/admin_footer.php';
