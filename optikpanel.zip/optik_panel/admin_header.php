<?php
require_once __DIR__ . '/config.php';
require_login();

// Aktif menüyü işaretlemek için
$__current = basename($_SERVER['PHP_SELF'] ?? '');
?>
<!doctype html>
<html lang="tr">
<head>
    <meta charset="utf-8">
    <title>Sonuç Yayınları - Optik Deneme Yönetimi</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/admin.css?v=1">
    <!-- Fallback (assets yüklenmezse çok hafif bir stil) -->
    <style>body{font-family:Inter,system-ui,-apple-system,Segoe UI,Roboto,Arial,sans-serif;margin:0}</style>
</head>
<body>
<div class="admin-shell">
    <header class="topbar">
        <div class="topbar-inner">
            <div class="brand">
                <div class="brand-badge" aria-hidden="true">SY</div>
                <div class="brand-text">
                    <div class="brand-title">Sonuç Yayınları</div>
                    <div class="brand-sub">Optik Deneme Yönetimi</div>
                </div>
            </div>

            <button class="nav-toggle" type="button" aria-label="Menüyü Aç/Kapat" data-nav-toggle>
                <span></span><span></span><span></span>
            </button>

            <nav class="topnav" data-topnav>
                <a class="nav-link <?php echo ($__current==='exams.php')?'active':''; ?>" href="exams.php">Denemeler</a>
                <a class="nav-link <?php echo ($__current==='exam_add.php')?'active':''; ?>" href="exam_add.php">Yeni Deneme</a>
                <a class="nav-link <?php echo ($__current==='analytics.php')?'active':''; ?>" href="analytics.php">Analytics</a>
                <a class="nav-link <?php echo ($__current==='users.php')?'active':''; ?>" href="users.php">Profil</a>
                <a class="nav-link danger" href="logout.php">Çıkış</a>
            </nav>
        </div>
    </header>

    <main class="content">
        <div class="container">
