-- Video Link Özelliği için Database Migration (Basit Versiyon)
-- Tarih: 30 Aralık 2025
-- UYARI: Kolon zaten varsa hata verir!

-- KULLANIM:
-- 1. Önce kontrol et hangi kolonlar eksik:
--    DESCRIBE exam_question_videos;
--
-- 2. Eksik olanları ekle (aşağıdaki komutlardan sadece gerekenleri çalıştır)

-- video_link kolonu ekle
ALTER TABLE exam_question_videos 
ADD COLUMN video_link VARCHAR(500) DEFAULT NULL COMMENT 'Harici video linki' AFTER video_path;

-- created_at kolonu ekle
ALTER TABLE exam_question_videos 
ADD COLUMN created_at TIMESTAMP NULL DEFAULT NULL AFTER video_link;

-- updated_at kolonu ekle
ALTER TABLE exam_question_videos 
ADD COLUMN updated_at TIMESTAMP NULL DEFAULT NULL AFTER created_at;

-- Index ekle
ALTER TABLE exam_question_videos 
ADD INDEX idx_video_link (video_link(255));

-- KONTROL: Tüm kolonlar eklendi mi?
DESCRIBE exam_question_videos;
