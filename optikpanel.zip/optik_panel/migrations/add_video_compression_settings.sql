-- Video Compression Ayarları için Database Migration
-- Tarih: 30 Aralık 2025

-- admin_users tablosuna yeni kolonlar ekle (Default KAPALI)
ALTER TABLE admin_users 
ADD COLUMN video_compression_enabled TINYINT(1) DEFAULT 0 COMMENT 'Video sıkıştırma aktif mi (0=kapalı)',
ADD COLUMN video_compression_quality VARCHAR(10) DEFAULT 'medium' COMMENT 'Kalite: low, medium, high',
ADD COLUMN video_compression_percentage INT DEFAULT 80 COMMENT 'Hedef sıkıştırma yüzdesi (50-90)';

-- Mevcut kullanıcılar için default değerleri ayarla (KAPALI)
UPDATE admin_users 
SET video_compression_enabled = 0,
    video_compression_quality = 'medium',
    video_compression_percentage = 80
WHERE video_compression_enabled IS NULL;

-- Index ekle (performans için)
ALTER TABLE admin_users 
ADD INDEX idx_compression (video_compression_enabled);
