# OPTIK PANEL - GÜVENLİK GÜNCELLEMELERİ KURULUM KILAVUZU

## 📋 Yapılan Güncellemeler

### ✅ Eklenen Güvenlik Özellikleri

1. **CSRF Koruması**
   - Tüm API endpoint'lerine CSRF token kontrolü eklendi
   - Token doğrulama mekanizması güçlendirildi

2. **Rate Limiting**
   - Login için brute force koruması (5 deneme / 5 dakika)
   - Rate limit bilgileri session'da saklanıyor
   - Kalan süre kullanıcıya gösteriliyor

3. **Session Hijacking Koruması**
   - User Agent kontrolü
   - Session timeout (30 dakika)
   - Maximum session lifetime (24 saat)
   - Session güvenlik metrikleri

4. **Gelişmiş Dosya Upload Güvenliği**
   - MIME type kontrolü
   - Video header doğrulaması (magic bytes)
   - Güvenli dosya isimlendirme (random)
   - Dosya izin kontrolü (644)

5. **Security Logging**
   - Tüm güvenlik olayları loglanıyor
   - Login başarı/başarısızlık kayıtları
   - Upload reddedilme sebepleri
   - Rate limit ihlalleri

---

## 🚀 KURULUM ADIMLARı

### Adım 1: Dosyaları Yükleyin

```bash
# Eski dosyaları yedekleyin
cp -r /path/to/optik_panel /path/to/optik_panel_backup_$(date +%Y%m%d)

# Yeni dosyaları kopyalayın
# - security.php (YENİ)
# - config.php (GÜNCELLENDİ)
# - api/upload_video.php (GÜNCELLENDİ)
# - api/save_outcomes.php (GÜNCELLENDİ)
# - uploads/.htaccess (YENİ)
# - logs/.htaccess (YENİ)
```

### Adım 2: Dizin İzinlerini Ayarlayın

```bash
# Logs dizinini oluşturun
mkdir -p optik_panel/logs
chmod 755 optik_panel/logs

# Uploads izinlerini kontrol edin
chmod 755 optik_panel/uploads
chmod 755 optik_panel/uploads/exams

# .htaccess dosyalarının okunabilir olduğundan emin olun
chmod 644 optik_panel/uploads/.htaccess
chmod 644 optik_panel/logs/.htaccess
```

### Adım 3: Veritabanı Güncelleme (Opsiyonel)

Eğer `exam_question_videos` tablosu yoksa:

```sql
CREATE TABLE IF NOT EXISTS `exam_question_videos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `exam_id` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `question_no` int(11) NOT NULL,
  `video_path` varchar(500) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `exam_id` (`exam_id`),
  KEY `branch_question` (`branch_id`, `question_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
```

### Adım 4: .htaccess Kontrolü

Ana `.htaccess` dosyanızda şunların olduğundan emin olun:

```apache
# Root .htaccess
Options -Indexes
DirectoryIndex index.php index.html
RewriteEngine On

# exam_view temiz URL
RewriteRule ^exam_view/([0-9]+)(?:/.*)?$ exam_view.php?id=$1 [L,QSA]
```

### Adım 5: PHP Konfigürasyonu

`php.ini` veya `.user.ini` dosyanızda:

```ini
# Güvenlik
expose_php = Off
allow_url_fopen = Off
allow_url_include = Off

# Upload
upload_max_filesize = 200M
post_max_size = 210M
max_execution_time = 300

# Session
session.cookie_httponly = 1
session.cookie_secure = 1  # Sadece HTTPS için
session.cookie_samesite = Lax
session.gc_maxlifetime = 1800

# Error Handling (Production)
display_errors = Off
log_errors = On
error_log = /var/log/php/error.log
```

---

## 🔍 TEST KONTROLÜ

### 1. CSRF Koruması Testi

```bash
# CSRF token olmadan API çağrısı yapın
curl -X POST https://your-domain.com/optik_panel/api/upload_video.php \
  -F "exam_id=1" \
  -F "branch_id=1" \
  -F "question_no=1"

# Beklenen: 403 Forbidden veya "Güvenlik doğrulaması başarısız"
```

### 2. Rate Limiting Testi

```bash
# Login sayfasında 6 kez yanlış şifre deneyin
# 5. denemeden sonra "Çok fazla başarısız deneme" mesajı görmeli
```

### 3. Dosya Upload Testi

```bash
# .php uzantılı dosyayı .mp4 olarak yüklemeyi deneyin
# Beklenen: "Dosya geçerli bir video değil" hatası
```

### 4. Log Dosyası Kontrolü

```bash
# Log dosyalarının oluştuğunu kontrol edin
ls -la optik_panel/logs/

# İçeriği kontrol edin
tail -f optik_panel/logs/security.log
tail -f optik_panel/logs/error.log
```

---

## 📊 CSRF TOKEN KULLANIMI

### Frontend'de Token Gönderme

#### AJAX İstekleri

```javascript
// Form data ile
const formData = new FormData();
formData.append('csrf_token', '<?= csrf_token() ?>');
formData.append('exam_id', examId);
formData.append('video', videoFile);

fetch('/optik_panel/api/upload_video.php', {
    method: 'POST',
    body: formData
});

// Veya header ile
fetch('/optik_panel/api/save_outcomes.php', {
    method: 'POST',
    headers: {
        'X-CSRF-TOKEN': '<?= csrf_token() ?>'
    },
    body: formData
});
```

#### Normal Form Gönderimi

```html
<form method="post" action="api/save_outcomes.php">
    <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
    <!-- Diğer alanlar -->
    <button type="submit">Kaydet</button>
</form>
```

---

## ⚠️ ÖNEMLİ NOTLAR

### 1. Session Timeout

- Kullanıcılar 30 dakika hareketsiz kalırsa otomatik çıkış yapılır
- Session maksimum 24 saat geçerlidir
- Timeout olursa `?error=session_expired` ile login'e yönlendirilir

### 2. Rate Limiting

- Login için: 5 deneme / 5 dakika
- API için: Henüz uygulanmadı (opsiyonel)
- Rate limit IP bazlı çalışır

### 3. Dosya Upload

- Maksimum dosya boyutu: 200MB
- İzin verilen formatlar: MP4, WebM, MOV
- MIME type ve video header kontrolü yapılır
- Başarısız upload'lar otomatik temizlenir

### 4. Logging

- Log dosyaları `/optik_panel/logs/` altında
- `security.log`: Güvenlik olayları
- `error.log`: Genel hatalar
- Log dosyalarına web'den erişim engellendi (.htaccess ile)

---

## 🐛 SORUN GİDERME

### Problem: "Güvenlik doğrulaması başarısız"

**Çözüm:**
- Sayfayı yenileyin (F5)
- Browser cache'i temizleyin
- Session cookie'nin aktif olduğundan emin olun

### Problem: "Çok fazla başarısız deneme"

**Çözüm:**
- 5 dakika bekleyin
- Veya sunucuda session'ı manuel temizleyin:
  ```bash
  rm /var/lib/php/sessions/sess_*
  ```

### Problem: "Dosya geçerli bir video değil"

**Çözüm:**
- Video dosyasının bozuk olmadığından emin olun
- Farklı bir video player ile test edin
- Formatı kontrol edin (MP4, WebM, MOV)

### Problem: Log dosyası oluşmuyor

**Çözüm:**
```bash
# Dizin izinlerini kontrol edin
chmod 755 optik_panel/logs
chown www-data:www-data optik_panel/logs

# Manuel test
touch optik_panel/logs/test.txt
```

---

## 📈 PERFORMANS ÖNERİLERİ

### 1. Opcode Cache

```ini
; php.ini
opcache.enable=1
opcache.memory_consumption=128
opcache.interned_strings_buffer=8
opcache.max_accelerated_files=4000
opcache.revalidate_freq=60
```

### 2. Session Storage

Yoğun kullanımda Redis/Memcached kullanın:

```php
// config.php'de
ini_set('session.save_handler', 'redis');
ini_set('session.save_path', 'tcp://127.0.0.1:6379');
```

### 3. Log Rotation

```bash
# logrotate.conf
/path/to/optik_panel/logs/*.log {
    daily
    rotate 30
    compress
    delaycompress
    notifempty
    missingok
}
```

---

## 🔐 EK GÜVENLİK ÖNERİLERİ

### 1. SSL/HTTPS Zorunlu

```apache
# .htaccess
RewriteCond %{HTTPS} off
RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]
```

### 2. Security Headers

```apache
# .htaccess
<IfModule mod_headers.c>
    Header set X-Content-Type-Options "nosniff"
    Header set X-Frame-Options "SAMEORIGIN"
    Header set X-XSS-Protection "1; mode=block"
    Header set Referrer-Policy "strict-origin-when-cross-origin"
    Header set Permissions-Policy "geolocation=(), microphone=(), camera=()"
</IfModule>
```

### 3. IP Whitelist (Opsiyonel)

```apache
# Admin paneli için
<Location "/optik_panel">
    Order Deny,Allow
    Deny from all
    Allow from 123.456.789.0
    # Trusted IP'leri ekleyin
</Location>
```

---

## 📞 DESTEK

Sorun yaşarsanız:

1. Log dosyalarını kontrol edin
2. Browser console'u kontrol edin
3. PHP error log'unu kontrol edin
4. Gerekirse backup'tan geri dönün

---

**Son Güncelleme:** 29 Aralık 2025
**Versiyon:** 7.1 (Security Update)
