<?php
/**
 * Optik Panel - Güvenli Konfigürasyon ve Kimlik Doğrulama
 *
 * Öneri (güvenlik): DB bilgilerini bu dosyada düz metin tutmayın.
 *  - Sunucuda ortam değişkenleri (ENV) kullanın veya
 *  - Bu dosyanın yanına config.local.php koyun (git'e / paylaşıma eklemeyin).
 *
 * config.local.php örneği: config.local.php.example
 */

declare(strict_types=1);

// ----------------- Güvenlik Modülü -----------------
require_once __DIR__ . '/security.php';

// ----------------- Güvenli oturum ayarları -----------------
$https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
    || (!empty($_SERVER['SERVER_PORT']) && (int)$_SERVER['SERVER_PORT'] === 443);

ini_set('session.use_strict_mode', '1');
ini_set('session.use_only_cookies', '1');
ini_set('session.cookie_httponly', '1');

if (PHP_VERSION_ID >= 70300) {
    // PHP 7.3+ SameSite destekler
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'domain' => '',
        'secure' => $https,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
}

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_name('optik_admin_session');
    session_start();
}

// ----------------- Yerel/ENV config yükle -----------------
$dsn     = getenv('OPTIK_DB_DSN') ?: '';
$db_user = getenv('OPTIK_DB_USER') ?: '';
$db_pass = getenv('OPTIK_DB_PASS') ?: '';
$base_url = getenv('OPTIK_BASE_URL') ?: '';

$local = __DIR__ . '/config.local.php';
if (is_file($local)) {
    /** @noinspection PhpIncludeInspection */
    require $local; // Bu dosya $dsn/$db_user/$db_pass/$base_url set edebilir.
}

// ----------------- Güvenli varsayılanlar -----------------
// Güvenlik optimizasyonu:
// - Bu repoda/zip'te GERÇEK şifre tutmuyoruz.
// - Üretimde mutlaka ENV veya config.local.php ile değerleri verin.
// - base_url boşsa, istekten otomatik türetir.

if ($base_url === '') {
    $scheme = $https ? 'https' : 'http';
    $host = (string)($_SERVER['HTTP_HOST'] ?? 'localhost');
    $base_url = $scheme . '://' . $host . '/';
}

if ($dsn === '' || $db_user === '') {
    // Kurulum yönergesi (detay sızdırmadan)
    http_response_code(500);
    die('Konfigürasyon eksik: OPTIK_DB_DSN / OPTIK_DB_USER (ve gerekiyorsa OPTIK_DB_PASS) tanımlayın veya config.local.php oluşturun.');
}

// ----------------- PDO -----------------
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $db_user, $db_pass, $options);
} catch (PDOException $e) {
    // Üretimde detaylı hatayı göstermeyin.
    http_response_code(500);
    die('Veritabanı bağlantı hatası.');
}

// ----------------- Auth (DB tabanlı) -----------------
function is_logged_in(): bool {
    return !empty($_SESSION['optik_admin_user_id']);
}

function current_user(): ?array {
    if (!is_logged_in()) return null;
    return [
        'id' => (int)$_SESSION['optik_admin_user_id'],
        'username' => (string)($_SESSION['optik_admin_username'] ?? ''),
        'role' => (string)($_SESSION['optik_admin_role'] ?? 'admin'),
    ];
}

function require_login(): void {
    $self = basename($_SERVER['PHP_SELF'] ?? '');
    if ($self === 'login.php') return;
    if (!is_logged_in()) {
        header('Location: login.php');
        exit;
    }
    
    // Session hijacking kontrolü
    if (!validate_session()) {
        log_security_event('session_invalid', 'Session validation failed');
        do_logout();
        header('Location: login.php?error=session_expired');
        exit;
    }
}
function verify_admin_password(string $plainPassword): bool {
    global $pdo;

    if (!is_logged_in()) return false;

    $userId = (int)($_SESSION['optik_admin_user_id'] ?? 0);
    if ($userId <= 0) return false;

    $st = $pdo->prepare("SELECT password_hash FROM admin_users WHERE id = ? LIMIT 1");
    $st->execute([$userId]);
    $hash = (string)$st->fetchColumn();

    if ($hash === '') return false;

    return password_verify($plainPassword, $hash);
}

function do_login(string $username, string $password): bool {
    global $pdo;

    $username = trim($username);
    if ($username === '' || $password === '') return false;

    // Rate limiting kontrolü
    $ip = client_ip_address();
    $rateLimitKey = 'login_' . $ip;
    
    if (!check_rate_limit($rateLimitKey, 5, 300)) {
        $remaining = get_rate_limit_remaining($rateLimitKey);
        log_security_event('rate_limit', 'Login rate limit exceeded', [
            'username' => $username,
            'remaining_seconds' => $remaining
        ]);
        return false;
    }

    $st = $pdo->prepare("SELECT id, username, password_hash, role, is_active FROM admin_users WHERE username = ? LIMIT 1");
    $st->execute([$username]);
    $u = $st->fetch();

    if (!$u || (int)$u['is_active'] !== 1) {
        log_security_event('login_failed', 'User not found or inactive', ['username' => $username]);
        return false;
    }

    if (!password_verify($password, (string)$u['password_hash'])) {
        log_security_event('login_failed', 'Invalid password', ['username' => $username]);
        return false;
    }

    // Başarılı login - rate limit sıfırla
    reset_rate_limit($rateLimitKey);

    // Session fixation önlemi
    if (session_status() === PHP_SESSION_ACTIVE) {
        session_regenerate_id(true);
    }

    $_SESSION['optik_admin_user_id'] = (int)$u['id'];
    $_SESSION['optik_admin_username'] = (string)$u['username'];
    $_SESSION['optik_admin_role'] = (string)($u['role'] ?? 'admin');
    
    // Session güvenlik verilerini başlat
    init_session_security();

    // last_login güncelle
    $upd = $pdo->prepare("UPDATE admin_users SET last_login_at = NOW() WHERE id = ?");
    $upd->execute([(int)$u['id']]);

    // Hash algoritması güçlendirilmişse rehash
    if (password_needs_rehash((string)$u['password_hash'], PASSWORD_DEFAULT)) {
        $newHash = password_hash($password, PASSWORD_DEFAULT);
        $reh = $pdo->prepare("UPDATE admin_users SET password_hash = ? WHERE id = ?");
        $reh->execute([$newHash, (int)$u['id']]);
    }

    // Giriş logu
    if (function_exists('log_admin_login')) {
        log_admin_login((int)$u['id']);
    }
    
    log_security_event('login_success', 'User logged in', [
        'user_id' => (int)$u['id'],
        'username' => $username
    ]);

    return true;
}

function do_logout(): void {
    $_SESSION = [];
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $params["path"], $params["domain"],
            $params["secure"], $params["httponly"]
        );
    }
    session_destroy();
}

// ----------------- Log helpers -----------------
function client_ip_address(): string {
    // Basit ve güvenli: REMOTE_ADDR
    $ip = (string)($_SERVER['REMOTE_ADDR'] ?? '');
    return $ip !== '' ? $ip : '0.0.0.0';
}

function client_user_agent(): string {
    $ua = (string)($_SERVER['HTTP_USER_AGENT'] ?? '');
    // DB'yi şişirmesin diye çok uzunsa kırp
    if (strlen($ua) > 8000) {
        $ua = substr($ua, 0, 8000);
    }
    return $ua;
}

function log_admin_login(int $userId): void {
    global $pdo;
    if ($userId <= 0) return;
    try {
        $st = $pdo->prepare("INSERT INTO admin_login_logs (user_id, ip_address, user_agent) VALUES (?, ?, ?)");
        $st->execute([$userId, client_ip_address(), client_user_agent()]);
    } catch (Throwable $e) {
        // tablo yoksa / hata olursa sessiz geç
    }
}

function log_exam_view_completed(int $examId): void {
    global $pdo;
    if ($examId <= 0) return;
    try {
        $st = $pdo->prepare("INSERT INTO exam_view_logs (exam_id, ip_address) VALUES (?, ?)");
        $st->execute([$examId, client_ip_address()]);
    } catch (Throwable $e) {
        // tablo yoksa / hata olursa sessiz geç
    }
}
?>
