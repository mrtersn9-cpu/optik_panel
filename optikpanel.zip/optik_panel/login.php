<?php
declare(strict_types=1);

// (İstersen debug'u tamamen kapatmak için aşağıdaki bloğu da silebilirsin.)
$debug = isset($_GET['debug']) && $_GET['debug'] === '1';
if ($debug) {
    ini_set('display_errors', '1');
    ini_set('display_startup_errors', '1');
    error_reporting(E_ALL);
}

require_once __DIR__ . '/config.php';

if (!function_exists('h')) {
    function h($s): string { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
}

// zaten login ise index'e
if (function_exists('is_logged_in') && is_logged_in()) {
    header('Location: index.php');
    exit;
}

$error = null;

$dbg = [
    'time' => date('Y-m-d H:i:s'),
    'php' => PHP_VERSION,
    'method' => $_SERVER['REQUEST_METHOD'] ?? '',
    'session_name' => session_name(),
    'session_id' => session_id(),
    'cookie_present' => isset($_COOKIE[session_name()]) ? 1 : 0,
    'csrf_ok' => null,
    'posted_username' => null,
    'password_len' => null,
    'do_login_result' => null,
    'after_login_is_logged_in' => null,
    'session_keys_after' => null,
    'db_driver' => null,
    'db_error' => null,
];

try {
    if (isset($pdo) && $pdo instanceof PDO) {
        $dbg['db_driver'] = $pdo->getAttribute(PDO::ATTR_DRIVER_NAME);
    }
} catch (Throwable $e) {
    $dbg['db_error'] = $e->getMessage();
}

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    $username = trim((string)($_POST['username'] ?? ''));
    $password = (string)($_POST['password'] ?? '');
    $token    = (string)($_POST['csrf_token'] ?? '');

    $dbg['posted_username'] = $username;
    $dbg['password_len'] = strlen($password);

    $csrfOk = function_exists('csrf_validate') ? csrf_validate($token) : false;
    $dbg['csrf_ok'] = $csrfOk ? 1 : 0;

    if (!$csrfOk) {
        $error = 'Güvenlik doğrulaması başarısız (CSRF).';
    } elseif ($username === '' || $password === '') {
        $error = 'Kullanıcı adı ve şifre zorunludur.';
    } else {
        try {
            $ok = function_exists('do_login') ? do_login($username, $password) : false;

            $dbg['do_login_result'] = $ok ? 1 : 0;
            $dbg['after_login_is_logged_in'] = (function_exists('is_logged_in') && is_logged_in()) ? 1 : 0;

            if ($ok) {
                header('Location: index.php');
                exit;
            } else {
                $error = 'Kullanıcı adı veya şifre hatalı.';
            }
        } catch (Throwable $e) {
            $dbg['db_error'] = $e->getMessage();
            $error = $debug ? ('Sistem hatası: ' . $e->getMessage()) : 'Giriş işlemi başarısız.';
        }
    }
}

$csrf = function_exists('csrf_token') ? csrf_token() : '';
?>
<!doctype html>
<html lang="tr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Optik Panel Giriş</title>

<style>
:root{
  --bg1:#0b2a43;
  --bg2:#1b4d7a;
  --card:#ffffff;
  --text:#0f172a;
  --muted:#64748b;
  --line:#e2e8f0;
  --brand:#2563eb;
  --brand2:#1d4ed8;
  --danger-bg:#fff1f2;
  --danger:#b91c1c;
  --shadow: 0 20px 60px rgba(2,6,23,.25);
  --radius:18px;
}

*{box-sizing:border-box}
html,body{height:100%}
body{
  margin:0;
  font-family: ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial;
  color:var(--text);
  background:
    radial-gradient(1000px 500px at 10% 10%, rgba(34,211,238,.18), transparent 60%),
    radial-gradient(900px 450px at 90% 30%, rgba(99,102,241,.18), transparent 55%),
    linear-gradient(135deg, var(--bg1), var(--bg2));
  display:flex;
  align-items:center;
  justify-content:center;
  padding:28px;
}

.wrap{
  width:min(980px, 100%);
  display:grid;
  grid-template-columns: 1.2fr 1fr;
  gap:18px;
  align-items:stretch;
}
@media (max-width: 860px){
  .wrap{grid-template-columns:1fr; max-width:520px}
}


.brand{
  display:flex; align-items:center; gap:10px;
  font-weight:800; letter-spacing:.2px;
}
.badge{
  font-size:11px;
  padding:6px 10px;
  border-radius:999px;
  border:1px solid rgba(255,255,255,.25);
  background: rgba(255,255,255,.10);
}

.kpi{
  display:flex; gap:10px; flex-wrap:wrap; margin-top:14px;
}
.kpi .pill{
  padding:8px 10px;
  border-radius:999px;
  background: rgba(255,255,255,.10);
  border:1px solid rgba(255,255,255,.14);
  font-size:12px;
  color: rgba(229,231,235,.92);
}

.card{
  background: var(--card);
  border-radius: var(--radius);
  box-shadow: var(--shadow);
  border:1px solid rgba(15,23,42,.06);
  padding:22px;
}
.card h2{
  margin:0 0 6px;
  font-size:18px;
}
.sub{
  margin:0 0 14px;
  color:var(--muted);
  font-size:12px;
  line-height:1.5;
}

.alert{
  background: var(--danger-bg);
  color: var(--danger);
  border:1px solid #fecdd3;
  border-radius: 14px;
  padding: 10px 12px;
  margin: 10px 0 14px;
  font-size: 13px;
}

.field{margin:12px 0}
.label{
  display:flex; justify-content:space-between; align-items:center;
  font-size:13px; color:#334155; font-weight:650;
  margin-bottom:6px;
}
.input{
  width:100%;
  border:1px solid var(--line);
  border-radius: 14px;
  padding: 12px 12px;
  font-size: 14px;
  outline:none;
  transition: box-shadow .15s ease, border-color .15s ease;
  background:#fff;
}
.input:focus{
  border-color: rgba(37,99,235,.55);
  box-shadow: 0 0 0 4px rgba(37,99,235,.14);
}
.input-wrap{position:relative}
.btn-icon{
  position:absolute;
  right:10px; top:50%;
  transform: translateY(-50%);
  border:0; background:transparent;
  cursor:pointer;
  padding:8px;
  border-radius:10px;
  color:#64748b;
}
.btn-icon:hover{background:#f1f5f9}

.btn{
  width:100%;
  margin-top:10px;
  padding: 12px 14px;
  border:0;
  border-radius: 14px;
  background: linear-gradient(135deg, var(--brand), var(--brand2));
  color:#fff;
  font-weight:750;
  font-size:14px;
  cursor:pointer;
  box-shadow: 0 10px 20px rgba(37,99,235,.22);
  transition: transform .12s ease, filter .12s ease;
}
.btn:hover{transform: translateY(-1px); filter: brightness(1.03);}
.btn:active{transform: translateY(0); filter: brightness(.98);}
.btn[disabled]{opacity:.7; cursor:not-allowed; transform:none;}

.hint{
  margin-top:10px;
  font-size:12px;
  color:#64748b;
  display:flex;
  align-items:center;
  justify-content:space-between;
  gap:10px;
  flex-wrap:wrap;
}
.sec{
  display:flex; align-items:center; gap:8px;
}
.dot{
  width:8px;height:8px;border-radius:999px;background:#22c55e;
  box-shadow:0 0 0 4px rgba(34,197,94,.15);
}
</style>
</head>

<body>



    <section class="card">
      <h2>Giriş Yap</h2>
      <p class="sub">Kullanıcı adı ve şifreni gir. Giriş sonrası panel yönlendirmesi otomatik yapılır.</p>

      <?php if ($error): ?>
        <div class="alert"><?= h($error) ?></div>
      <?php endif; ?>

      <form method="post" action="login.php" id="loginForm">
        <input type="hidden" name="csrf_token" value="<?= h($csrf) ?>">

        <div class="field">
          <div class="label">Kullanıcı Adı</div>
          <input class="input" type="text" name="username" autocomplete="username"
                 value="<?= h($_POST['username'] ?? 'admin') ?>" placeholder="örn. admin">
        </div>

        <div class="field">
          <div class="label"><span>Şifre</span></div>
          <div class="input-wrap">
            <input class="input" id="pwd" type="password" name="password" autocomplete="current-password" placeholder="••••••••">
            <button class="btn-icon" type="button" id="togglePwd" aria-label="Şifreyi göster/gizle" title="Şifreyi göster/gizle">
              👁️
            </button>
          </div>
        </div>

        <button class="btn" id="submitBtn" type="submit">Giriş Yap</button>

        <div class="hint">
          <div class="sec"><span class="dot"></span> Güvenlik aktif</div>
        </div>
      </form>
    </section>


<script>
(function(){
  const pwd = document.getElementById('pwd');
  const toggle = document.getElementById('togglePwd');
  const form = document.getElementById('loginForm');
  const btn = document.getElementById('submitBtn');

  if (toggle && pwd) {
    toggle.addEventListener('click', function(){
      const isPw = pwd.getAttribute('type') === 'password';
      pwd.setAttribute('type', isPw ? 'text' : 'password');
      toggle.textContent = isPw ? '🙈' : '👁️';
    });
  }

  if (form && btn) {
    form.addEventListener('submit', function(){
      btn.disabled = true;
      btn.textContent = 'Giriş yapılıyor...';
    });
  }
})();
</script>
</body>
</html>
