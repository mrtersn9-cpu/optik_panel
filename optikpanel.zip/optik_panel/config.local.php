<?php
$dsn = 'mysql:host=localhost;dbname=sonu3109_dijitaloptik;charset=utf8mb4';
$db_user = 'sonu3109_dijitaloptik';
$db_pass = 'oLh4AFV#)tL1';
$base_url = 'https://dijitaloptik.sonucyayinlari.com.tr/';
$base_url_qr = 'https://dijitaloptik.sonucyayinlari.com.tr/';
