<?php

require_once __DIR__ . '/config.php';

require_login();

/**
 * AJAX İLE TEK KAZANIM SİLME
 * ---------------------------
 * POST: ajax=1, action=delete_outcome, id, exam_id
 * JSON döner.
 */
if (
    $_SERVER['REQUEST_METHOD'] === 'POST' &&
    isset($_POST['ajax']) && (string)$_POST['ajax'] === '1' &&
    isset($_POST['action']) && (string)$_POST['action'] === 'delete_outcome'
) {
    header('Content-Type: application/json; charset=utf-8');

    $id      = isset($_POST['id']) ? (int)$_POST['id'] : 0;
    $exam_id = isset($_POST['exam_id']) ? (int)$_POST['exam_id'] : 0;

    if ($id <= 0 || $exam_id <= 0) {
        echo json_encode(['success' => false, 'message' => 'Geçersiz istek.'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // Güvenlik kontrolü: outcome bu denemeye mi ait?
    $stmt = $pdo->prepare("SELECT exam_id FROM exam_outcomes WHERE id = ?");
    $stmt->execute([$id]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$row || (int)$row['exam_id'] !== $exam_id) {
        echo json_encode(['success' => false, 'message' => 'Yetkisiz işlem veya kayıt bulunamadı.'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    try {
        $pdo->beginTransaction();

        // Önce harita kayıtları
        $stmt = $pdo->prepare("DELETE FROM exam_outcome_booklet_map WHERE outcome_id = ?");
        $stmt->execute([$id]);

        // Sonra kazanım
        $stmt = $pdo->prepare("DELETE FROM exam_outcomes WHERE id = ?");
        $stmt->execute([$id]);

        $pdo->commit();

        echo json_encode(['success' => true, 'message' => 'Kayıt silindi.'], JSON_UNESCAPED_UNICODE);
        exit;
    } catch (Exception $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        echo json_encode(['success' => false, 'message' => 'Silme sırasında hata oluştu: ' . $e->getMessage()], JSON_UNESCAPED_UNICODE);
        exit;
    }
}

// === Normal sayfa akışı buradan sonra ===
include __DIR__ . '/admin_header.php';

// Yardımcı
function h($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($id <= 0) {
    echo "<p>Geçersiz deneme ID.</p>";
    include __DIR__ . '/admin_footer.php';
    exit;
}

// Deneme bilgisi
$stmt = $pdo->prepare("SELECT * FROM exams WHERE id = ?");
$stmt->execute([$id]);
$exam = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$exam) {
    echo "<p>Deneme bulunamadı.</p>";
    include __DIR__ . '/admin_footer.php';
    exit;
}

// Net ayarları
$useNegativeScoring = isset($exam['use_negative_scoring']) ? (int)$exam['use_negative_scoring'] : 1;
$wrongPerMinus      = isset($exam['wrong_per_minus']) && (int)$exam['wrong_per_minus'] > 0 ? (int)$exam['wrong_per_minus'] : 4;

// Kitapçıklar
$stmt = $pdo->prepare("SELECT * FROM exam_booklets WHERE exam_id = ? ORDER BY id ASC");
$stmt->execute([$id]);
$booklets = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Branşlar
$stmt = $pdo->prepare("SELECT * FROM exam_branches WHERE exam_id = ? ORDER BY id ASC");
$stmt->execute([$id]);
$branches = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Mevcut kazanımlar
$stmt = $pdo->prepare("
    SELECT eo.*, eb.name AS branch_name
    FROM exam_outcomes eo
    JOIN exam_branches eb ON eo.branch_id = eb.id
    WHERE eo.exam_id = ?
");
$stmt->execute([$id]);
$outcomes = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Kazanım başına kitapçık haritaları
$maps_by_outcome = [];
if ($outcomes) {
    $outcome_ids = array_column($outcomes, 'id');
    $in_query = implode(',', array_fill(0, count($outcome_ids), '?'));

    $stmt = $pdo->prepare("
        SELECT m.*, b.code AS booklet_code
        FROM exam_outcome_booklet_map m
        JOIN exam_booklets b ON m.booklet_id = b.id
        WHERE m.outcome_id IN ($in_query)
        ORDER BY b.id
    ");
    $stmt->execute($outcome_ids);

    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $maps_by_outcome[$row['outcome_id']][] = $row;
    }

    // SIRALAMA: Branş > A kitapçığı soru no
    usort($outcomes, function ($a, $b) use ($maps_by_outcome) {
        $cmpBranch = strcasecmp((string)$a['branch_name'], (string)$b['branch_name']);
        if ($cmpBranch !== 0) return $cmpBranch;

        $getAQuestion = function ($outcomeId) use ($maps_by_outcome) {
            if (!isset($maps_by_outcome[$outcomeId])) return PHP_INT_MAX;
            foreach ($maps_by_outcome[$outcomeId] as $m) {
                if (!empty($m['booklet_code']) && $m['booklet_code'] === 'A') {
                    return (int)$m['question_no'];
                }
            }
            return PHP_INT_MAX;
        };

        $qA = $getAQuestion($a['id']);
        $qB = $getAQuestion($b['id']);
        if ($qA === $qB) return 0;
        return ($qA < $qB) ? -1 : 1;
    });
}

// Video çözümler (exam_id + branch_id + question_no)
$video_by_branch_q = [];
$video_data_by_branch_q = [];
try {
    $stmt = $pdo->prepare("SELECT id, branch_id, question_no, video_path, video_link FROM exam_question_videos WHERE exam_id = ?");
    $stmt->execute([$id]);
    while ($v = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $bId = (int)$v['branch_id'];
        $qNo = (int)$v['question_no'];
        if ($bId > 0 && $qNo > 0) {
            if (!empty($v['video_link'])) {
                $video_by_branch_q[$bId][$qNo] = (string)$v['video_link'];
                $video_data_by_branch_q[$bId][$qNo] = [
                    'id' => (int)$v['id'],
                    'type' => 'link',
                    'url' => (string)$v['video_link']
                ];
            } elseif (!empty($v['video_path'])) {
                $url = rtrim($base_url, '/') . '/' . ltrim((string)$v['video_path'], '/');
                $video_by_branch_q[$bId][$qNo] = $url;
                $video_data_by_branch_q[$bId][$qNo] = [
                    'id' => (int)$v['id'],
                    'type' => 'upload',
                    'url' => $url
                ];
            }
        }
    }
} catch (Exception $e) {
}

?>
<style>
/* === CSS BLOĞUN AYNEN DURUYOR, DOKUNMADIM === */
.exam-page-title { font-size: 24px; font-weight: 700; margin-bottom: 18px; color: #1f2933; }
/* KART TASARIMI */
.exam-header-card { background: #f8fafc; border-radius: 16px; padding: 22px 26px; box-shadow: 0 4px 14px rgba(15, 23, 42, 0.08); margin-bottom: 28px; }
/* SOL TARAF (Metin) */
.exam-header-title { font-size: 18px; font-weight: 700; color: #1f2937; margin-bottom: 6px; }
.exam-header-sub { font-size: 13px; color: #6b7280; margin-bottom: 18px; }
.exam-info-label { font-size: 12px; color: #6b7280; margin-bottom: 2px; }
.exam-info-value { font-size: 14px; font-weight: 500; color: #111827; }
/* DURUM BADGELERI */
.exam-status-badge { display: inline-block; padding: 4px 10px; border-radius: 999px; font-size: 12px; font-weight: 600; margin-right: 6px; }
.exam-status-active { background: #dcfce7; color: #15803d; }
.exam-status-passive { background: #fee2e2; color: #b91c1c; }
/* QR KOD */
.qr-title { font-size: 14px; font-weight: 600; margin-bottom: 10px; color: #1f2937; }
.exam-qr-box { border-radius: 14px; border: 1px solid #e5e7eb; padding: 12px; background: white; box-shadow: 0 2px 10px rgba(0,0,0,0.05); text-align: center; }
.exam-qr-desc { font-size: 12px; color: #6b7280; margin-top: 10px; text-align: center; max-width: 260px; }
/* EXCEL PANEL */
.excel-panel { background: #f7f9fc; border-radius: 10px; padding: 12px 16px; border: 1px solid #e1e5f0; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 12px; }
.excel-title { font-size: 14px; font-weight: 600; color: #1f4e79; }
.excel-hint { font-size: 12px; color: #7a8496; }
/* MODERN BUTONLAR */
.btn { border-radius: 999px !important; font-size: 13px; font-weight: 500; padding: 6px 14px; border: none; box-shadow: 0 2px 6px rgba(15, 23, 42, 0.18); transition: all 0.15s ease-in-out; }
.btn-sm { padding: 4px 10px; font-size: 12px; }
.btn-primary { background: linear-gradient(135deg, #2563eb, #1d4ed8); }
.btn-primary:hover { background: linear-gradient(135deg, #1d4ed8, #1e40af); transform: translateY(-1px); }
.btn-secondary { background: #6b7280; }
.btn-secondary:hover { background: #4b5563; transform: translateY(-1px); }
.btn-danger { background: #dc2626; }
.btn-danger:hover { background: #b91c1c; transform: translateY(-1px); }
.btn-success { background: #16a34a; }
.btn-success:hover { background: #15803d; transform: translateY(-1px); }
/* Tanımlı kazanımlar tablosunda sil butonu */
.btn-outcome-delete { padding: 2px 10px; font-size: 11px; box-shadow: none; }
/* ---------- MODERN TOGGLE SWITCH ----------- */
.toggle-wrapper { display: flex; align-items: center; gap: 8px; margin-top: 4px; }
.toggle-switch { position: relative; width: 44px; height: 24px; display: inline-block; }
.toggle-switch input { opacity: 0; width: 0; height: 0; }
.toggle-slider { position: absolute; cursor: pointer; top: 0; left: 0; right: 0; bottom: 0; background-color: #d1d5db; transition: 0.2s; border-radius: 999px; box-shadow: inset 0 0 0 1px rgba(148,163,184,0.7); }
.toggle-slider:before { position: absolute; content: ""; height: 18px; width: 18px; left: 3px; top: 3px; background-color: #ffffff; border-radius: 50%; transition: 0.2s; box-shadow: 0 1px 4px rgba(15,23,42,0.35); }
.toggle-switch input:checked + .toggle-slider { background: linear-gradient(135deg, #22c55e, #16a34a); box-shadow: inset 0 0 0 1px rgba(21,128,61,0.7); }
.toggle-switch input:checked + .toggle-slider:before { transform: translateX(18px); }
/* ========= MOBİL: TABLOLAR TAŞMASIN ========= */
.table-sm { width:100%; max-width:100%; border-collapse:collapse; }
@media (max-width: 900px){
    #outcomes-table, #defined-outcomes-table{ display:block; width:100%; overflow-x:auto; -webkit-overflow-scrolling: touch; background:#fff; border-radius:12px; }
    #outcomes-table th, #outcomes-table td, #defined-outcomes-table th, #defined-outcomes-table td{ white-space: nowrap; vertical-align: middle; }
    #outcomes-table input[type="text"], #outcomes-table input[type="number"], #outcomes-table select{ max-width: 180px; }
    #outcomes-table td div[style*="display:flex"] input[type="number"]{ width:72px !important; min-width:72px !important; }
    #outcomes-table td div[style*="display:flex"] select{ width:72px !important; min-width:72px !important; }
    #defined-outcomes-table td[style*="min-width:220px"]{ min-width:260px !important; }
}
@media (max-width: 520px){
    #outcomes-table th, #outcomes-table td, #defined-outcomes-table th, #defined-outcomes-table td{ font-size:12px; padding:6px 8px; }
}
</style>

<!-- ÜST KART: SOL METİN + SAĞ QR -->
<div class="exam-header-card">
    <div class="row d-flex align-items-start" style="justify-content: space-around;">
        <!-- SOL TARAF -->
        <div class="col-md-6">
            <div class="exam-header-title"><?php echo h($exam['name']); ?></div>

            <div class="exam-header-sub">
                ID: <?php echo (int)$exam['id']; ?> ·
                Deneme No: <?php echo h($exam['exam_number']); ?>
            </div>

            <div class="mb-3">
                <p class="exam-info-label">Barkod</p>
                <p class="exam-info-value"><?php echo h($exam['barcode']); ?></p>
            </div>

            <div class="mb-2">
                <p class="exam-info-label mb-1">Durum</p>
                <div class="toggle-wrapper">
                    <label class="toggle-switch mb-0">
                        <input type="checkbox" id="is-active-switch" data-exam-id="<?php echo (int)$exam['id']; ?>" <?php echo !empty($exam['is_active']) ? 'checked' : ''; ?>>
                        <span class="toggle-slider"></span>
                    </label>
                    <span id="status-text" style="font-size: 13px; color:#374151; margin-left: 8px;">
                        <?php echo !empty($exam['is_active']) ? 'Aktif' : 'Pasif'; ?>
                    </span>
                </div>
            </div>

            <!-- NET HESAPLAMA AYARI -->
            <hr style="margin: 14px 0;">

            <div style="font-size: 13px; font-weight: 600; color:#374151; margin-bottom:6px;">
                Net Hesaplama Ayarı
            </div>

            <form id="scoringForm" method="post" action="api/update_scoring.php" class="mb-2">
                <input type="hidden" name="exam_id" value="<?php echo (int)$exam['id']; ?>">

                <div class="toggle-wrapper">
                    <label class="toggle-switch mb-0">
                        <input type="checkbox" id="neg-scoring-switch" name="use_negative_scoring" <?php echo $useNegativeScoring ? 'checked' : ''; ?>>
                        <span class="toggle-slider"></span>
                    </label>
                    <span style="font-size: 13px; color:#374151;">
                        Yanlışlar doğruları götürsün
                    </span>
                </div>

                <div class="form-inline mt-2">
                    <label class="mr-2" style="font-size: 12px;">Kaç yanlış 1 doğruyu götürsün?</label>
                    <input type="number" min="1" name="wrong_per_minus" id="wrong_per_minus_input"
                           class="form-control form-control-sm" style="width:80px;"
                           value="<?php echo (int)$wrongPerMinus; ?>">
                </div>

                <small class="text-muted d-block mt-1" style="font-size: 11px;">
                    Örn: 4 yazarsanız “4 yanlış 1 doğruyu götürür”.
                </small>

                <button type="submit" class="btn btn-secondary btn-sm mt-2">
                    Net Ayarını Kaydet
                </button>
            </form>
        </div>

        <!-- SAĞ TARAF: QR KOD -->
        <div class="col-md-6 d-flex flex-column align-items-center justify-content-start">
            <div class="qr-title">QR Kod</div>

            <?php
            function seo_slug(string $s, int $maxLen = 80, string $fallback = 'deneme'): string {
                $s = trim($s);
                if ($s === '') return $fallback;
                $s = html_entity_decode($s, ENT_QUOTES | ENT_HTML5, 'UTF-8');
                $s = mb_strtolower($s, 'UTF-8');
                $trMap = [
                    'ğ'=>'g','Ğ'=>'g','ü'=>'u','Ü'=>'u','ş'=>'s','Ş'=>'s','ı'=>'i','İ'=>'i','ö'=>'o','Ö'=>'o','ç'=>'c','Ç'=>'c',
                ];
                $s = strtr($s, $trMap);
                if (function_exists('iconv')) {
                    $converted = @iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $s);
                    if ($converted !== false && $converted !== '') $s = $converted;
                }
                $s = str_replace('&', ' and ', $s);
                $s = preg_replace('/[^a-z0-9]+/i', '-', $s) ?? $s;
                $s = preg_replace('/-+/', '-', $s) ?? $s;
                $s = trim($s, '-');
                if ($maxLen > 0 && strlen($s) > $maxLen) {
                    $cut = substr($s, 0, $maxLen);
                    $cut = rtrim($cut, '-');
                    if (str_contains($cut, '-')) {
                        $cut = preg_replace('/-?[^-]*$/', '', $cut) ?: $cut;
                        $cut = trim($cut, '-');
                    }
                    $s = $cut;
                }
                return $s !== '' ? $s : $fallback;
            }

            // ✅ QR ID: gerçek id yerine (id * 12345)
            $slug = seo_slug((string)$exam['name'], 90, 'deneme');
            $qrId = ((int)$exam['id']) * 12345;
            $qrData = $base_url_qr . 'exam_view/' . $qrId . '/' . urlencode($slug);
            $qrUrl  = 'https://api.qrserver.com/v1/create-qr-code/?size=220x220&data=' . urlencode($qrData);
            ?>

            <a href="<?php echo h($qrData); ?>" target="_blank" rel="noopener noreferrer">
                <div class="exam-qr-box">
                    <img src="<?php echo h($qrUrl); ?>" alt="QR Kod" style="width:220px;height:220px;">
                </div>
            </a>

            <div class="exam-qr-desc">
                Bu QR, öğrenci optik okuma / sonuç sayfasına yönlendirme için kullanılabilir.
            </div>
        </div>
    </div>
</div>

<h3 class="mt-4">Kazanım Tanımla</h3>
<p class="muted">Excel şablonunu indirip doldurabilir veya aşağıdan manuel ekleme yapabilirsiniz.</p>

<!-- EXCEL PANEL -->
<div class="excel-panel mt-3 mb-4">
    <div>
        <form id="excelImportForm" method="post" action="api/import_outcomes_excel.php" enctype="multipart/form-data" class="mb-0">
            <input type="hidden" name="exam_id" value="<?php echo (int)$exam['id']; ?>">
            <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">

            <div class="excel-title">Excel'den Kazanım Yükle</div>
            <input type="file" name="excel_file" accept=".xlsx,.xls,.csv" class="form-control-file" style="font-size:13px;">
            <div class="excel-hint">Şablonu indirip doldurun, sonra buradan yükleyin.</div>

            <button type="submit" class="btn btn-primary btn-sm mt-2">Excel'den Yükle</button>
        </form>
    </div>

    <div>
        <a href="api/export_outcome_template.php?exam_id=<?php echo (int)$exam['id']; ?>" class="btn btn-secondary btn-sm">
            Şablonu İndir (Excel)
        </a>
        <div class="excel-hint mt-1">Kitapçıklara göre otomatik oluşturulur.</div>
    </div>
</div>

<!-- MANUEL KAZANIM GİRİŞİ -->
<form id="outcomesSaveForm" method="post" action="api/save_outcomes.php">
    <input type="hidden" name="exam_id" value="<?php echo (int)$exam['id']; ?>">

    <table class="table-sm" id="outcomes-table">
        <thead>
            <tr>
                <th>Branş</th>
                <th>Alt Branş</th>
                <?php foreach ($booklets as $b): ?>
                    <th>Kitapçık <?php echo h($b['code']); ?><br><span class="muted">Soru + Cevap</span></th>
                <?php endforeach; ?>
                <th>Kazanım Adı</th>
                <th>Kazanım Kodu</th>
                <th>Sil</th>
            </tr>
        </thead>

        <tbody>
            <tr>
                <td>
                    <select name="branch_id[]">
                        <?php foreach ($branches as $br): ?>
                            <option value="<?php echo (int)$br['id']; ?>"><?php echo h($br['name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </td>

                <td><input type="text" name="alt_branch_name[]"></td>

                <?php foreach ($booklets as $b): ?>
                    <td>
                        <div style="display:flex; gap:4px;">
                            <input type="number" name="booklet_<?php echo (int)$b['id']; ?>_qno[]" style="width:60px;">
                            <select name="booklet_<?php echo (int)$b['id']; ?>_ans[]" style="width:60px;">
                                <option value="">-</option>
                                <option value="A">A</option>
                                <option value="B">B</option>
                                <option value="C">C</option>
                                <option value="D">D</option>
                                <option value="E">E</option>
                            </select>
                        </div>
                    </td>
                <?php endforeach; ?>

                <td><input type="text" name="outcome_name[]"></td>
                <td><input type="text" name="outcome_code[]"></td>

                <td><button type="button" class="btn btn-danger btn-sm" onclick="removeOutcomeRow(this)">X</button></td>
            </tr>
        </tbody>
    </table>

    <button type="button" class="btn btn-secondary btn-sm mt-2" onclick="addOutcomeRow()">+ Satır Ekle</button>

    <div class="text-right mt-3">
        <button type="submit" class="btn btn-primary">Kazanımları Kaydet</button>
    </div>
</form>

<!-- TANIMLI KAZANIMLAR -->
<?php if (!empty($outcomes)): ?>
<!-- Toplu Video İşlemleri -->
<div style="margin: 20px 0; padding: 15px; background: #f8f9fa; border-radius: 8px;">
    <h4 style="margin: 0 0 12px; font-size: 16px; color: #333;">🎬 Toplu Video İşlemleri</h4>
    <div style="display:flex; gap:10px; flex-wrap:wrap; align-items:center;">
        <button type="button" id="bulkVideoUploadBtn" class="btn btn-primary">
            📤 Toplu Video Yükle
        </button>
        <button type="button" id="bulkVideoDeleteBtn" class="btn btn-danger">
            🗑️ Seçili Videoları Sil
        </button>
        <button type="button" id="downloadTemplateBtn" class="btn btn-success">
            📥 Şablon İndir
        </button>
        <label style="margin-left: 10px;">
            <input type="checkbox" id="selectAllVideos" style="width:18px;height:18px;cursor:pointer;">
            <span style="margin-left:5px;">Tümünü Seç</span>
        </label>
        <span id="selectedVideoCount" style="margin-left:10px; color:#666; font-weight:bold;"></span>
    </div>
</div>

    <h3 class="mt-4">Tanımlı Kazanımlar</h3>

    <div class="d-flex align-items-center mb-2" style="display: flex;gap:8px; flex-wrap:wrap;">
        <form id="deleteAllForm" method="post" action="api/delete_all_outcomes.php" class="mb-0" style="width: 15%;">
            <input type="hidden" name="exam_id" value="<?php echo (int)$exam['id']; ?>">
            <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
            <button class="btn btn-danger btn-sm">Tüm Kazanımları Sil</button>
        </form>

        <form method="post" action="api/export_outcomes_excel.php" style="display:inline;">
            <input type="hidden" name="exam_id" value="<?php echo (int)$exam['id']; ?>">
            <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
            <button type="submit" class="btn btn-success btn-sm">Tanımlı Kazanımları Excel Olarak İndir</button>
        </form>
    </div>

    <table class="table-sm" id="defined-outcomes-table">
        <thead>
            <tr>
                <th>Branş</th>
                <th>Alt Branş</th>
                <?php foreach ($booklets as $b): ?>
                    <th><?php echo h($b['code']); ?> Kitapçık</th>
                <?php endforeach; ?>
                <th>Kazanım Adı</th>
                <th>Kazanım Kodu</th>
                <th>Video Çözüm</th>
                <th>Sil</th>
            </tr>
        </thead>
        <tbody id="definedOutcomesTbody">
        <?php foreach ($outcomes as $o): ?>
            <tr data-outcome-id="<?php echo (int)$o['id']; ?>">
                <td><?php echo h($o['branch_name']); ?></td>
                <td><?php echo h($o['alt_branch_name']); ?></td>

                <?php
                    $maps = $maps_by_outcome[$o['id']] ?? [];
                    $byCode = [];
                    foreach ($maps as $m) $byCode[$m['booklet_code']] = $m;

                    foreach ($booklets as $b):
                        $cell = "";
                        if (isset($byCode[$b['code']])) {
                            $cell = $byCode[$b['code']]['question_no'];
                            if (!empty($byCode[$b['code']]['answer_option'])) {
                                $cell .= " / " . $byCode[$b['code']]['answer_option'];
                            }
                        }
                ?>
                    <td><?php echo h($cell); ?></td>
                <?php endforeach; ?>

                <td><?php echo h($o['outcome_name']); ?></td>
                <td><?php echo h($o['outcome_code']); ?></td>

                <?php
                    $videoQno = 0;
                    if (!empty($byCode['A']['question_no'])) {
                        $videoQno = (int)$byCode['A']['question_no'];
                    } elseif (!empty($byCode)) {
                        foreach ($byCode as $tmp) {
                            if (!empty($tmp['question_no'])) { $videoQno = (int)$tmp['question_no']; break; }
                        }
                    }
                    $videoUrl = null;
                    if ($videoQno > 0) {
                        $videoUrl = $video_by_branch_q[(int)$o['branch_id']][$videoQno] ?? null;
                    }
                ?>

                <td style="min-width:280px;">
                    <?php if ($videoQno > 0): 
                        $videoData = $video_data_by_branch_q[(int)$o['branch_id']][$videoQno] ?? null;
                        $videoId = $videoData ? $videoData['id'] : 0;
                    ?>
                        <div class="video-card-wrapper" style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;">
                            
                            <?php if ($videoUrl): ?>
                                <input 
                                    type="checkbox" 
                                    class="video-select-checkbox" 
                                    data-video-id="<?php echo (int)$videoId; ?>"
                                    data-exam-id="<?php echo (int)$exam['id']; ?>"
                                    data-branch-id="<?php echo (int)$o['branch_id']; ?>"
                                    data-question-no="<?php echo (int)$videoQno; ?>"
                                    style="width:18px; height:18px; cursor:pointer;"
                                >
                            <?php endif; ?>
                            
                            <label class="btn btn-secondary btn-sm" style="margin:0;">
                                📤
                                <input
                                    type="file"
                                    class="video-upload"
                                    accept="video/mp4,video/webm,video/quicktime"
                                    data-exam-id="<?php echo (int)$exam['id']; ?>"
                                    data-branch-id="<?php echo (int)$o['branch_id']; ?>"
                                    data-question-no="<?php echo (int)$videoQno; ?>"
                                    data-branch-name="<?php echo h($o['branch_name']); ?>"
                                    style="display:none;"
                                >
                            </label>

                            <button 
                                type="button" 
                                class="btn btn-info btn-sm video-link-btn"
                                data-exam-id="<?php echo (int)$exam['id']; ?>"
                                data-branch-id="<?php echo (int)$o['branch_id']; ?>"
                                data-question-no="<?php echo (int)$videoQno; ?>"
                                data-branch-name="<?php echo h($o['branch_name']); ?>"
                                title="YouTube, Vimeo vb. video linki ekle"
                                style="box-shadow:none;"
                            >
                                🔗
                            </button>

                            <small class="muted" style="font-size:11px;">S:<?php echo (int)$videoQno; ?></small>

                            <?php if ($videoUrl): ?>
                                <a class="btn btn-success btn-sm watch-video" href="<?php echo h($videoUrl); ?>" target="_blank" 
                                   title="<?php echo $videoData && $videoData['type'] === 'link' ? 'Link' : 'Yüklü Video'; ?>"
                                   data-video-id="<?php echo (int)$videoId; ?>">
                                    <?php if ($videoData && $videoData['type'] === 'link'): ?>
                                        🔗 İzle
                                    <?php else: ?>
                                        📹 İzle
                                    <?php endif; ?>
                                </a>

                                <button
                                    type="button"
                                    class="btn btn-danger btn-sm delete-video"
                                    data-exam-id="<?php echo (int)$exam['id']; ?>"
                                    data-branch-id="<?php echo (int)$o['branch_id']; ?>"
                                    data-question-no="<?php echo (int)$videoQno; ?>"
                                    style="box-shadow:none;"
                                >
                                    ❌
                                </button>
                            <?php else: ?>
                                <span class="badge badge-danger">Yok</span>
                            <?php endif; ?>

                            <small class="muted upload-status" style="display:none;"></small>
                        </div>
                    <?php else: ?>
                        <small class="muted">Soru no bulunamadı</small>
                    <?php endif; ?>

                <td>
                    <button
                        type="button"
                        class="btn btn-danger btn-sm btn-outcome-delete"
                        data-id="<?php echo (int)$o['id']; ?>"
                        data-exam="<?php echo (int)$exam['id']; ?>"
                    >
                        Sil
                    </button>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
<?php endif; ?>

<!-- SweetAlert2 -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
// SweetAlert2 toast yardımcıları
const SwalToast = Swal.mixin({
    toast: true,
    position: 'top-end',
    showConfirmButton: false,
    timer: 2200,
    timerProgressBar: true
});
function toastOk(msg){ SwalToast.fire({ icon:'success', title: msg || 'Başarılı' }); }
function toastInfo(msg){ SwalToast.fire({ icon:'info', title: msg || 'Bilgi' }); }

// Branş limitleri (limit = exam_branches.question_count)
const BRANCH_LIMITS = <?php
    $limits = [];
    foreach ($branches as $br) $limits[(int)$br['id']] = max(0, (int)$br['question_count']);
    echo json_encode($limits, JSON_UNESCAPED_UNICODE);
?>;

function getRowBranchId(tr) {
    const sel = tr.querySelector('select[name="branch_id[]"]');
    return sel ? parseInt(sel.value || '0', 10) : 0;
}
function isRowFilled(tr) {
    const outcomeName = tr.querySelector('input[name="outcome_name[]"]');
    const outcomeCode = tr.querySelector('input[name="outcome_code[]"]');
    const nameVal = (outcomeName ? outcomeName.value : '').trim();
    const codeVal = (outcomeCode ? outcomeCode.value : '').trim();
    if (nameVal !== '' || codeVal !== '') return true;

    const qnos = tr.querySelectorAll('input[name^="booklet_"][name$="_qno[]"]');
    for (const q of qnos) {
        if (String(q.value || '').trim() !== '') return true;
    }
    return false;
}
function countFilledRowsByBranch() {
    const rows = Array.from(document.querySelectorAll('#outcomes-table tbody tr'));
    const counts = {};
    for (const tr of rows) {
        const bid = getRowBranchId(tr);
        if (!bid) continue;
        if (!isRowFilled(tr)) continue;
        counts[bid] = (counts[bid] || 0) + 1;
    }
    return counts;
}
function branchNameById(bid) {
    const opt = document.querySelector(`#outcomes-table select[name="branch_id[]"] option[value="${bid}"]`);
    return opt ? opt.textContent.trim() : ('Branş #' + bid);
}
function showLimitAlert(bid, limit) {
    Swal.fire({
        icon: 'warning',
        title: 'Branş limiti doldu',
        html: `<b>${branchNameById(bid)}</b> için en fazla <b>${limit}</b> kazanım girebilirsiniz.`,
        confirmButtonText: 'Tamam'
    });
}

// Satır ekleme (limiti doluysa ekleme)
function addOutcomeRow() {
    const tbody = document.querySelector('#outcomes-table tbody');
    if (!tbody) return;

    const lastRow = tbody.querySelector('tr:last-child');
    const bid = lastRow ? getRowBranchId(lastRow) : 0;

    if (bid && BRANCH_LIMITS[bid]) {
        const counts = countFilledRowsByBranch();
        const filledCount = counts[bid] || 0;
        const limit = BRANCH_LIMITS[bid];

        if (filledCount >= limit) {
            showLimitAlert(bid, limit);
            return;
        }
    }

    const row = tbody.querySelector('tr');
    if (!row) return;

    const clone = row.cloneNode(true);
    clone.querySelectorAll("input").forEach(i => i.value = "");
    clone.querySelectorAll("select").forEach(s => s.selectedIndex = 0);
    tbody.appendChild(clone);
}
function removeOutcomeRow(btn) {
    const tr = btn.closest("tr");
    const tbody = tr.parentNode;
    if (tbody.children.length > 1) {
        tr.remove();
    } else {
        tr.querySelectorAll("input").forEach(i => i.value = "");
        tr.querySelectorAll("select").forEach(s => s.selectedIndex = 0);
    }
}

// AJAX ile tek satır silme
document.addEventListener('click', function (e) {
    if (!e.target.classList.contains('btn-outcome-delete')) return;

    const btn = e.target;
    const id = btn.getAttribute('data-id');
    const examId = btn.getAttribute('data-exam');

    Swal.fire({
        title: 'Emin misiniz?',
        text: 'Bu kazanım silinecek. Bu işlem geri alınamaz.',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Evet, sil',
        cancelButtonText: 'Vazgeç',
        reverseButtons: true
    }).then((res) => {
        if (!res.isConfirmed) return;

        const formData = new URLSearchParams();
        formData.append('ajax', '1');
        formData.append('action', 'delete_outcome');
        formData.append('id', id);
        formData.append('exam_id', examId);

        fetch('exam_detail.php?id=' + encodeURIComponent(examId), {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
            body: formData.toString()
        })
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                const row = btn.closest('tr');
                if (row) row.remove();
                toastOk('Silindi');
            } else {
                Swal.fire({ icon:'error', title:'Hata', text: (data.message || 'Silme işlemi başarısız oldu.') });
            }
        })
        .catch(err => {
            console.error(err);
            Swal.fire({ icon:'error', title:'Hata', text:'Silme sırasında bir hata oluştu.' });
        });
    });
});
</script>

<script>
// --- SAYFA YENİLEMEDEN TÜM İŞLEMLER (Excel yükle, manuel kaydet, toplu sil, net ayarı) ---

async function refreshDefinedOutcomes(examId) {
    const tbody = document.getElementById('definedOutcomesTbody');
    if (!tbody) return;

    const res = await fetch('api/outcomes_table_rows.php?exam_id=' + encodeURIComponent(examId), {
        headers: { 'Accept': 'application/json' }
    });
    const j = await res.json();
    if (!j.success) {
        Swal.fire({ icon:'error', title:'Hata', text: (j.message || 'Tablo yenilenemedi.') });
        return;
    }
    tbody.innerHTML = j.html || '';
}

function setBusy(btn, busy, label) {
    if (!btn) return;
    btn.disabled = !!busy;
    if (busy) {
        btn.dataset._oldText = btn.textContent;
        if (label) btn.textContent = label;
    } else {
        if (btn.dataset._oldText) btn.textContent = btn.dataset._oldText;
    }
}

document.addEventListener('DOMContentLoaded', function () {
    const examId = <?php echo (int)$exam['id']; ?>;

    // Net ayarı switch'e göre input'u aktif/pasif et
    (function() {
        var sw = document.getElementById('neg-scoring-switch');
        var input = document.getElementById('wrong_per_minus_input');
        if (!sw || !input) return;
        function toggleInput() { input.disabled = !sw.checked; }
        sw.addEventListener('change', toggleInput);
        toggleInput();
    })();

    // Excel import (AJAX)
    const excelForm = document.getElementById('excelImportForm');
    if (excelForm) {
        excelForm.addEventListener('submit', async function (e) {
            e.preventDefault();

            const btn = excelForm.querySelector('button[type="submit"]');
            setBusy(btn, true, 'Yükleniyor...');

            const formData = new FormData(excelForm);
            formData.append('ajax', '1');
            formData.append('csrf_token', '<?= csrf_token() ?>');

            try {
                const res = await fetch(excelForm.action, { method: 'POST', body: formData });
                const j = await res.json();

                if (!j.success) {
                    Swal.fire({ icon:'error', title:'Hata', text: (j.message || 'Excel yükleme başarısız.') });
                    return;
                }

                await refreshDefinedOutcomes(examId);

                const file = excelForm.querySelector('input[type="file"]');
                if (file) file.value = '';

                toastOk('Yüklendi');

                const info = [];
                if (typeof j.inserted !== 'undefined') info.push('Eklenen: ' + j.inserted);
                if (typeof j.skipped !== 'undefined') info.push('Atlanan: ' + j.skipped);
                if (typeof j.unknown_branch !== 'undefined') info.push('Bilinmeyen branş: ' + j.unknown_branch);
                if (info.length) toastInfo(info.join(' · '));

                // over_limit desteği varsa uyar
                if (j.over_limit && parseInt(j.over_limit, 10) > 0) {
                    const summary = Array.isArray(j.over_limit_summary) ? j.over_limit_summary : [];
                    const rows = Array.isArray(j.over_limit_rows) ? j.over_limit_rows : [];

                    let html = `<div style="text-align:left;font-size:13px;">
                        <p><b>${j.over_limit}</b> satır, branş limitleri nedeniyle içe aktarılmadı.</p>`;

                    if (summary.length) {
                        html += `<div style="margin:8px 0 10px 0;"><b>Özet:</b><ul style="margin:6px 0 0 18px;">`;
                        summary.forEach(s => html += `<li>${String(s)}</li>`);
                        html += `</ul></div>`;
                    }

                    if (rows.length) {
                        html += `<div style="margin-top:8px;"><b>Örnek satırlar:</b>
                            <div style="margin-top:6px; max-height:180px; overflow:auto; border:1px solid #e5e7eb; border-radius:8px; padding:8px; background:#f9fafb;">`;
                        rows.forEach(r => {
                            html += `<div style="margin-bottom:6px;">
                                <span style="font-weight:600;">Satır ${r.row}</span> · ${String(r.branch)} · limit ${r.limit} · mevcut ${r.current} · kod: ${String(r.outcome_code || '')}
                            </div>`;
                        });
                        html += `</div></div>`;
                    }

                    html += `</div>`;

                    Swal.fire({
                        icon: 'warning',
                        title: 'Limit Aşıldı',
                        html: html,
                        confirmButtonText: 'Tamam'
                    });
                }

            } catch (err) {
                console.error(err);
                Swal.fire({ icon:'error', title:'Hata', text:'Excel yüklemede hata oluştu.' });
            } finally {
                setBusy(btn, false);
            }
        });
    }

    // Manuel kaydet (AJAX) + limit kontrol
    const saveForm = document.getElementById('outcomesSaveForm');
    if (saveForm) {
        saveForm.addEventListener('submit', async function (e) {
            const counts = countFilledRowsByBranch();
            for (const bidStr of Object.keys(counts)) {
                const bid = parseInt(bidStr, 10);
                const limit = BRANCH_LIMITS[bid];
                if (!limit) continue;
                if (counts[bid] > limit) {
                    e.preventDefault();
                    Swal.fire({
                        icon: 'error',
                        title: 'Limit aşıldı',
                        html: `<b>${branchNameById(bid)}</b> için <b>${limit}</b> kazanım hakkı var.<br>
                               Siz <b>${counts[bid]}</b> kazanım girmişsiniz.`,
                        confirmButtonText: 'Tamam'
                    });
                    return;
                }
            }

            e.preventDefault();

            const btn = saveForm.querySelector('button[type="submit"]');
            setBusy(btn, true, 'Kaydediliyor...');

            const formData = new FormData(saveForm);
            formData.append('csrf_token', '<?= csrf_token() ?>');
            formData.append('ajax', '1');

            try {
                const res = await fetch(saveForm.action, { method: 'POST', body: formData });
                const j = await res.json();

                if (!j.success) {
                    Swal.fire({ icon:'error', title:'Hata', text: (j.message || 'Kayıt başarısız.') });
                    return;
                }

                await refreshDefinedOutcomes(examId);

                // Form satırlarını temizle (tek satır bırak)
                const tbody = document.querySelector('#outcomes-table tbody');
                if (tbody) {
                    const rows = Array.from(tbody.querySelectorAll('tr'));
                    rows.slice(1).forEach(r => r.remove());
                    const first = rows[0];
                    if (first) {
                        first.querySelectorAll('input').forEach(i => i.value = '');
                        first.querySelectorAll('select').forEach(s => s.selectedIndex = 0);
                    }
                }

                toastOk('Kaydedildi');

            } catch (err) {
                console.error(err);
                Swal.fire({ icon:'error', title:'Hata', text:'Kaydetme sırasında hata oluştu.' });
            } finally {
                setBusy(btn, false);
            }
        });
    }

    // Toplu sil
    const delAllForm = document.getElementById('deleteAllForm');
    if (delAllForm) {
        delAllForm.addEventListener('submit', async function (e) {
            e.preventDefault();

            const ask = await Swal.fire({
                title: 'Emin misiniz?',
                text: 'Tüm kazanımlar silinecek. Bu işlem geri alınamaz.',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Evet, sil',
                cancelButtonText: 'Vazgeç',
                reverseButtons: true
            });
            if (!ask.isConfirmed) return;

            const btn = delAllForm.querySelector('button[type="submit"]');
            setBusy(btn, true, 'Siliniyor...');

            const formData = new FormData(delAllForm);
            formData.append('ajax', '1');

            try {
                const res = await fetch(delAllForm.action, { method: 'POST', body: formData });
                const j = await res.json();

                if (!j.success) {
                    Swal.fire({ icon:'error', title:'Hata', text: (j.message || 'Silme başarısız.') });
                    return;
                }

                await refreshDefinedOutcomes(examId);
                toastOk('Silindi');

            } catch (err) {
                console.error(err);
                Swal.fire({ icon:'error', title:'Hata', text:'Toplu silme sırasında hata oluştu.' });
            } finally {
                setBusy(btn, false);
            }
        });
    }

    // Net ayarı kaydet
    const scoringForm = document.getElementById('scoringForm');
    if (scoringForm) {
        scoringForm.addEventListener('submit', async function (e) {
            e.preventDefault();

            const btn = scoringForm.querySelector('button[type="submit"]');
            setBusy(btn, true, 'Kaydediliyor...');

            const formData = new FormData(scoringForm);
            formData.append('ajax', '1');

            try {
                const res = await fetch(scoringForm.action, { method: 'POST', body: formData });
                const j = await res.json();

                if (!j.success) {
                    Swal.fire({ icon:'error', title:'Hata', text: (j.message || 'Net ayarı kaydedilemedi.') });
                    return;
                }

                toastOk('Net ayarı kaydedildi');

            } catch (err) {
                console.error(err);
                Swal.fire({ icon:'error', title:'Hata', text:'Net ayarı kaydında hata oluştu.' });
            } finally {
                setBusy(btn, false);
            }
        });
    }

    // Branş seçimi değişince anlık uyarı (opsiyonel)
    document.addEventListener('change', function(ev) {
        const el = ev.target;
        if (!el.matches('select[name="branch_id[]"]')) return;

        const tr = el.closest('tr');
        const bid = getRowBranchId(tr);
        if (!bid || !BRANCH_LIMITS[bid]) return;

        const counts = countFilledRowsByBranch();
        const limit = BRANCH_LIMITS[bid];

        if (isRowFilled(tr) && (counts[bid] > limit)) {
            Swal.fire({
                icon: 'warning',
                title: 'Dikkat',
                html: `<b>${branchNameById(bid)}</b> için limit <b>${limit}</b>. Şu an <b>${counts[bid]}</b> oldu.`,
                confirmButtonText: 'Tamam'
            });
        }
    });
});
</script>

<script>
// Video upload (anlık) - Progress Bar ile
document.addEventListener('change', async function (e) {
    const input = e.target;
    if (!input.classList.contains('video-upload')) return;

    const file = input.files && input.files[0];
    if (!file) return;

    const wrap = input.closest('td');
    const status = wrap ? wrap.querySelector('.upload-status') : null;
    
    // Progress bar elementi oluştur
    let progressBar = wrap.querySelector('.upload-progress');
    if (!progressBar) {
        progressBar = document.createElement('div');
        progressBar.className = 'upload-progress';
        progressBar.style.cssText = 'width:100%;height:20px;background:#e0e0e0;border-radius:4px;margin:5px 0;overflow:hidden;display:none;';
        
        const progressFill = document.createElement('div');
        progressFill.className = 'progress-fill';
        progressFill.style.cssText = 'height:100%;background:linear-gradient(90deg, #4CAF50, #45a049);transition:width 0.3s;width:0%;text-align:center;color:white;font-size:12px;line-height:20px;';
        
        progressBar.appendChild(progressFill);
        wrap.querySelector('div').appendChild(progressBar);
    }
    
    const progressFill = progressBar.querySelector('.progress-fill');
    progressBar.style.display = 'block';
    progressFill.style.width = '0%';
    progressFill.textContent = '0%';
    
    if (status) {
        status.style.display = 'inline-block';
        status.textContent = 'Hazırlanıyor...';
    }

    const fd = new FormData();
    fd.append('exam_id', input.dataset.examId);
    fd.append('branch_id', input.dataset.branchId);
    fd.append('question_no', input.dataset.questionNo);
    fd.append('video', file);
    fd.append('csrf_token', '<?= csrf_token() ?>');

    try {
        // XMLHttpRequest kullanarak progress tracking
        const xhr = new XMLHttpRequest();
        
        // Upload progress
        xhr.upload.addEventListener('progress', function(e) {
            if (e.lengthComputable) {
                const percentComplete = Math.round((e.loaded / e.total) * 100);
                progressFill.style.width = percentComplete + '%';
                progressFill.textContent = percentComplete + '%';
                
                if (status) {
                    const uploadedMB = (e.loaded / 1024 / 1024).toFixed(1);
                    const totalMB = (e.total / 1024 / 1024).toFixed(1);
                    status.textContent = `Yükleniyor... ${uploadedMB}MB / ${totalMB}MB`;
                }
            }
        });
        
        // Response handler
        xhr.addEventListener('load', function() {
            if (xhr.status === 200) {
                try {
                    const j = JSON.parse(xhr.responseText);
                    
                    if (!j.success) {
                        progressBar.style.display = 'none';
                        if (status) status.textContent = j.message || 'Yükleme başarısız.';
                        Swal.fire({ icon:'error', title:'Hata', text: (j.message || 'Yükleme başarısız.') });
                        return;
                    }
                    
                    progressFill.style.width = '100%';
                    progressFill.textContent = '100%';
                    
                    setTimeout(() => {
                        progressBar.style.display = 'none';
                    }, 1000);
                    
                    if (status) status.textContent = 'Kaydedildi ✓';
                    toastOk('Video yüklendi');

                    let watch = wrap.querySelector('a.watch-video');
                    if (!watch) {
                        watch = document.createElement('a');
                        watch.className = 'btn btn-success btn-sm watch-video';
                        watch.target = '_blank';
                        watch.textContent = 'İzle';
                        wrap.querySelector('div').insertBefore(watch, status);
                    }
                    watch.href = j.url;

                    let delBtn = wrap.querySelector('button.delete-video');
                    if (!delBtn) {
                        delBtn = document.createElement('button');
                        delBtn.type = 'button';
                        delBtn.className = 'btn btn-danger btn-sm delete-video';
                        delBtn.textContent = 'Sil';
                        delBtn.style.boxShadow = 'none';
                        delBtn.dataset.examId = input.dataset.examId;
                        delBtn.dataset.branchId = input.dataset.branchId;
                        delBtn.dataset.questionNo = input.dataset.questionNo;
                        wrap.querySelector('div').insertBefore(delBtn, status);
                    } else {
                        delBtn.dataset.examId = input.dataset.examId;
                        delBtn.dataset.branchId = input.dataset.branchId;
                        delBtn.dataset.questionNo = input.dataset.questionNo;
                    }

                    const badge = wrap.querySelector('.badge-danger');
                    if (badge) badge.remove();

                    input.value = '';
                    
                } catch (parseErr) {
                    progressBar.style.display = 'none';
                    if (status) status.textContent = 'Parse hatası';
                    Swal.fire({ icon:'error', title:'Hata', text:'Yanıt işlenemedi.' });
                }
            } else {
                progressBar.style.display = 'none';
                if (status) status.textContent = 'HTTP Hata: ' + xhr.status;
                Swal.fire({ icon:'error', title:'Hata', text:'Sunucu hatası: ' + xhr.status });
            }
        });
        
        // Error handler
        xhr.addEventListener('error', function() {
            progressBar.style.display = 'none';
            if (status) status.textContent = 'Bağlantı hatası';
            Swal.fire({ icon:'error', title:'Hata', text:'Yükleme sırasında hata oluştu.' });
        });
        
        // Abort handler
        xhr.addEventListener('abort', function() {
            progressBar.style.display = 'none';
            if (status) status.textContent = 'İptal edildi';
        });
        
        // Send request
        xhr.open('POST', 'api/upload_video.php', true);
        xhr.send(fd);
        
    } catch (err) {
        if (progressBar) progressBar.style.display = 'none';
        if (status) status.textContent = 'Hata: ' + (err && err.message ? err.message : 'Bilinmeyen');
        Swal.fire({ icon:'error', title:'Hata', text:'Yükleme sırasında hata oluştu.' });
    }
});
</script>

<script>
// Video silme (anlık)
document.addEventListener('click', async function (e) {
    const btn = e.target;
    if (!btn.classList.contains('delete-video')) return;

    const ask = await Swal.fire({
        title: 'Emin misiniz?',
        text: 'Bu videoyu silmek istediğinize emin misiniz?',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Evet, sil',
        cancelButtonText: 'Vazgeç',
        reverseButtons: true
    });
    if (!ask.isConfirmed) return;

    const td = btn.closest('td');
    const examId = btn.dataset.examId;
    const branchId = btn.dataset.branchId;
    const questionNo = btn.dataset.questionNo;

    const status = td ? td.querySelector('.upload-status') : null;
    if (status) {
        status.style.display = 'inline-block';
        status.textContent = 'Siliniyor...';
    }

    const fd = new FormData();
    fd.append('exam_id', examId);
    fd.append('branch_id', branchId);
    fd.append('question_no', questionNo);
    fd.append('csrf_token', '<?= csrf_token() ?>');

    try {
        const res = await fetch('api/delete_video.php', { method: 'POST', body: fd });
        const j = await res.json();

        if (!j.success) {
            if (status) status.textContent = j.message || 'Silme başarısız.';
            Swal.fire({ icon:'error', title:'Hata', text: (j.message || 'Silme başarısız.') });
            return;
        }

        const watch = td.querySelector('a.watch-video');
        if (watch) watch.remove();

        btn.remove();

        if (!td.querySelector('.badge-danger')) {
            const badge = document.createElement('span');
            badge.className = 'badge badge-danger';
            badge.textContent = 'Yok';
            const container = td.querySelector('div');
            if (container) container.insertBefore(badge, status || null);
            else td.appendChild(badge);
        }

        if (status) status.textContent = 'Silindi.';
        toastOk('Silindi');

    } catch (err) {
        if (status) status.textContent = 'Hata: ' + (err && err.message ? err.message : 'Bilinmeyen');
        Swal.fire({ icon:'error', title:'Hata', text:'Silme sırasında hata oluştu.' });
    }
});
</script>

<script>
// ==========================================
// VIDEO ÖZELLİKLERİ ENHANCEMENT - Videos işlemleri için gerekli değişkenler
window.examId = <?php echo (int)($exam['id'] ?? 0); ?>;

// TEST: Console'a log bas

window.examId = <?php echo (int)($exam['id'] ?? 0); ?>;
window.csrfToken = '<?php echo csrf_token(); ?>';

// Butonların varlığını kontrol et




// ==========================================
// 3. VIDEO LINK EKLEME
// ==========================================
document.addEventListener('click', function(e) {
    const btn = e.target.closest('.video-link-btn');
    if (!btn) return;
    
    const examId = btn.dataset.examId;
    const branchId = btn.dataset.branchId;
    const questionNo = btn.dataset.questionNo;
    
    Swal.fire({
        title: 'Video Linki Ekle',
        html: `
            <p style="text-align:left; margin-bottom:10px; color:#666; font-size:14px;">
                YouTube, Google Drive, Vimeo veya başka bir video linkini yapıştırın:
            </p>
            <input type="url" id="videoLinkInput" class="swal2-input" 
                   placeholder="https://youtube.com/... veya https://drive.google.com/..."
                   style="width:90%; font-size:14px;">
            <p style="text-align:left; margin-top:10px; color:#999; font-size:12px;">
                💡 Link kaydedilirse, sunucuya video yüklenmeye gerek kalmaz.
            </p>
        `,
        showCancelButton: true,
        confirmButtonText: 'Kaydet',
        cancelButtonText: 'İptal',
        preConfirm: () => {
            const link = document.getElementById('videoLinkInput').value.trim();
            if (!link) {
                Swal.showValidationMessage('Link boş olamaz');
                return false;
            }
            if (!link.startsWith('http://') && !link.startsWith('https://')) {
                Swal.showValidationMessage('Link http:// veya https:// ile başlamalı');
                return false;
            }
            return link;
        }
    }).then((result) => {
        if (result.isConfirmed) {
            saveVideoLink(examId, branchId, questionNo, result.value);
        }
    });
});

function saveVideoLink(examId, branchId, questionNo, link) {
    const formData = new FormData();
    formData.append('csrf_token', window.csrfToken);
    formData.append('exam_id', examId);
    formData.append('branch_id', branchId);
    formData.append('question_no', questionNo);
    formData.append('video_link', link);
    
    Swal.fire({
        title: 'Kaydediliyor...',
        allowOutsideClick: false,
        didOpen: () => Swal.showLoading()
    });
    
    fetch('api/save_video_link.php', {
        method: 'POST',
        body: formData
    })
    .then(r => r.json())
    .then(j => {
        if (j.success) {
            Swal.fire({
                icon: 'success',
                title: 'Başarılı',
                text: j.message || 'Link kaydedildi',
                timer: 1500,
                showConfirmButton: false
            });
            
            // Sayfa yenileme yerine tabloyu güncelle
            updateVideoInTable(branchId, questionNo, link, 'link');
        } else {
            Swal.fire('Hata', j.message || 'Link kaydedilemedi', 'error');
        }
    })
    .catch(err => {
        console.error(err);
        Swal.fire('Hata', 'Bağlantı hatası', 'error');
    });
}

function updateVideoInTable(branchId, questionNo, videoUrl, type) {
    // Video input'u bul
    const videoInput = document.querySelector(
        `.video-upload[data-branch-id="${branchId}"][data-question-no="${questionNo}"]`
    );
    
    if (!videoInput) return;
    
    const td = videoInput.closest('td');
    if (!td) return;
    
    // "Yok" badge'ini kaldır
    const noBadge = td.querySelector('.badge-danger');
    if (noBadge) noBadge.remove();
    
    // İzle ve Sil butonları ekle
    const videoCard = td.querySelector('.video-card-wrapper');
    if (videoCard) {
        // Checkbox ekle (eğer yoksa)
        if (!videoCard.querySelector('.video-select-checkbox')) {
            const checkbox = document.createElement('input');
            checkbox.type = 'checkbox';
            checkbox.className = 'video-select-checkbox';
            checkbox.dataset.videoId = '0'; // Yeni, ID yok
            checkbox.dataset.examId = branchId;
            checkbox.dataset.branchId = branchId;
            checkbox.dataset.questionNo = questionNo;
            checkbox.style.cssText = 'width:18px; height:18px; cursor:pointer;';
            videoCard.insertBefore(checkbox, videoCard.firstChild);
        }
        
        // İzle butonu ekle
        const watchBtn = document.createElement('a');
        watchBtn.className = 'btn btn-success btn-sm watch-video';
        watchBtn.href = videoUrl;
        watchBtn.target = '_blank';
        watchBtn.dataset.videoId = '0';
        watchBtn.innerHTML = type === 'link' ? '🔗 İzle' : '📹 İzle';
        watchBtn.title = type === 'link' ? 'Link' : 'Yüklü Video';
        
        // Sil butonu ekle
        const delBtn = document.createElement('button');
        delBtn.type = 'button';
        delBtn.className = 'btn btn-danger btn-sm delete-video';
        delBtn.dataset.examId = branchId;
        delBtn.dataset.branchId = branchId;
        delBtn.dataset.questionNo = questionNo;
        delBtn.style.cssText = 'box-shadow:none;';
        delBtn.innerHTML = '❌';
        
        // "S:X" label'dan sonra ekle
        const smallLabel = videoCard.querySelector('small');
        if (smallLabel) {
            smallLabel.after(watchBtn, ' ', delBtn);
        }
    }
}

// ==========================================
// 4. TOPLU VIDEO YÜKLEME
// ==========================================
document.getElementById('bulkVideoUploadBtn')?.addEventListener('click', function() {
    const input = document.createElement('input');
    input.type = 'file';
    input.multiple = true;
    input.accept = 'video/mp4,video/webm,video/quicktime';
    
    input.addEventListener('change', function() {
        if (this.files.length === 0) return;
        
        // Boş slotları bul - branch name ile
        const emptySlots = [];
        document.querySelectorAll('.video-upload').forEach(input => {
            const parent = input.parentElement.parentElement;
            const hasVideo = parent.querySelector('.watch-video');
            if (!hasVideo) {
                emptySlots.push({
                    input: input,
                    examId: input.dataset.examId,
                    branchId: input.dataset.branchId,
                    branchName: input.dataset.branchName || 'Bilinmeyen',
                    questionNo: input.dataset.questionNo
                });
            }
        });
        
        if (emptySlots.length === 0) {
            Swal.fire('Bilgi', 'Tüm sorularda zaten video var', 'info');
            return;
        }
        
        // Dosya isimlerine göre eşleştir
        const matches = [];
        const files = Array.from(this.files);
        
        files.forEach(file => {
            const filename = file.name.replace(/\.[^/.]+$/, ""); // Uzantıyı çıkar
            
            // Format: BransAdi_SoruNo veya bransadi_soruno
            const parts = filename.split('_');
            if (parts.length >= 2) {
                const fileBranchName = parts.slice(0, -1).join('_'); // Son kısım dışındaki her şey branch name
                const fileQuestionNo = parts[parts.length - 1];
                
                // Eşleşen slotu bul
                const slot = emptySlots.find(s => 
                    s.branchName.toLowerCase() === fileBranchName.toLowerCase() &&
                    s.questionNo === fileQuestionNo
                );
                
                if (slot) {
                    matches.push({ file, slot });
                }
            }
        });
        
        if (matches.length === 0) {
            Swal.fire({
                icon: 'warning',
                title: 'Eşleşme Bulunamadı',
                html: `
                    <p>Video dosya isimleri şu formatta olmalı:</p>
                    <p style="margin:10px 0;"><strong>BransAdi_SoruNo.mp4</strong></p>
                    <p style="font-size:12px; color:#666;">
                        Örnek: Fizik_5.mp4, Kimya_12.mp4
                    </p>
                    <hr style="margin:15px 0;">
                    <p style="font-size:13px; text-align:left;">Beklenen format:</p>
                    <ul style="font-size:12px; text-align:left; color:#666;">
                        ${emptySlots.slice(0, 3).map(s => `<li>${s.branchName}_${s.questionNo}.mp4</li>`).join('')}
                    </ul>
                `
            });
            return;
        }
        
        Swal.fire({
            title: 'Toplu Video Yükleme',
            html: `
                <p style="color:#10b981; font-weight:600;">${matches.length} eşleşme bulundu!</p>
                <p style="font-size:13px; margin-top:10px;">${this.files.length} dosyadan ${matches.length} tanesi yüklenecek.</p>
                <hr style="margin:12px 0;">
                <div style="max-height:150px; overflow-y:auto; text-align:left; font-size:12px;">
                    ${matches.map(m => `<div>✓ ${m.file.name} → ${m.slot.branchName} Soru ${m.slot.questionNo}</div>`).join('')}
                </div>
            `,
            showCancelButton: true,
            confirmButtonText: 'Yükle',
            cancelButtonText: 'İptal'
        }).then((result) => {
            if (result.isConfirmed) {
                bulkUploadVideos(matches);
            }
        });
    });
    
    input.click();
});

function bulkUploadVideos(matches) {
    let completed = 0;
    let errors = 0;
    
    Swal.fire({
        title: 'Yükleniyor...',
        html: `<div id="bulkUploadProgress">0 / ${matches.length}</div>`,
        allowOutsideClick: false,
        didOpen: () => Swal.showLoading()
    });
    
    matches.forEach((match, index) => {
        uploadSingleVideo(match.file, match.slot, () => {
            completed++;
            const progressDiv = document.getElementById('bulkUploadProgress');
            if (progressDiv) {
                progressDiv.textContent = `${completed} / ${matches.length}${errors > 0 ? ` (${errors} hata)` : ''}`;
            }
            
            if (completed === matches.length) {
                setTimeout(() => {
                    Swal.fire({
                        icon: errors > 0 ? 'warning' : 'success',
                        title: 'Tamamlandı',
                        html: `${completed - errors} video yüklendi${errors > 0 ? `, ${errors} hata` : ''}`,
                        confirmButtonText: 'Sayfayı Yenile'
                    }).then(() => location.reload());
                }, 500);
            }
        }, () => {
            errors++;
            completed++;
            const progressDiv = document.getElementById('bulkUploadProgress');
            if (progressDiv) {
                progressDiv.textContent = `${completed} / ${matches.length} (${errors} hata)`;
            }
        });
    });
}

function uploadSingleVideo(file, slot, onSuccess, onError) {
    const formData = new FormData();
    formData.append('csrf_token', window.csrfToken);
    formData.append('exam_id', slot.examId);
    formData.append('branch_id', slot.branchId);
    formData.append('question_no', slot.questionNo);
    formData.append('video', file);
    
    fetch('api/upload_video.php', {
        method: 'POST',
        body: formData
    })
    .then(r => r.json())
    .then(j => {
        if (j.success) {
            onSuccess();
        } else {
            onError();
        }
    })
    .catch(onError);
}

// ==========================================
// 5. TOPLU VIDEO SILME
// ==========================================
document.getElementById('bulkVideoDeleteBtn')?.addEventListener('click', function() {
    const checked = document.querySelectorAll('.video-select-checkbox:checked');
    
    if (checked.length === 0) {
        Swal.fire('Uyarı', 'Silinecek video seçilmedi', 'warning');
        return;
    }
    
    // Video ID'lerini topla (şimdilik row index kullanacağız)
    const toDelete = [];
    checked.forEach(cb => {
        const card = cb.closest('div');
        const delBtn = card.querySelector('.delete-video');
        if (delBtn) {
            toDelete.push({
                examId: delBtn.dataset.examId,
                branchId: delBtn.dataset.branchId,
                questionNo: delBtn.dataset.questionNo
            });
        }
    });
    
    if (toDelete.length === 0) {
        Swal.fire('Uyarı', 'Silinecek video bulunamadı', 'warning');
        return;
    }
    
    Swal.fire({
        title: 'Emin misiniz?',
        html: `<b>${toDelete.length}</b> video silinecek. Bu işlem geri alınamaz!`,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Evet, Sil',
        cancelButtonText: 'İptal',
        confirmButtonColor: '#d33'
    }).then((result) => {
        if (result.isConfirmed) {
            bulkDeleteVideos(toDelete);
        }
    });
});

function bulkDeleteVideos(toDelete) {
    Swal.fire({
        title: 'Siliniyor...',
        html: `<div id="bulkDeleteProgress">0 / ${toDelete.length}</div>`,
        allowOutsideClick: false,
        didOpen: () => Swal.showLoading()
    });
    
    let completed = 0;
    let errors = 0;
    
    toDelete.forEach((item, index) => {
        const formData = new FormData();
        formData.append('csrf_token', window.csrfToken);
        formData.append('exam_id', item.examId);
        formData.append('branch_id', item.branchId);
        formData.append('question_no', item.questionNo);
        
        fetch('api/delete_video.php', {
            method: 'POST',
            body: formData
        })
        .then(r => r.json())
        .then(j => {
            completed++;
            const progressDiv = document.getElementById('bulkDeleteProgress');
            if (progressDiv) {
                progressDiv.textContent = `${completed} / ${toDelete.length}${errors > 0 ? ` (${errors} hata)` : ''}`;
            }
            
            if (!j.success) errors++;
            
            if (completed === toDelete.length) {
                setTimeout(() => {
                    Swal.fire({
                        icon: errors > 0 ? 'warning' : 'success',
                        title: 'Tamamlandı',
                        html: `${completed - errors} video silindi${errors > 0 ? `, ${errors} hata` : ''}`,
                        confirmButtonText: 'Sayfayı Yenile'
                    }).then(() => location.reload());
                }, 500);
            }
        })
        .catch(err => {
            errors++;
            completed++;
        });
    });
}

// ==========================================
// 6. TÜMÜNÜ SEÇ/BIRAK
// ==========================================
document.getElementById('selectAllVideos')?.addEventListener('change', function() {
    document.querySelectorAll('.video-select-checkbox').forEach(cb => {
        cb.checked = this.checked;
    });
    updateSelectedVideoCount();
});

// ==========================================
// 7. SEÇİLİ VIDEO SAYISINI GÖSTER
// ==========================================
document.addEventListener('change', function(e) {
    if (e.target.classList.contains('video-select-checkbox')) {
        updateSelectedVideoCount();
    }
});

function updateSelectedVideoCount() {
    const checked = document.querySelectorAll('.video-select-checkbox:checked');
    const countSpan = document.getElementById('selectedVideoCount');
    if (countSpan) {
        if (checked.length > 0) {
            countSpan.textContent = `${checked.length} video seçildi`;
            countSpan.style.color = '#2196F3';
        } else {
            countSpan.textContent = '';
        }
    }
}

// ==========================================
// 8. "KAYDEDİLDİ ✓" OTOMATİK GİZLENME
// ==========================================
const originalUploadHandler = window.handleVideoUpload;
if (originalUploadHandler) {
    window.handleVideoUpload = function(...args) {
        const result = originalUploadHandler.apply(this, args);
        
        // Status mesajını 2 saniye sonra gizle
        setTimeout(() => {
            document.querySelectorAll('.upload-status').forEach(status => {
                if (status.textContent.includes('Kaydedildi')) {
                    status.style.display = 'none';
                }
            });
        }, 2000);
        
        return result;
    };
}


// ==========================================
// IS_ACTIVE TOGGLE - Denemeyi Aktif/Pasif Yap
// ==========================================
document.getElementById('is-active-switch')?.addEventListener('change', async function() {
    const examId = this.dataset.examId;
    const isActive = this.checked ? 1 : 0;
    const statusText = document.getElementById('status-text');
    
    try {
        const formData = new FormData();
        formData.append('csrf_token', window.csrfToken);
        formData.append('exam_id', examId);
        formData.append('is_active', isActive);
        
        const response = await fetch('api/toggle_exam_status.php', {
            method: 'POST',
            body: formData
        });
        
        const result = await response.json();
        
        if (result.success) {
            if (statusText) {
                statusText.textContent = isActive ? 'Aktif' : 'Pasif';
            }
            // Mini notification
            const toast = document.createElement('div');
            toast.textContent = isActive ? '✓ Deneme aktif edildi' : '✓ Deneme pasif edildi';
            toast.style.cssText = 'position:fixed;top:20px;right:20px;background:#10b981;color:white;padding:12px 20px;border-radius:6px;z-index:9999;font-size:14px;';
            document.body.appendChild(toast);
            setTimeout(() => toast.remove(), 2000);
        } else {
            throw new Error(result.message || 'Durum değiştirilemedi');
        }
    } catch (err) {
        console.error(err);
        this.checked = !this.checked; // Revert
        if (statusText) {
            statusText.textContent = this.checked ? 'Aktif' : 'Pasif';
        }
        Swal.fire('Hata', err.message || 'Durum değiştirilemedi', 'error');
    }
});

// ==========================================
// WATCH VIDEO - POPUP İLE AÇ
// ==========================================
document.addEventListener('click', function(e) {
    const watchBtn = e.target.closest('.watch-video');
    if (!watchBtn) return;
    
    e.preventDefault(); // Link açılmasını engelle
    
    const videoUrl = watchBtn.href;
    const isLink = watchBtn.textContent.includes('🔗');
    
    // Video popup
    Swal.fire({
        title: isLink ? 'Video Linki' : 'Video',
        html: `
            <div style="position:relative; padding-bottom:56.25%; height:0; overflow:hidden; max-width:100%; background:#000;">
                <iframe 
                    src="${getEmbedUrl(videoUrl)}" 
                    style="position:absolute; top:0; left:0; width:100%; height:100%; border:0;"
                    allowfullscreen
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                ></iframe>
            </div>
            <div style="margin-top:10px; text-align:left;">
                <a href="${videoUrl}" target="_blank" style="font-size:12px; color:#3b82f6;">
                    🔗 Yeni sekmede aç
                </a>
            </div>
        `,
        width: '800px',
        showConfirmButton: false,
        showCloseButton: true
    });
});

function getEmbedUrl(url) {
    // YouTube
    if (url.includes('youtube.com') || url.includes('youtu.be')) {
        let videoId = '';
        if (url.includes('youtube.com/watch')) {
            videoId = new URL(url).searchParams.get('v');
        } else if (url.includes('youtu.be/')) {
            videoId = url.split('youtu.be/')[1].split('?')[0];
        }
        return `https://www.youtube.com/embed/${videoId}`;
    }
    
    // Google Drive
    if (url.includes('drive.google.com')) {
        let fileId = '';
        if (url.includes('/file/d/')) {
            fileId = url.split('/file/d/')[1].split('/')[0];
        } else if (url.includes('id=')) {
            fileId = new URL(url).searchParams.get('id');
        }
        if (fileId) {
            return `https://drive.google.com/file/d/${fileId}/preview`;
        }
    }
    
    // Vimeo
    if (url.includes('vimeo.com')) {
        const videoId = url.split('vimeo.com/')[1].split('?')[0];
        return `https://player.vimeo.com/video/${videoId}`;
    }
    
    // Diğer (direkt embed dene)
    return url;
}

// ==========================================
// ŞABLON İNDİR - CSV oluştur
// ==========================================
document.getElementById('downloadTemplateBtn')?.addEventListener('click', function() {
    // Boş soruları bul
    const emptySlots = [];
    document.querySelectorAll('.video-upload').forEach(input => {
        const parent = input.parentElement.parentElement;
        const hasVideo = parent.querySelector('.watch-video');
        if (!hasVideo) {
            const branchName = input.dataset.branchName || 'Bilinmeyen';
            const questionNo = input.dataset.questionNo;
            const branchId = input.dataset.branchId; // Opsiyonel
            emptySlots.push({ branchName, questionNo, branchId });
        }
    });
    
    if (emptySlots.length === 0) {
        Swal.fire('Bilgi', 'Tüm sorularda zaten video var', 'info');
        return;
    }
    
    // CSV oluştur - BRANŞ İSMİ ile
    let csv = 'brans_adi,soru_no,video_dosya_adi\n';
    emptySlots.forEach(slot => {
        csv += `${slot.branchName},${slot.questionNo},\n`;
    });
    
    // İndir
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `video_sablonu_deneme_${window.examId}.csv`;
    link.click();
    
    Swal.fire({
        icon: 'success',
        title: 'Şablon İndirildi',
        html: `
            <p>${emptySlots.length} boş soru için şablon oluşturuldu.</p>
            <p style="font-size:12px; color:#666; margin-top:10px;">
                CSV dosyasını Excel ile açın ve videoları şu formatta isimlendirin:<br>
                <strong>${emptySlots[0].branchName}_${emptySlots[0].questionNo}.mp4</strong>
            </p>
            <p style="font-size:11px; color:#999; margin-top:8px;">
                Örnek: Fizik_5.mp4, Kimya_12.mp4
            </p>
        `,
        timer: 5000
    });
});

// DOMContentLoaded sonrası çalıştır
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function() {
        updateSelectedVideoCount();
    });
} else {
    updateSelectedVideoCount();
}

</script>

<?php
include __DIR__ . '/admin_footer.php';
?>
