(function(){
  "use strict";
  var btn = document.querySelector('[data-nav-toggle]');
  var nav = document.querySelector('[data-topnav]');
  if(!btn || !nav) return;

  function close(){ nav.classList.remove('open'); }
  function toggle(){ nav.classList.toggle('open'); }

  btn.addEventListener('click', function(e){
    e.preventDefault();
    toggle();
  });

  // Dışarı tıklayınca kapat
  document.addEventListener('click', function(e){
    if(!nav.classList.contains('open')) return;
    var t = e.target;
    if(t === btn || btn.contains(t) || nav.contains(t)) return;
    close();
  });

  // Link tıklanınca kapat (mobil)
  nav.addEventListener('click', function(e){
    var a = e.target.closest('a');
    if(a) close();
  });
})();
