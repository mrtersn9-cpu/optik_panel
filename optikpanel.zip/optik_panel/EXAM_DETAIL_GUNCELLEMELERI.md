# EXAM_DETAIL.PHP GÜNCELLEMELERİ - Video Link ve Toplu İşlemler

## DEĞ

İŞİKLİK 1: Video Sorgusunu Güncelle (Satır 150-163)

**ÖNCESİ:**
```php
$video_by_branch_q = [];
try {
    $stmt = $pdo->prepare("SELECT branch_id, question_no, video_path FROM exam_question_videos WHERE exam_id = ?");
    $stmt->execute([$id]);
    while ($v = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $bId = (int)$v['branch_id'];
        $qNo = (int)$v['question_no'];
        if ($bId > 0 && $qNo > 0 && !empty($v['video_path'])) {
            $video_by_branch_q[$bId][$qNo] = rtrim($base_url, '/') . '/' . ltrim((string)$v['video_path'], '/');
        }
    }
} catch (Exception $e) {
    // tablo yoksa sayfayı kırmayalım
}
```

**SONRASI:**
```php
$video_by_branch_q = [];
$video_data_by_branch_q = []; // ID, link, path bilgilerini tut
try {
    $stmt = $pdo->prepare("SELECT id, branch_id, question_no, video_path, video_link FROM exam_question_videos WHERE exam_id = ?");
    $stmt->execute([$id]);
    while ($v = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $bId = (int)$v['branch_id'];
        $qNo = (int)$v['question_no'];
        if ($bId > 0 && $qNo > 0) {
            // Link varsa onu kullan, yoksa path kullan
            if (!empty($v['video_link'])) {
                $video_by_branch_q[$bId][$qNo] = (string)$v['video_link'];
                $video_data_by_branch_q[$bId][$qNo] = [
                    'id' => (int)$v['id'],
                    'type' => 'link',
                    'url' => (string)$v['video_link']
                ];
            } elseif (!empty($v['video_path'])) {
                $url = rtrim($base_url, '/') . '/' . ltrim((string)$v['video_path'], '/');
                $video_by_branch_q[$bId][$qNo] = $url;
                $video_data_by_branch_q[$bId][$qNo] = [
                    'id' => (int)$v['id'],
                    'type' => 'upload',
                    'url' => $url
                ];
            }
        }
    }
} catch (Exception $e) {
    // tablo yoksa sayfayı kırmayalım
}
```

---

## DEĞİŞİKLİK 2: Toplu İşlem Butonlarını Ekle (Satır ~250, outcomes tablosundan önce)

**EKLE:**
```php
<!-- Toplu Video İşlemleri -->
<div style="margin: 20px 0; padding: 15px; background: #f8f9fa; border-radius: 8px;">
    <h4 style="margin: 0 0 12px; font-size: 16px; color: #333;">🎬 Toplu Video İşlemleri</h4>
    <div style="display:flex; gap:10px; flex-wrap:wrap;">
        <button type="button" id="bulkVideoUploadBtn" class="btn btn-primary">
            📤 Toplu Video Yükle
        </button>
        <button type="button" id="bulkVideoDeleteBtn" class="btn btn-danger">
            🗑️ Seçili Videoları Sil
        </button>
        <span id="selectedVideoCount" style="margin-left:10px; color:#666; line-height:36px;"></span>
    </div>
</div>
```

---

## DEĞİŞİKLİK 3: Video Card'ı Güncelle (Satır ~501-540)

**ÖNCESİ:**
```php
<td style="min-width:220px;">
    <?php if ($videoQno > 0): ?>
        <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;">
            <label class="btn btn-secondary btn-sm" style="margin:0;">
                Video Yükle
                <input
                    type="file"
                    class="video-upload"
                    accept="video/mp4,video/webm,video/quicktime"
                    data-exam-id="<?php echo (int)$exam['id']; ?>"
                    data-branch-id="<?php echo (int)$o['branch_id']; ?>"
                    data-question-no="<?php echo (int)$videoQno; ?>"
                    style="display:none;"
                >
            </label>

            <small class="muted">Soru: <?php echo (int)$videoQno; ?></small>

            <?php if ($videoUrl): ?>
                <a class="btn btn-success btn-sm watch-video" href="<?php echo h($videoUrl); ?>" target="_blank">İzle</a>

                <button
                    type="button"
                    class="btn btn-danger btn-sm delete-video"
                    data-exam-id="<?php echo (int)$exam['id']; ?>"
                    data-branch-id="<?php echo (int)$o['branch_id']; ?>"
                    data-question-no="<?php echo (int)$videoQno; ?>"
                    style="box-shadow:none;"
                >
                    Sil
                </button>
            <?php else: ?>
                <span class="badge badge-danger">Yok</span>
            <?php endif; ?>

            <small class="muted upload-status" style="display:none;"></small>
        </div>
    <?php else: ?>
        <small class="muted">Soru no bulunamadı</small>
    <?php endif; ?>
</td>
```

**SONRASI:**
```php
<td style="min-width:280px;">
    <?php if ($videoQno > 0): 
        $videoData = $video_data_by_branch_q[(int)$o['branch_id']][$videoQno] ?? null;
        $videoId = $videoData ? $videoData['id'] : 0;
    ?>
        <div class="video-card-wrapper" style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;">
            
            <!-- Checkbox for bulk operations -->
            <?php if ($videoUrl): ?>
                <input 
                    type="checkbox" 
                    class="video-select-checkbox" 
                    data-video-id="<?php echo (int)$videoId; ?>"
                    style="width:18px; height:18px; cursor:pointer;"
                >
            <?php endif; ?>
            
            <!-- Video Upload Button -->
            <label class="btn btn-secondary btn-sm" style="margin:0;">
                📤 Dosya
                <input
                    type="file"
                    class="video-upload"
                    accept="video/mp4,video/webm,video/quicktime"
                    data-exam-id="<?php echo (int)$exam['id']; ?>"
                    data-branch-id="<?php echo (int)$o['branch_id']; ?>"
                    data-question-no="<?php echo (int)$videoQno; ?>"
                    style="display:none;"
                >
            </label>

            <!-- Video Link Button -->
            <button 
                type="button" 
                class="btn btn-info btn-sm video-link-btn"
                data-exam-id="<?php echo (int)$exam['id']; ?>"
                data-branch-id="<?php echo (int)$o['branch_id']; ?>"
                data-question-no="<?php echo (int)$videoQno; ?>"
                title="YouTube, Vimeo vb. video linki ekle"
            >
                🔗 Link
            </button>

            <small class="muted" style="font-size:11px;">S:<?php echo (int)$videoQno; ?></small>

            <?php if ($videoUrl): ?>
                <a class="btn btn-success btn-sm watch-video" href="<?php echo h($videoUrl); ?>" target="_blank" title="<?php echo $videoData['type'] === 'link' ? 'Link' : 'Yüklü Video'; ?>">
                    <?php if ($videoData['type'] === 'link'): ?>
                        🔗 İzle
                    <?php else: ?>
                        📹 İzle
                    <?php endif; ?>
                </a>

                <button
                    type="button"
                    class="btn btn-danger btn-sm delete-video"
                    data-exam-id="<?php echo (int)$exam['id']; ?>"
                    data-branch-id="<?php echo (int)$o['branch_id']; ?>"
                    data-question-no="<?php echo (int)$videoQno; ?>"
                    style="box-shadow:none;"
                >
                    ❌
                </button>
            <?php else: ?>
                <span class="badge badge-danger">Yok</span>
            <?php endif; ?>

            <small class="muted upload-status" style="display:none;"></small>
        </div>
    <?php else: ?>
        <small class="muted">Soru no bulunamadı</small>
    <?php endif; ?>
</td>
```

---

## DEĞİŞİKLİK 4: "Kaydedildi ✓" Otomatik Gizle (Satır ~1077)

**ÖNCESİ:**
```javascript
if (status) status.textContent = 'Kaydedildi ✓';
toastOk('Video yüklendi');
```

**SONRASI:**
```javascript
if (status) {
    status.textContent = 'Kaydedildi ✓';
    status.style.display = 'inline';
    setTimeout(() => {
        status.style.display = 'none';
    }, 2000); // 2 saniye sonra gizle
}
toastOk('Video yüklendi');
```

---

## DEĞİŞİKLİK 5: Yeni JavaScript Fonksiyonları Ekle (</script> etiketinden önce, dosya sonunda)

**EKLE:**
```javascript
// =====================================================
// YENİ ÖZELLİKLER: Video Link + Toplu İşlemler
// =====================================================

// Video Link Dialog
document.addEventListener('click', function(e) {
    if (e.target.classList.contains('video-link-btn') || e.target.closest('.video-link-btn')) {
        const btn = e.target.classList.contains('video-link-btn') ? e.target : e.target.closest('.video-link-btn');
        const examId = btn.dataset.examId;
        const branchId = btn.dataset.branchId;
        const questionNo = btn.dataset.questionNo;
        
        Swal.fire({
            title: 'Video Linki Ekle',
            html: `
                <p style="text-align:left; margin-bottom:10px; color:#666; font-size:14px;">
                    YouTube, Vimeo veya başka bir video linkini yapıştırın:
                </p>
                <input type="url" id="videoLinkInput" class="swal2-input" 
                       placeholder="https://www.youtube.com/watch?v=..."
                       style="width:90%; font-size:14px;">
                <p style="text-align:left; margin-top:10px; color:#999; font-size:12px;">
                    💡 Link kaydedilirse, sunucuya video yüklenmeye gerek kalmaz.
                </p>
            `,
            showCancelButton: true,
            confirmButtonText: 'Kaydet',
            cancelButtonText: 'İptal',
            preConfirm: () => {
                const link = document.getElementById('videoLinkInput').value.trim();
                if (!link) {
                    Swal.showValidationMessage('Link boş olamaz');
                    return false;
                }
                if (!link.startsWith('http://') && !link.startsWith('https://')) {
                    Swal.showValidationMessage('Link http:// veya https:// ile başlamalı');
                    return false;
                }
                return link;
            }
        }).then((result) => {
            if (result.isConfirmed) {
                saveVideoLink(examId, branchId, questionNo, result.value, btn);
            }
        });
    }
});

function saveVideoLink(examId, branchId, questionNo, link, btn) {
    const formData = new FormData();
    formData.append('csrf_token', '<?php echo csrf_token(); ?>');
    formData.append('exam_id', examId);
    formData.append('branch_id', branchId);
    formData.append('question_no', questionNo);
    formData.append('video_link', link);
    
    fetch('api/save_video_link.php', {
        method: 'POST',
        body: formData
    })
    .then(r => r.json())
    .then(j => {
        if (j.success) {
            toastOk(j.message || 'Link kaydedildi');
            
            // UI'ı güncelle
            const wrap = btn.closest('.video-card-wrapper');
            const badge = wrap.querySelector('.badge-danger');
            if (badge) badge.remove();
            
            // İzle butonu ekle/güncelle
            let watchBtn = wrap.querySelector('.watch-video');
            if (!watchBtn) {
                watchBtn = document.createElement('a');
                watchBtn.className = 'btn btn-success btn-sm watch-video';
                watchBtn.target = '_blank';
                wrap.insertBefore(watchBtn, wrap.querySelector('.upload-status'));
            }
            watchBtn.href = j.url;
            watchBtn.innerHTML = '🔗 İzle';
            watchBtn.title = 'Link';
            
            // Sil butonu ekle
            let delBtn = wrap.querySelector('.delete-video');
            if (!delBtn) {
                delBtn = document.createElement('button');
                delBtn.type = 'button';
                delBtn.className = 'btn btn-danger btn-sm delete-video';
                delBtn.innerHTML = '❌';
                delBtn.dataset.examId = examId;
                delBtn.dataset.branchId = branchId;
                delBtn.dataset.questionNo = questionNo;
                wrap.insertBefore(delBtn, wrap.querySelector('.upload-status'));
            }
            
            // Checkbox ekle
            let checkbox = wrap.querySelector('.video-select-checkbox');
            if (!checkbox) {
                checkbox = document.createElement('input');
                checkbox.type = 'checkbox';
                checkbox.className = 'video-select-checkbox';
                checkbox.style.cssText = 'width:18px; height:18px; cursor:pointer;';
                wrap.insertBefore(checkbox, wrap.firstChild);
            }
            
            // Sayfayı yenile (video ID'sini almak için)
            setTimeout(() => location.reload(), 1500);
        } else {
            Swal.fire('Hata', j.message || 'Link kaydedilemedi', 'error');
        }
    })
    .catch(err => {
        console.error(err);
        Swal.fire('Hata', 'Bağlantı hatası', 'error');
    });
}

// Toplu Video Yükleme
document.getElementById('bulkVideoUploadBtn')?.addEventListener('click', function() {
    const input = document.createElement('input');
    input.type = 'file';
    input.multiple = true;
    input.accept = 'video/mp4,video/webm,video/quicktime';
    
    input.addEventListener('change', function() {
        if (this.files.length === 0) return;
        
        Swal.fire({
            title: 'Toplu Video Yükleme',
            html: `
                <p>${this.files.length} video seçildi.</p>
                <p>Videoları hangi sorulara yüklemek istiyorsunuz?</p>
                <p style="color:#666; font-size:13px;">
                    Not: İlk video ilk boş soruya, ikinci video ikinci boş soruya... şeklinde yüklenecek.
                </p>
            `,
            showCancelButton: true,
            confirmButtonText: 'Yükle',
            cancelButtonText: 'İptal'
        }).then((result) => {
            if (result.isConfirmed) {
                bulkUploadVideos(this.files);
            }
        });
    });
    
    input.click();
});

function bulkUploadVideos(files) {
    // Boş video slotlarını bul
    const emptySlots = [];
    document.querySelectorAll('.video-upload').forEach(input => {
        const wrap = input.closest('.video-card-wrapper');
        const hasVideo = wrap?.querySelector('.watch-video');
        if (!hasVideo) {
            emptySlots.push({
                input: input,
                examId: input.dataset.examId,
                branchId: input.dataset.branchId,
                questionNo: input.dataset.questionNo
            });
        }
    });
    
    if (emptySlots.length === 0) {
        Swal.fire('Bilgi', 'Tüm sorularda zaten video var', 'info');
        return;
    }
    
    const uploadCount = Math.min(files.length, emptySlots.length);
    let completed = 0;
    let errors = 0;
    
    Swal.fire({
        title: 'Yükleniyor...',
        html: `<div id="bulkUploadProgress">0 / ${uploadCount}</div>`,
        allowOutsideClick: false,
        didOpen: () => Swal.showLoading()
    });
    
    for (let i = 0; i < uploadCount; i++) {
        const file = files[i];
        const slot = emptySlots[i];
        
        uploadSingleVideo(file, slot, () => {
            completed++;
            document.getElementById('bulkUploadProgress').textContent = `${completed} / ${uploadCount}`;
            
            if (completed === uploadCount) {
                setTimeout(() => {
                    Swal.fire({
                        icon: errors > 0 ? 'warning' : 'success',
                        title: 'Tamamlandı',
                        html: `${completed - errors} video yüklendi${errors > 0 ? `, ${errors} hata` : ''}`,
                        confirmButtonText: 'Sayfayı Yenile'
                    }).then(() => location.reload());
                }, 500);
            }
        }, () => {
            errors++;
            completed++;
            document.getElementById('bulkUploadProgress').textContent = `${completed} / ${uploadCount} (${errors} hata)`;
        });
    }
}

function uploadSingleVideo(file, slot, onSuccess, onError) {
    const formData = new FormData();
    formData.append('csrf_token', '<?php echo csrf_token(); ?>');
    formData.append('exam_id', slot.examId);
    formData.append('branch_id', slot.branchId);
    formData.append('question_no', slot.questionNo);
    formData.append('video', file);
    
    fetch('api/upload_video.php', {
        method: 'POST',
        body: formData
    })
    .then(r => r.json())
    .then(j => {
        if (j.success) {
            onSuccess();
        } else {
            onError();
        }
    })
    .catch(onError);
}

// Toplu Video Silme
document.getElementById('bulkVideoDeleteBtn')?.addEventListener('click', function() {
    const checked = document.querySelectorAll('.video-select-checkbox:checked');
    
    if (checked.length === 0) {
        Swal.fire('Uyarı', 'Silinecek video seçilmedi', 'warning');
        return;
    }
    
    const videoIds = Array.from(checked).map(cb => cb.dataset.videoId);
    
    Swal.fire({
        title: 'Emin misiniz?',
        html: `<b>${checked.length}</b> video silinecek. Bu işlem geri alınamaz!`,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Evet, Sil',
        cancelButtonText: 'İptal',
        confirmButtonColor: '#d33'
    }).then((result) => {
        if (result.isConfirmed) {
            bulkDeleteVideos(videoIds);
        }
    });
});

function bulkDeleteVideos(videoIds) {
    const formData = new FormData();
    formData.append('csrf_token', '<?php echo csrf_token(); ?>');
    formData.append('exam_id', <?php echo (int)$exam['id']; ?>);
    videoIds.forEach(id => formData.append('video_ids[]', id));
    
    Swal.fire({
        title: 'Siliniyor...',
        allowOutsideClick: false,
        didOpen: () => Swal.showLoading()
    });
    
    fetch('api/bulk_delete_videos.php', {
        method: 'POST',
        body: formData
    })
    .then(r => r.json())
    .then(j => {
        if (j.success) {
            Swal.fire({
                icon: 'success',
                title: 'Başarılı',
                text: j.message || 'Videolar silindi',
                confirmButtonText: 'Sayfayı Yenile'
            }).then(() => location.reload());
        } else {
            Swal.fire('Hata', j.message || 'Silme başarısız', 'error');
        }
    })
    .catch(err => {
        console.error(err);
        Swal.fire('Hata', 'Bağlantı hatası', 'error');
    });
}

// Seçili video sayısını göster
document.addEventListener('change', function(e) {
    if (e.target.classList.contains('video-select-checkbox')) {
        updateSelectedVideoCount();
    }
});

function updateSelectedVideoCount() {
    const checked = document.querySelectorAll('.video-select-checkbox:checked');
    const countSpan = document.getElementById('selectedVideoCount');
    if (countSpan) {
        if (checked.length > 0) {
            countSpan.textContent = `${checked.length} video seçildi`;
            countSpan.style.color = '#2196F3';
            countSpan.style.fontWeight = 'bold';
        } else {
            countSpan.textContent = '';
        }
    }
}
```

---

## KURULUM ADIMLARI:

1. **Database Migration Çalıştır:**
   ```bash
   mysql -u username -p database_name < migrations/add_video_link.sql
   ```

2. **API Dosyalarını Yükle:**
   ```bash
   cp api/save_video_link.php /var/www/optik_panel/api/
   cp api/bulk_delete_videos.php /var/www/optik_panel/api/
   ```

3. **exam_detail.php'yi Elle Güncelle:**
   - Yukarıdaki 5 değişikliği sırasıyla uygula
   - Her değişiklik için satır numaralarına dikkat et

4. **Test Et:**
   - Video link ekleme
   - Toplu video yükleme
   - Toplu video silme
   - "Kaydedildi ✓" mesajının 2 saniye sonra gizlenmesi

---

## NOTLAR:

- Dosya çok uzun olduğu için (1220 satır) tamamını yeniden yazmadım
- Manuel değişiklikler gerekiyor
- Alternatif: Tam güncellenmiş exam_detail.php'yi ayrı oluşturabilirim
