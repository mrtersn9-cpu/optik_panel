<?php
require_once __DIR__ . '/admin_header.php';

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    echo "<p>Geçersiz kullanıcı.</p>";
    require_once __DIR__ . '/admin_footer.php';
    exit;
}

$st = $pdo->prepare("SELECT id, username, role, is_active, video_compression_enabled, video_compression_quality, video_compression_percentage, created_at, updated_at, last_login_at FROM admin_users WHERE id = ?");
$st->execute([$id]);
$user = $st->fetch();
if (!$user) {
    echo "<p>Kullanıcı bulunamadı.</p>";
    require_once __DIR__ . '/admin_footer.php';
    exit;
}

$msg = '';
$err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_validate($_POST['csrf_token'] ?? null)) {
        $err = 'Güvenlik doğrulaması başarısız. Lütfen tekrar deneyin.';
    } else {
        $newPass = (string)($_POST['new_password'] ?? '');
        $newPass2 = (string)($_POST['new_password2'] ?? '');
        $isActive = isset($_POST['is_active']) ? 1 : 0;
        $role = trim((string)($_POST['role'] ?? 'admin'));
        if ($role === '') $role = 'admin';
        
        // Video compression ayarları
        $videoCompressionEnabled = isset($_POST['video_compression_enabled']) ? 1 : 0;
        $videoCompressionQuality = (string)($_POST['video_compression_quality'] ?? 'medium');
        $videoCompressionPercentage = (int)($_POST['video_compression_percentage'] ?? 80);
        
        // Validasyon
        if (!in_array($videoCompressionQuality, ['low', 'medium', 'high'])) {
            $videoCompressionQuality = 'medium';
        }
        if ($videoCompressionPercentage < 50 || $videoCompressionPercentage > 90) {
            $videoCompressionPercentage = 80;
        }

        // Kendi hesabını pasife alma engeli
        $me = current_user();
        if ($me && (int)$me['id'] === (int)$user['id'] && $isActive !== 1) {
            $err = 'Kendi hesabınızı pasif yapamazsınız.';
        } else {
            // Şifre güncellemesi opsiyonel
            if ($newPass !== '' || $newPass2 !== '') {
                if (strlen($newPass) < 8) {
                    $err = 'Şifre en az 8 karakter olmalı.';
                } elseif ($newPass !== $newPass2) {
                    $err = 'Şifreler eşleşmiyor.';
                } else {
                    $hash = password_hash($newPass, PASSWORD_DEFAULT);
                    $up = $pdo->prepare("UPDATE admin_users SET password_hash = ?, role = ?, is_active = ?, video_compression_enabled = ?, video_compression_quality = ?, video_compression_percentage = ?, updated_at = NOW() WHERE id = ?");
                    $up->execute([$hash, $role, $isActive, $videoCompressionEnabled, $videoCompressionQuality, $videoCompressionPercentage, $id]);
                    $msg = 'Kullanıcı güncellendi (şifre değiştirildi).';
                }
            }

            if ($err === '' && $msg === '') {
                $up = $pdo->prepare("UPDATE admin_users SET role = ?, is_active = ?, video_compression_enabled = ?, video_compression_quality = ?, video_compression_percentage = ?, updated_at = NOW() WHERE id = ?");
                $up->execute([$role, $isActive, $videoCompressionEnabled, $videoCompressionQuality, $videoCompressionPercentage, $id]);
                $msg = 'Kullanıcı güncellendi.';
            }

            // Güncel veriyi tekrar çek
            $st->execute([$id]);
            $user = $st->fetch();
        }
    }
}
?>
<h2>Kullanıcı Düzenle</h2>

<?php if ($err): ?>
    <div style="background:#ffebee;color:#b71c1c;padding:10px;border-radius:8px;margin:10px 0;"><?= h($err) ?></div>
<?php endif; ?>
<?php if ($msg): ?>
    <div style="background:#e8f5e9;color:#1b5e20;padding:10px;border-radius:8px;margin:10px 0;"><?= h($msg) ?></div>
<?php endif; ?>

<form method="post">
    <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">

    <p><b>Kullanıcı:</b> <?= h($user['username']) ?></p>

    <label>Rol</label>
    <input type="text" name="role" value="<?= h($user['role'] ?? 'admin') ?>" style="max-width:320px;">

    <label style="margin-top:10px; display:block;">
        <input type="checkbox" name="is_active" value="1" <?= ((int)$user['is_active'] === 1) ? 'checked' : '' ?>>
        Aktif
    </label>

    <hr style="margin:15px 0; border:none; border-top:1px solid #eee;">

    <h3 style="margin:0 0 10px;">🎬 Video Sıkıştırma Ayarları</h3>
    <p style="color:#666;font-size:13px;margin:0 0 15px;">Video yükleme sırasında otomatik sıkıştırma yapılsın mı?</p>
    
    <label style="margin-top:10px; display:block;">
        <input type="checkbox" name="video_compression_enabled" id="compressionEnabled" value="1" 
               <?= ((int)($user['video_compression_enabled'] ?? 1) === 1) ? 'checked' : '' ?>>
        Video Sıkıştırmayı Etkinleştir
    </label>

    <div id="compressionSettings" style="margin-left:25px; margin-top:15px; display:<?= ((int)($user['video_compression_enabled'] ?? 1) === 1) ? 'block' : 'none' ?>;">
        
        <label>Kalite Seviyesi</label>
        <select name="video_compression_quality" id="qualitySelect" style="max-width:320px;">
            <option value="low" <?= ($user['video_compression_quality'] ?? 'medium') === 'low' ? 'selected' : '' ?>>
                Düşük Kalite (640x480, ~50-70% sıkıştırma)
            </option>
            <option value="medium" <?= ($user['video_compression_quality'] ?? 'medium') === 'medium' ? 'selected' : '' ?>>
                Orta Kalite (1280x720, ~75-85% sıkıştırma) ⭐ Önerilen
            </option>
            <option value="high" <?= ($user['video_compression_quality'] ?? 'medium') === 'high' ? 'selected' : '' ?>>
                Yüksek Kalite (1920x1080, ~60-75% sıkıştırma)
            </option>
        </select>

        <label style="margin-top:15px;">Hedef Sıkıştırma Oranı: <span id="percentageValue"><?= (int)($user['video_compression_percentage'] ?? 80) ?>%</span></label>
        <div style="display:flex;align-items:center;gap:10px;max-width:320px;">
            <input type="range" name="video_compression_percentage" id="percentageSlider" 
                   min="50" max="90" step="5" 
                   value="<?= (int)($user['video_compression_percentage'] ?? 80) ?>"
                   style="flex:1;">
            <span style="color:#666;font-size:13px;">50%</span>
            <span style="color:#666;font-size:13px;">90%</span>
        </div>
        <p style="color:#888;font-size:12px;margin:5px 0 0;">
            Daha yüksek oran = daha küçük dosya boyutu
        </p>

        <div id="estimateBox" style="background:#e3f2fd;border:1px solid #2196F3;border-radius:8px;padding:12px;margin-top:15px;">
            <strong style="color:#1976D2;">💾 Tahmini Boyut:</strong>
            <p style="margin:5px 0 0;color:#666;font-size:13px;" id="estimateText">
                100 MB video → <strong id="estimateSize">20 MB</strong> olacak (<span id="estimateSaved">80 MB</span> tasarruf)
            </p>
        </div>
    </div>

    <script>
    // Compression enable/disable toggle
    document.getElementById('compressionEnabled').addEventListener('change', function() {
        document.getElementById('compressionSettings').style.display = this.checked ? 'block' : 'none';
    });

    // Percentage slider update
    const slider = document.getElementById('percentageSlider');
    const percentageValue = document.getElementById('percentageValue');
    const estimateSize = document.getElementById('estimateSize');
    const estimateSaved = document.getElementById('estimateSaved');

    function updateEstimate() {
        const percentage = parseInt(slider.value);
        percentageValue.textContent = percentage + '%';
        
        // 100 MB video için hesaplama
        const originalSize = 100;
        const compressedSize = Math.round(originalSize * (1 - percentage / 100));
        const saved = originalSize - compressedSize;
        
        estimateSize.textContent = compressedSize + ' MB';
        estimateSaved.textContent = saved + ' MB';
    }

    slider.addEventListener('input', updateEstimate);
    
    // Kalite değişince slider'ı otomatik ayarla
    document.getElementById('qualitySelect').addEventListener('change', function() {
        const quality = this.value;
        if (quality === 'low') slider.value = 85;
        else if (quality === 'medium') slider.value = 80;
        else if (quality === 'high') slider.value = 70;
        updateEstimate();
    });

    // İlk yüklemede hesapla
    updateEstimate();
    </script>

    <hr style="margin:15px 0; border:none; border-top:1px solid #eee;">

    <h3 style="margin:0 0 10px;">Şifre Değiştir</h3>
    <label>Yeni Şifre</label>
    <input type="password" name="new_password" placeholder="En az 8 karakter" style="max-width:320px;">
    <label>Yeni Şifre (Tekrar)</label>
    <input type="password" name="new_password2" style="max-width:320px;">

    <div style="margin-top:15px;">
        <button class="btn btn-success" type="submit">Kaydet</button>
        <a class="btn btn-secondary" href="users.php">Geri</a>
    </div>
</form>

<?php require_once __DIR__ . '/admin_footer.php'; ?>
