<?php
require_once __DIR__ . '/../config.php';
require_login();

// CSRF kontrolü (sadece POST için)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf_api();
}


// Composer autoload (api klasöründen: optik_panel/api -> optik_panel -> vendor)
$autoload = __DIR__ . '/../../vendor/autoload.php';
if (!file_exists($autoload)) {
    die('vendor/autoload.php bulunamadı. Composer kurulu mu?');
}
require_once $autoload;

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Cell\Coordinate;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Fill;

$exam_id = isset($_POST['exam_id']) ? (int)$_POST['exam_id'] : (isset($_GET['exam_id']) ? (int)$_GET['exam_id'] : 0);
if ($exam_id <= 0) {
    die('Geçersiz deneme ID.');
}

// Deneme
$stmt = $pdo->prepare("SELECT * FROM exams WHERE id = ?");
$stmt->execute([$exam_id]);
$exam = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$exam) {
    die('Deneme bulunamadı.');
}

// Kitapçıklar
$stmt = $pdo->prepare("SELECT * FROM exam_booklets WHERE exam_id = ? ORDER BY id ASC");
$stmt->execute([$exam_id]);
$booklets = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Kazanımlar
$stmt = $pdo->prepare("
    SELECT eo.*, eb.name AS branch_name
    FROM exam_outcomes eo
    JOIN exam_branches eb ON eo.branch_id = eb.id
    WHERE eo.exam_id = ?
");
$stmt->execute([$exam_id]);
$outcomes = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (!$outcomes) {
    die('Bu denemeye ait tanımlı kazanım bulunmuyor.');
}

// Harita (outcome -> booklet mappings)
$maps_by_outcome = [];
$outcome_ids = array_column($outcomes, 'id');

if ($outcome_ids) {
    $in_query = implode(',', array_fill(0, count($outcome_ids), '?'));
    $stmt = $pdo->prepare("
        SELECT m.*, b.code AS booklet_code
        FROM exam_outcome_booklet_map m
        JOIN exam_booklets b ON m.booklet_id = b.id
        WHERE m.outcome_id IN ($in_query)
        ORDER BY b.id
    ");
    $stmt->execute($outcome_ids);
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $maps_by_outcome[$row['outcome_id']][] = $row;
    }
}

// SIRALAMA: Branş > A kitapçığı soru no (exam_detail.php ile uyumlu)
usort($outcomes, function ($a, $b) use ($maps_by_outcome) {
    $cmpBranch = strcasecmp((string)$a['branch_name'], (string)$b['branch_name']);
    if ($cmpBranch !== 0) return $cmpBranch;

    $getAQuestion = function ($outcomeId) use ($maps_by_outcome) {
        if (!isset($maps_by_outcome[$outcomeId])) return PHP_INT_MAX;
        foreach ($maps_by_outcome[$outcomeId] as $m) {
            if (($m['booklet_code'] ?? '') === 'A') {
                return (int)($m['question_no'] ?? PHP_INT_MAX);
            }
        }
        return PHP_INT_MAX;
    };

    $qA = $getAQuestion($a['id']);
    $qB = $getAQuestion($b['id']);

    if ($qA === $qB) return 0;
    return ($qA < $qB) ? -1 : 1;
});

// ---------- EXCEL OLUŞTUR ----------
$spreadsheet = new Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();
$sheet->setTitle('Kazanımlar');

// Yardımcı: hücreye yaz
$setCell = function($sheet, $colIndex, $rowIndex, $value) {
    $colLetter = Coordinate::stringFromColumnIndex($colIndex);
    $sheet->setCellValue($colLetter . $rowIndex, $value);
};

// ---------- Başlık satırı ----------
$rowIndex = 1;
$colIndex = 1;

$setCell($sheet, $colIndex++, $rowIndex, 'Branş');
$setCell($sheet, $colIndex++, $rowIndex, 'Alt Branş');

foreach ($booklets as $b) {
    $code = (string)($b['code'] ?? '');
    $setCell($sheet, $colIndex++, $rowIndex, 'Kitapçık ' . $code . ' Soru No');
    $setCell($sheet, $colIndex++, $rowIndex, 'Kitapçık ' . $code . ' Cevap');
}

$setCell($sheet, $colIndex++, $rowIndex, 'Kazanım Adı');
$setCell($sheet, $colIndex++, $rowIndex, 'Kazanım Kodu');

$lastCol = $colIndex - 1;

// Başlık stil
$headerRange = 'A1:' . Coordinate::stringFromColumnIndex($lastCol) . '1';
$sheet->getStyle($headerRange)->getFont()->setBold(true)->setSize(12);
$sheet->getStyle($headerRange)->getAlignment()->setVertical(Alignment::VERTICAL_CENTER);
$sheet->getStyle($headerRange)->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
$sheet->getStyle($headerRange)->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setARGB('FF1F4E79');
$sheet->getStyle($headerRange)->getFont()->getColor()->setARGB('FFFFFFFF');
$sheet->getRowDimension(1)->setRowHeight(22);

// Freeze + filtre
$sheet->freezePane('A2');
$sheet->setAutoFilter($headerRange);

// ---------- Satırlar ----------
$rowIndex = 2;

foreach ($outcomes as $o) {
    $colIndex = 1;

    $branchName = (string)($o['branch_name'] ?? '');
    $altBranch  = (string)($o['alt_branch_name'] ?? ''); // null gelebilir
    $outName    = (string)($o['outcome_name'] ?? '');
    $outCode    = (string)($o['outcome_code'] ?? '');

    $setCell($sheet, $colIndex++, $rowIndex, $branchName);
    $setCell($sheet, $colIndex++, $rowIndex, $altBranch);

    $maps = $maps_by_outcome[$o['id']] ?? [];
    $byCode = [];
    foreach ($maps as $m) {
        $byCode[(string)($m['booklet_code'] ?? '')] = $m;
    }

    foreach ($booklets as $b) {
        $code = (string)($b['code'] ?? '');
        $q = '';
        $ans = '';

        if (isset($byCode[$code])) {
            $q   = $byCode[$code]['question_no'] ?? '';
            $ans = $byCode[$code]['answer_option'] ?? '';
        }

        $setCell($sheet, $colIndex++, $rowIndex, $q);
        $setCell($sheet, $colIndex++, $rowIndex, $ans);
    }

    $setCell($sheet, $colIndex++, $rowIndex, $outName);
    $setCell($sheet, $colIndex++, $rowIndex, $outCode);

    $rowIndex++;
}

// Hizalama (veri satırları)
$dataRange = 'A2:' . Coordinate::stringFromColumnIndex($lastCol) . ($rowIndex - 1);
$sheet->getStyle($dataRange)->getAlignment()->setVertical(Alignment::VERTICAL_TOP);
$sheet->getStyle($dataRange)->getAlignment()->setWrapText(false); // senin isteğine göre tek satır

// Kolon genişliği (güvenli autosize)
for ($c = 1; $c <= $lastCol; $c++) {
    $colLetter = Coordinate::stringFromColumnIndex($c);
    $sheet->getColumnDimension($colLetter)->setAutoSize(true);
}

// ---------- Çıktı ----------
$filename = 'deneme_' . $exam_id . '_kazanımlar_' . date('Ymd_His') . '.xlsx';

// Excel bozulmasın diye olası buffer temizle
while (ob_get_level() > 0) { ob_end_clean(); }

header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Cache-Control: max-age=0');

$writer = new Xlsx($spreadsheet);
$writer->save('php://output');
exit;
