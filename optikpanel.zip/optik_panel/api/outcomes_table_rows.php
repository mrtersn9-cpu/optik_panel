<?php
require_once __DIR__ . '/../config.php';

require_login();

header('Content-Type: application/json; charset=utf-8');

$examId = isset($_GET['exam_id']) ? (int)$_GET['exam_id'] : 0;
if ($examId <= 0) {
    echo json_encode(['success' => false, 'message' => 'Geçersiz exam_id']);
    exit;
}

// Deneme bilgisi (video url üretiminde base_url kullanacağız)
$stmt = $pdo->prepare('SELECT * FROM exams WHERE id = ?');
$stmt->execute([$examId]);
$exam = $stmt->fetch();
if (!$exam) {
    echo json_encode(['success' => false, 'message' => 'Deneme bulunamadı']);
    exit;
}

// Kitapçıklar
$stmt = $pdo->prepare('SELECT * FROM exam_booklets WHERE exam_id = ? ORDER BY id ASC');
$stmt->execute([$examId]);
$booklets = $stmt->fetchAll();

// Kazanımlar + branş adı
$stmt = $pdo->prepare(
    'SELECT eo.*, eb.name AS branch_name '
  . 'FROM exam_outcomes eo '
  . 'JOIN exam_branches eb ON eo.branch_id = eb.id '
  . 'WHERE eo.exam_id = ?'
);
$stmt->execute([$examId]);
$outcomes = $stmt->fetchAll();

// Mapler
$maps_by_outcome = [];
if (!empty($outcomes)) {
    $outcome_ids = array_column($outcomes, 'id');
    $in_query = implode(',', array_fill(0, count($outcome_ids), '?'));

    $stmt = $pdo->prepare(
        'SELECT m.*, b.code AS booklet_code '
      . 'FROM exam_outcome_booklet_map m '
      . 'JOIN exam_booklets b ON m.booklet_id = b.id '
      . "WHERE m.outcome_id IN ($in_query) "
      . 'ORDER BY b.id'
    );
    $stmt->execute($outcome_ids);
    while ($row = $stmt->fetch()) {
        $maps_by_outcome[$row['outcome_id']][] = $row;
    }

    // Sıralama: Branş > A kitapçığı soru no
    usort($outcomes, function ($a, $b) use ($maps_by_outcome) {
        $cmpBranch = strcasecmp((string)$a['branch_name'], (string)$b['branch_name']);
        if ($cmpBranch !== 0) return $cmpBranch;

        $getAQuestion = function ($outcomeId) use ($maps_by_outcome) {
            if (!isset($maps_by_outcome[$outcomeId])) return PHP_INT_MAX;
            foreach ($maps_by_outcome[$outcomeId] as $m) {
                if (($m['booklet_code'] ?? '') === 'A') return (int)$m['question_no'];
            }
            return PHP_INT_MAX;
        };

        $qA = $getAQuestion($a['id']);
        $qB = $getAQuestion($b['id']);
        if ($qA === $qB) return 0;
        return ($qA < $qB) ? -1 : 1;
    });
}

// Video çözümler (exam_id + branch_id + question_no)
$video_by_branch_q = [];
try {
    $stmt = $pdo->prepare('SELECT branch_id, question_no, video_path FROM exam_question_videos WHERE exam_id = ?');
    $stmt->execute([$examId]);
    while ($v = $stmt->fetch()) {
        $bId = (int)$v['branch_id'];
        $qNo = (int)$v['question_no'];
        if ($bId > 0 && $qNo > 0 && !empty($v['video_path'])) {
            $video_by_branch_q[$bId][$qNo] = rtrim($base_url, '/') . '/' . ltrim((string)$v['video_path'], '/');
        }
    }
} catch (Exception $e) {
    // tablo yoksa vs.
}

ob_start();
foreach ($outcomes as $o):
    $maps = $maps_by_outcome[$o['id']] ?? [];
    $byCode = [];
    foreach ($maps as $m) $byCode[$m['booklet_code']] = $m;

    // Video soru no: A kitapçığı öncelik
    $videoQno = 0;
    if (!empty($byCode['A']['question_no'])) {
        $videoQno = (int)$byCode['A']['question_no'];
    } elseif (!empty($byCode)) {
        foreach ($byCode as $tmp) {
            if (!empty($tmp['question_no'])) { $videoQno = (int)$tmp['question_no']; break; }
        }
    }
    $videoUrl = null;
    if ($videoQno > 0) {
        $videoUrl = $video_by_branch_q[(int)$o['branch_id']][$videoQno] ?? null;
    }
?>
<tr data-outcome-id="<?php echo (int)$o['id']; ?>">
    <td><?php echo htmlspecialchars($o['branch_name']); ?></td>
    <td><?php echo htmlspecialchars($o['alt_branch_name']); ?></td>

    <?php foreach ($booklets as $b):
        $cell = '';
        if (isset($byCode[$b['code']])) {
            $cell = (string)$byCode[$b['code']]['question_no'];
            if (!empty($byCode[$b['code']]['answer_option'])) $cell .= ' / ' . $byCode[$b['code']]['answer_option'];
        }
    ?>
        <td><?php echo htmlspecialchars($cell); ?></td>
    <?php endforeach; ?>

    <td><?php echo htmlspecialchars($o['outcome_name']); ?></td>
    <td><?php echo htmlspecialchars($o['outcome_code']); ?></td>

    <td style="min-width:220px;">
        <?php if ($videoQno > 0): ?>
            <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;">
                <label class="btn btn-secondary btn-sm" style="margin:0;">
                    Video Yükle
                    <input
                        type="file"
                        class="video-upload"
                        accept="video/mp4,video/webm,video/quicktime"
                        data-exam-id="<?php echo (int)$examId; ?>"
                        data-branch-id="<?php echo (int)$o['branch_id']; ?>"
                        data-question-no="<?php echo (int)$videoQno; ?>"
                        style="display:none;"
                    >
                </label>

                <small class="muted">Soru: <?php echo (int)$videoQno; ?></small>

                <?php if ($videoUrl): ?>
                    <a class="btn btn-success btn-sm watch-video" href="<?php echo htmlspecialchars($videoUrl); ?>" target="_blank">İzle</a>
                    <button
                        type="button"
                        class="btn btn-danger btn-sm delete-video"
                        data-exam-id="<?php echo (int)$examId; ?>"
                        data-branch-id="<?php echo (int)$o['branch_id']; ?>"
                        data-question-no="<?php echo (int)$videoQno; ?>"
                        style="box-shadow:none;"
                    >
                        Sil
                    </button>
                <?php else: ?>
                    <span class="badge badge-danger">Yok</span>
                <?php endif; ?>

                <small class="muted upload-status" style="display:none;"></small>
            </div>
        <?php else: ?>
            <small class="muted">Soru no bulunamadı</small>
        <?php endif; ?>
    </td>

    <td>
        <button
            type="button"
            class="btn btn-danger btn-sm btn-outcome-delete"
            data-id="<?php echo (int)$o['id']; ?>"
            data-exam="<?php echo (int)$examId; ?>"
        >
            Sil
        </button>
    </td>
</tr>
<?php endforeach;
$html = ob_get_clean();

echo json_encode(['success' => true, 'html' => $html]);
