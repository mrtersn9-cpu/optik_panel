<?php
require_once __DIR__ . '/../config.php';

require_login();

// CSRF kontrolü
require_csrf_api();


/**
 * TOPLU KAZANIM SİLME
 * - AJAX: JSON döner
 * - Normal form: redirect ile çalışır
 */

$isAjax = (
    (isset($_POST['ajax']) && (string)$_POST['ajax'] === '1') ||
    (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower((string)$_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest')
);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    if ($isAjax) {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['success' => false, 'message' => 'Geçersiz istek.']);
        exit;
    }
    header('Location: /optik_panel/exams.php');
    exit;
}

$exam_id = (int)($_POST['exam_id'] ?? 0);
if ($exam_id <= 0) {
    if ($isAjax) {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['success' => false, 'message' => 'Geçersiz deneme ID.']);
        exit;
    }
    die('Geçersiz deneme ID');
}

try {
    $pdo->beginTransaction();

    // Bu denemeye ait outcome id'leri
    $st = $pdo->prepare('SELECT id FROM exam_outcomes WHERE exam_id = ?');
    $st->execute([$exam_id]);
    $ids = $st->fetchAll(PDO::FETCH_COLUMN);

    // Map kayıtları
    if (!empty($ids)) {
        $in = implode(',', array_fill(0, count($ids), '?'));
        $delMap = $pdo->prepare("DELETE FROM exam_outcome_booklet_map WHERE outcome_id IN ($in)");
        $delMap->execute($ids);
    }

    // Outcome kayıtları
    $stmt = $pdo->prepare('DELETE FROM exam_outcomes WHERE exam_id = ?');
    $stmt->execute([$exam_id]);

    $pdo->commit();

    if ($isAjax) {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['success' => true, 'message' => 'Tüm kazanımlar silindi.']);
        exit;
    }

    header('Location: /optik_panel/exam_detail.php?id=' . $exam_id);
    exit;
} catch (Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    if ($isAjax) {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['success' => false, 'message' => 'Hata: ' . $e->getMessage()]);
        exit;
    }
    die('Kazanımlar silinirken hata oluştu: ' . $e->getMessage());
}
