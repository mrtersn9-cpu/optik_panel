<?php
require_once __DIR__ . '/../config.php';
require_login();
require_csrf_api();

header('Content-Type: application/json; charset=utf-8');

function jerr(string $msg): void {
    echo json_encode(['success' => false, 'message' => $msg], JSON_UNESCAPED_UNICODE);
    exit;
}

$exam_id = (int)($_POST['exam_id'] ?? 0);
$video_ids = $_POST['video_ids'] ?? [];

if ($exam_id <= 0) {
    jerr('Eksik parametre.');
}

if (!is_array($video_ids) || empty($video_ids)) {
    jerr('Silinecek video seçilmedi.');
}

// ID'leri integer'a çevir
$video_ids = array_map('intval', $video_ids);
$video_ids = array_filter($video_ids, function($id) { return $id > 0; });

if (empty($video_ids)) {
    jerr('Geçersiz video ID\'leri.');
}

try {
    $pdo->beginTransaction();
    
    // Önce bu exam'a ait videoları çek (güvenlik)
    $placeholders = implode(',', array_fill(0, count($video_ids), '?'));
    $params = array_merge([$exam_id], $video_ids);
    
    $stmt = $pdo->prepare("SELECT id, video_path FROM exam_question_videos WHERE exam_id=? AND id IN ($placeholders)");
    $stmt->execute($params);
    $videos = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($videos)) {
        jerr('Bu sınavda silinecek video bulunamadı.');
    }
    
    $deletedCount = 0;
    $baseDir = realpath(__DIR__ . '/..');
    
    foreach ($videos as $video) {
        $videoId = (int)$video['id'];
        $videoPath = $video['video_path'];
        
        // Database'den sil
        $del = $pdo->prepare("DELETE FROM exam_question_videos WHERE id=?");
        $del->execute([$videoId]);
        
        // Dosyayı sil (varsa)
        if ($videoPath) {
            $fullPath = $baseDir . '/' . $videoPath;
            if (file_exists($fullPath)) {
                @unlink($fullPath);
            }
        }
        
        $deletedCount++;
    }
    
    $pdo->commit();
    
    log_security_event('bulk_video_delete', "Bulk deleted $deletedCount videos", [
        'exam_id' => $exam_id,
        'count' => $deletedCount,
        'ids' => array_column($videos, 'id')
    ]);
    
    echo json_encode([
        'success' => true,
        'deleted_count' => $deletedCount,
        'message' => "$deletedCount video silindi"
    ], JSON_UNESCAPED_UNICODE);
    
} catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    jerr('Silme hatası: ' . $e->getMessage());
}
