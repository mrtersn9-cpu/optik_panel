<?php
require_once __DIR__ . '/../config.php';

require_login();

// CSRF kontrolü
require_csrf_api();


$id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
$exam_id = isset($_POST['exam_id']) ? (int)$_POST['exam_id'] : 0;

if ($id <= 0 || $exam_id <= 0) {
    die("Geçersiz istek.");
}

// 1) Bu outcome gerçekten bu denemeye mi ait? Güvenlik kontrolü
$stmt = $pdo->prepare("SELECT exam_id FROM exam_outcomes WHERE id = ?");
$stmt->execute([$id]);
$row = $stmt->fetch();

if (!$row || (int)$row['exam_id'] !== $exam_id) {
    die("Yetkisiz işlem.");
}

// 2) İlgili kitapçık haritalarını sil
$pdo->prepare("DELETE FROM exam_outcome_booklet_map WHERE outcome_id = ?")
    ->execute([$id]);

// 3) Kazanımı sil
$pdo->prepare("DELETE FROM exam_outcomes WHERE id = ?")
    ->execute([$id]);

// Geri dön
header("Location: exam_detail.php?id=" . $exam_id);
exit;
