<?php
require_once __DIR__ . '/../config.php';
require_login();

// CSRF kontrolü
require_csrf_api();

// Upload performans optimizasyonları
@ini_set('max_execution_time', '600');
@ini_set('max_input_time', '600');
@ini_set('memory_limit', '256M');

// Output buffering kapalı (streaming için)
if (ob_get_level()) ob_end_clean();

header('Content-Type: application/json; charset=utf-8');

function jerr(string $msg, int $code = 200): void {
    http_response_code($code);
    echo json_encode(['success' => false, 'message' => $msg], JSON_UNESCAPED_UNICODE);
    exit;
}

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    jerr('Geçersiz istek.');
}

$exam_id     = (int)($_POST['exam_id'] ?? 0);
$branch_id   = (int)($_POST['branch_id'] ?? 0);
$question_no = (int)($_POST['question_no'] ?? 0);

if ($exam_id <= 0 || $branch_id <= 0 || $question_no <= 0) {
    jerr('Eksik parametre.');
}

if (empty($_FILES['video'])) {
    jerr('Video dosyası bulunamadı.');
}

$file = $_FILES['video'];

// Güvenli dosya upload validasyonu
$validation = validate_video_upload($file);
if (!$validation['success']) {
    log_security_event('upload_rejected', 'Video upload validation failed', [
        'exam_id' => $exam_id,
        'reason' => $validation['message']
    ]);
    jerr($validation['message']);
}

$ext = $validation['extension'];

/**
 * Klasör: /optik_panel/uploads/exams/{exam_id}/videos/
 */
$baseDir = realpath(__DIR__ . '/..');
if ($baseDir === false) {
    jerr('Sunucu dizin yolu çözümlenemedi.');
}

$videoDir = $baseDir . '/uploads/exams/' . $exam_id . '/videos/';
if (!is_dir($videoDir)) {
    if (!mkdir($videoDir, 0755, true) && !is_dir($videoDir)) {
        jerr('Klasör oluşturulamadı.');
    }
}

// Güvenli dosya adı
$safeFile = generate_safe_filename('branch' . $branch_id . '_q' . $question_no, $ext);
$targetPath = $videoDir . $safeFile;

if (!move_uploaded_file($file['tmp_name'], $targetPath)) {
    jerr('Dosya kaydedilemedi.');
}

// Dosya izinlerini güvenli hale getir
@chmod($targetPath, 0644);

// Web yolu (relative)
$relPath = 'uploads/exams/' . $exam_id . '/videos/' . $safeFile;

/**
 * DB'de exam_question_videos tablosunu güncelle/ekle
 */
function table_has_column(PDO $pdo, string $table, string $column): bool {
    try {
        $stmt = $pdo->prepare("SHOW COLUMNS FROM `{$table}` LIKE ?");
        $stmt->execute([$column]);
        return ($stmt->rowCount() > 0);
    } catch (Throwable $e) {
        return false;
    }
}

$hasCreatedAt = table_has_column($pdo, 'exam_question_videos', 'created_at');
$hasUpdatedAt = table_has_column($pdo, 'exam_question_videos', 'updated_at');

try {
    $pdo->beginTransaction();

    $stmt = $pdo->prepare("SELECT id FROM exam_question_videos WHERE exam_id=? AND branch_id=? AND question_no=? LIMIT 1");
    $stmt->execute([$exam_id, $branch_id, $question_no]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($row) {
        if ($hasUpdatedAt) {
            $upd = $pdo->prepare("UPDATE exam_question_videos SET video_path=?, updated_at=NOW() WHERE id=?");
            $upd->execute([$relPath, (int)$row['id']]);
        } else {
            $upd = $pdo->prepare("UPDATE exam_question_videos SET video_path=? WHERE id=?");
            $upd->execute([$relPath, (int)$row['id']]);
        }
    } else {
        if ($hasCreatedAt && $hasUpdatedAt) {
            $ins = $pdo->prepare("INSERT INTO exam_question_videos (exam_id, branch_id, question_no, video_path, created_at, updated_at) VALUES (?,?,?,?,NOW(),NOW())");
            $ins->execute([$exam_id, $branch_id, $question_no, $relPath]);
        } elseif ($hasCreatedAt && !$hasUpdatedAt) {
            $ins = $pdo->prepare("INSERT INTO exam_question_videos (exam_id, branch_id, question_no, video_path, created_at) VALUES (?,?,?,?,NOW())");
            $ins->execute([$exam_id, $branch_id, $question_no, $relPath]);
        } elseif (!$hasCreatedAt && $hasUpdatedAt) {
            $ins = $pdo->prepare("INSERT INTO exam_question_videos (exam_id, branch_id, question_no, video_path, updated_at) VALUES (?,?,?,?,NOW())");
            $ins->execute([$exam_id, $branch_id, $question_no, $relPath]);
        } else {
            $ins = $pdo->prepare("INSERT INTO exam_question_videos (exam_id, branch_id, question_no, video_path) VALUES (?,?,?,?)");
            $ins->execute([$exam_id, $branch_id, $question_no, $relPath]);
        }
    }

    $pdo->commit();
    
    log_security_event('upload_success', 'Video uploaded successfully', [
        'exam_id' => $exam_id,
        'branch_id' => $branch_id,
        'question_no' => $question_no,
        'filename' => $safeFile
    ]);
    
} catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    // Başarısız upload dosyasını temizle
    if (file_exists($targetPath)) {
        @unlink($targetPath);
    }
    jerr('DB kaydı hatası: ' . $e->getMessage());
}

// Base URL config.php'de var
$url = rtrim($base_url, '/') . '/' . $relPath;

echo json_encode(['success' => true, 'url' => $url, 'path' => $relPath], JSON_UNESCAPED_UNICODE);
exit;
