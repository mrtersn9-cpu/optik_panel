<?php
require_once __DIR__ . '/../config.php';
require_login();

// CSRF kontrolü
require_csrf_api();


header('Content-Type: application/json; charset=utf-8');

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Geçersiz istek.']);
    exit;
}

$exam_id    = isset($_POST['exam_id']) ? (int)$_POST['exam_id'] : 0;
$branch_id  = isset($_POST['branch_id']) ? (int)$_POST['branch_id'] : 0;
$question_no= isset($_POST['question_no']) ? (int)$_POST['question_no'] : 0;

if ($exam_id <= 0 || $branch_id <= 0 || $question_no <= 0) {
    echo json_encode(['success' => false, 'message' => 'Eksik parametre.']);
    exit;
}

try {
    // Kaydı bul
    $st = $pdo->prepare("SELECT id, video_path FROM exam_question_videos WHERE exam_id=? AND branch_id=? AND question_no=? LIMIT 1");
    $st->execute([$exam_id, $branch_id, $question_no]);
    $row = $st->fetch(PDO::FETCH_ASSOC);

    if (!$row) {
        echo json_encode(['success' => false, 'message' => 'Video kaydı bulunamadı.']);
        exit;
    }

    $videoPath = (string)$row['video_path'];

    // Dosya güvenli silme (uploads kökü dışına çıkmayı engelle)
    $uploadsRoot = realpath(__DIR__ . '/../uploads');
    $absFile = realpath(__DIR__ . '/../' . ltrim($videoPath, '/'));

    if ($uploadsRoot && $absFile && strpos($absFile, $uploadsRoot) === 0 && is_file($absFile)) {
        @unlink($absFile);
    }

    // DB kaydını sil
    $del = $pdo->prepare("DELETE FROM exam_question_videos WHERE id = ?");
    $del->execute([(int)$row['id']]);

    echo json_encode(['success' => true, 'message' => 'Video silindi.']);
    exit;

} catch (Throwable $e) {
    echo json_encode(['success' => false, 'message' => 'Silme hatası: ' . $e->getMessage()]);
    exit;
}
