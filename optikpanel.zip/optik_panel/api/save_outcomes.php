<?php
require_once __DIR__ . '/../config.php';

require_login();

// CSRF kontrolü
require_csrf_api();

$isAjax = (
    (isset($_POST['ajax']) && (string)$_POST['ajax'] === '1') ||
    (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower((string)$_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest')
);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    if ($isAjax) {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['success' => false, 'message' => 'Geçersiz istek.']);
        exit;
    }
    header('Location: exams.php');
    exit;
}

$exam_id = (int)($_POST['exam_id'] ?? 0);
if ($exam_id <= 0) {
    if ($isAjax) {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['success' => false, 'message' => 'Geçersiz deneme ID.']);
        exit;
    }
    die('Geçersiz deneme ID');
}

// Formdan gelen diziler
$branch_ids       = $_POST['branch_id']       ?? [];
$alt_branch_names = $_POST['alt_branch_name'] ?? [];
$outcome_names    = $_POST['outcome_name']    ?? [];
$outcome_codes    = $_POST['outcome_code']    ?? [];

// İlgili denemeye ait kitapçıklar
$stmt = $pdo->prepare("SELECT * FROM exam_booklets WHERE exam_id = ? ORDER BY id ASC");
$stmt->execute([$exam_id]);
$booklets = $stmt->fetchAll();

if (!$booklets) {
    if ($isAjax) {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['success' => false, 'message' => 'Bu deneme için kitapçık tanımlanmamış.']);
        exit;
    }
    die('Bu deneme için kitapçık tanımlanmamış.');
}

$pdo->beginTransaction();
try {
    $rowCount = count($branch_ids);
    $inserted = 0;
    $skipped = 0;

    for ($i = 0; $i < $rowCount; $i++) {
        $branch_id       = (int)($branch_ids[$i] ?? 0);
        $alt_branch_name = trim($alt_branch_names[$i] ?? '');
        $name            = trim($outcome_names[$i] ?? '');
        $code            = trim($outcome_codes[$i] ?? '');

        // Boş satırları atla (branş yoksa veya kazanım adı/kodu boşsa kayıt alma)
        if ($branch_id <= 0 || $name === '' || $code === '') {
            $skipped++;
            continue;
        }

        // Mantıksal soru no: istersen sıraya göre kullanıyoruz
        $logical = $i + 1;

        // Outcome kaydı
        $stmtIns = $pdo->prepare("
            INSERT INTO exam_outcomes (exam_id, branch_id, alt_branch_name, logical_question_no, outcome_name, outcome_code)
            VALUES (?, ?, ?, ?, ?, ?)
        ");
        $stmtIns->execute([
            $exam_id,
            $branch_id,
            $alt_branch_name,
            $logical,
            $name,
            $code
        ]);

        $outcome_id = (int)$pdo->lastInsertId();
        $inserted++;

        // Her kitapçık için: soru no + cevap
        foreach ($booklets as $b) {
            $fieldQ = 'booklet_' . $b['id'] . '_qno';
            $fieldA = 'booklet_' . $b['id'] . '_ans';

            $qArr = $_POST[$fieldQ] ?? [];
            $aArr = $_POST[$fieldA] ?? [];

            $qno = (int)($qArr[$i] ?? 0);
            $ans = strtoupper(trim($aArr[$i] ?? ''));

            // Hiç soru girilmediyse o kitapçık için kayıt alma
            if ($qno <= 0 && $ans === '') {
                continue;
            }

            // Cevap harfini A–E dışında bırakma (güvenlik için)
            if (!in_array($ans, ['A','B','C','D','E'], true)) {
                $ans = null;
            }

            $stmtMap = $pdo->prepare("
                INSERT INTO exam_outcome_booklet_map (outcome_id, booklet_id, question_no, answer_option)
                VALUES (?, ?, ?, ?)
            ");
            $stmtMap->execute([
                $outcome_id,
                $b['id'],
                $qno,
                $ans
            ]);
        }
    }

    $pdo->commit();
    if ($isAjax) {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode([
            'success' => true,
            'message' => 'Kazanımlar kaydedildi.',
            'inserted' => $inserted,
            'skipped' => $skipped
        ]);
        exit;
    }
    header('Location: exam_detail.php?id=' . $exam_id);
    exit;
} catch (Exception $e) {
    $pdo->rollBack();
    if ($isAjax) {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['success' => false, 'message' => 'Kayıt sırasında hata: ' . $e->getMessage()]);
        exit;
    }
    die('Kayıt sırasında hata oluştu: ' . $e->getMessage());
}
