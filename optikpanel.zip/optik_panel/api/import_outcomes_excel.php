<?php
require_once __DIR__ . '/../config.php';
require_login();

// CSRF kontrolü
require_csrf_api();

require_once __DIR__ . '/./../../vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\IOFactory;

$isAjax = (
    (isset($_POST['ajax']) && (string)$_POST['ajax'] === '1') ||
    (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower((string)$_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest')
);

function json_out($arr) {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($arr, JSON_UNESCAPED_UNICODE);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    if ($isAjax) json_out(['success' => false, 'message' => 'Geçersiz istek.']);
    header('Location: exams.php');
    exit;
}

$exam_id = (int)($_POST['exam_id'] ?? 0);
if ($exam_id <= 0) {
    if ($isAjax) json_out(['success' => false, 'message' => 'Geçersiz deneme ID.']);
    die('Geçersiz deneme ID');
}

if (empty($_FILES['excel_file']['tmp_name'])) {
    if ($isAjax) json_out(['success' => false, 'message' => 'Herhangi bir dosya yüklenmedi.']);
    die('Herhangi bir dosya yüklenmedi.');
}

// Kitapçıklar
$stmt = $pdo->prepare("SELECT * FROM exam_booklets WHERE exam_id = ? ORDER BY id ASC");
$stmt->execute([$exam_id]);
$booklets = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (!$booklets) {
    if ($isAjax) json_out(['success' => false, 'message' => 'Bu deneme için kitapçık tanımlanmamış.']);
    die('Bu deneme için kitapçık tanımlanmamış.');
}

// Branşlar (isim → id map) + LIMIT (question_count)
$stmt = $pdo->prepare("SELECT id, name, question_count FROM exam_branches WHERE exam_id = ?");
$stmt->execute([$exam_id]);
$branches = $stmt->fetchAll(PDO::FETCH_ASSOC);

$branchMap = [];        // lower(name) => id
$branchLimits = [];     // id => question_count
$branchNamesById = [];  // id => name

foreach ($branches as $br) {
    $bid = (int)$br['id'];
    $bname = (string)$br['name'];
    $branchMap[trim(mb_strtolower($bname, 'UTF-8'))] = $bid;
    $branchLimits[$bid] = max(0, (int)$br['question_count']); // limit = question_count
    $branchNamesById[$bid] = $bname;
}

$tmpPath = $_FILES['excel_file']['tmp_name'];

try {
    $spreadsheet = IOFactory::load($tmpPath);
    $sheet = $spreadsheet->getActiveSheet();
    $highestRow = (int)$sheet->getHighestRow();

    $pdo->beginTransaction();

    // Mevcut kazanım sayıları (branş bazlı) -> import sırasında limit aşımını doğru saymak için
    $existingCounts = [];
    try {
        $stmt = $pdo->prepare("
            SELECT branch_id, COUNT(*) AS cnt
            FROM exam_outcomes
            WHERE exam_id = ?
            GROUP BY branch_id
        ");
        $stmt->execute([$exam_id]);
        while ($r = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $existingCounts[(int)$r['branch_id']] = (int)$r['cnt'];
        }
    } catch (Exception $e) {
        // exam_outcomes tablosu yoksa vs. yine de devam edelim (ama bu projede var)
        $existingCounts = [];
    }

    $logicalCounter = 0;
    $inserted = 0;
    $skipped = 0;
    $unknownBranch = 0;

    // Limit aşımları
    $overLimit = 0;
    $overLimitByBranch = []; // id => count
    $overLimitRows = [];     // örnek satırlar (çok uzamasın diye)

    // Import sırasında branş başına eklenenleri say
    $addedCounts = []; // id => added in this import

    // Hazır statement'lar
    $stmtIns = $pdo->prepare("
        INSERT INTO exam_outcomes (exam_id, branch_id, alt_branch_name, logical_question_no, outcome_name, outcome_code)
        VALUES (?, ?, ?, ?, ?, ?)
    ");
    $stmtMap = $pdo->prepare("
        INSERT INTO exam_outcome_booklet_map (outcome_id, booklet_id, question_no, answer_option)
        VALUES (?, ?, ?, ?)
    ");

    for ($row = 2; $row <= $highestRow; $row++) {
        $branchName    = trim((string)$sheet->getCell('A' . $row)->getValue());
        $altBranchName = trim((string)$sheet->getCell('B' . $row)->getValue());
        $outcomeName   = trim((string)$sheet->getCell('C' . $row)->getValue());
        $outcomeCode   = trim((string)$sheet->getCell('D' . $row)->getValue());

        if ($branchName === '' && $outcomeName === '' && $outcomeCode === '') {
            continue; // tamamen boş satır
        }

        $branchKey = trim(mb_strtolower($branchName, 'UTF-8'));
        $branch_id = (int)($branchMap[$branchKey] ?? 0);

        if ($branch_id <= 0) {
            $unknownBranch++;
            continue;
        }

        if ($outcomeName === '' || $outcomeCode === '') {
            $skipped++;
            continue;
        }

        // ===== LIMIT KONTROLÜ (branş başına question_count kadar kazanım) =====
        $limit = (int)($branchLimits[$branch_id] ?? 0);

        // limit 0 ise (tanımsız gibi) istersen sınırsız kabul edebilirdik,
        // ama senin senaryoda limit 0 olmasın; 0 ise yine de engelleyelim.
        $currentExisting = (int)($existingCounts[$branch_id] ?? 0);
        $currentAdded    = (int)($addedCounts[$branch_id] ?? 0);
        $currentTotal    = $currentExisting + $currentAdded;

        if ($limit > 0 && $currentTotal >= $limit) {
            $overLimit++;
            $overLimitByBranch[$branch_id] = (int)($overLimitByBranch[$branch_id] ?? 0) + 1;

            // Örnek birkaç satırı kaydedelim (response şişmesin)
            if (count($overLimitRows) < 8) {
                $overLimitRows[] = [
                    'row' => $row,
                    'branch' => $branchNamesById[$branch_id] ?? $branchName,
                    'limit' => $limit,
                    'current' => $currentTotal,
                    'outcome_code' => $outcomeCode
                ];
            }
            continue;
        }

        // logical_question_no: import edilen sıraya göre
        $logicalCounter++;
        $logical = $logicalCounter;

        // Outcome insert
        $stmtIns->execute([
            $exam_id,
            $branch_id,
            $altBranchName,
            $logical,
            $outcomeName,
            $outcomeCode
        ]);

        $outcome_id = (int)$pdo->lastInsertId();
        $inserted++;

        // Branş bazlı eklenen sayıyı artır
        $addedCounts[$branch_id] = (int)($addedCounts[$branch_id] ?? 0) + 1;

        // Kitapçık kolonları: E sütunundan itibaren (Q + A)
        $colOrd = ord('E');

        foreach ($booklets as $b) {
            $qCol = chr($colOrd);
            $aCol = chr($colOrd + 1);

            $qVal = $sheet->getCell($qCol . $row)->getCalculatedValue();
            $aVal = $sheet->getCell($aCol . $row)->getValue();

            $qno = (int)$qVal;
            $ans = strtoupper(trim((string)$aVal));

            if ($qno <= 0 && $ans === '') {
                $colOrd += 2;
                continue;
            }

            if (!in_array($ans, ['A', 'B', 'C', 'D', 'E'], true)) {
                $ans = null;
            }

            $stmtMap->execute([
                $outcome_id,
                (int)$b['id'],
                $qno,
                $ans
            ]);

            $colOrd += 2;
        }
    }

    $pdo->commit();

    // Limit aşımlarını “okunur” bir metne çevir (frontend SweetAlert için)
    $overLimitSummary = [];
    if (!empty($overLimitByBranch)) {
        foreach ($overLimitByBranch as $bid => $cnt) {
            $bname = $branchNamesById[(int)$bid] ?? ('Branş #' . (int)$bid);
            $lim = (int)($branchLimits[(int)$bid] ?? 0);
            $overLimitSummary[] = $bname . " (limit: " . $lim . ", aşılan: " . (int)$cnt . ")";
        }
    }

    if ($isAjax) {
        json_out([
            'success' => true,
            'message' => 'Excel kazanımları yüklendi.',
            'inserted' => $inserted,
            'skipped' => $skipped,
            'unknown_branch' => $unknownBranch,
            'over_limit' => $overLimit,
            'over_limit_summary' => $overLimitSummary,   // dizi (frontend istersen join ile gösterebilir)
            'over_limit_rows' => $overLimitRows          // örnek satırlar
        ]);
    }

    header('Location: exam_detail.php?id=' . $exam_id);
    exit;

} catch (Exception $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();

    if ($isAjax) {
        json_out(['success' => false, 'message' => 'Excel okuma sırasında hata: ' . $e->getMessage()]);
    }
    die('Excel okuma sırasında hata oluştu: ' . $e->getMessage());
}
