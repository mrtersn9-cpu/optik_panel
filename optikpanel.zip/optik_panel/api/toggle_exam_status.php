<?php
require_once __DIR__ . '/../config.php';
require_login();
require_csrf_api();

header('Content-Type: application/json; charset=utf-8');

function jerr(string $msg): void {
    echo json_encode(['success' => false, 'message' => $msg], JSON_UNESCAPED_UNICODE);
    exit;
}

$exam_id = (int)($_POST['exam_id'] ?? 0);
$is_active = isset($_POST['is_active']) ? (int)$_POST['is_active'] : 0;

if ($exam_id <= 0) {
    jerr('Geçersiz deneme ID.');
}

// is_active sadece 0 veya 1 olabilir
$is_active = $is_active ? 1 : 0;

try {
    $stmt = $pdo->prepare("UPDATE exams SET is_active = ? WHERE id = ?");
    $stmt->execute([$is_active, $exam_id]);
    
    if ($stmt->rowCount() === 0) {
        jerr('Deneme bulunamadı veya değişiklik yapılamadı.');
    }
    
    if (function_exists('log_security_event')) {
        log_security_event('exam_status_changed', 'Exam status changed', [
            'exam_id' => $exam_id,
            'is_active' => $is_active
        ]);
    }
    
    echo json_encode([
        'success' => true,
        'is_active' => $is_active,
        'message' => $is_active ? 'Deneme aktif edildi' : 'Deneme pasif edildi'
    ], JSON_UNESCAPED_UNICODE);
    
} catch (Throwable $e) {
    jerr('DB hatası: ' . $e->getMessage());
}
