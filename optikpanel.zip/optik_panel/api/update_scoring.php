<?php
require_once __DIR__ . '/../config.php';

require_login();

// CSRF kontrolü
require_csrf_api();


$isAjax = (
    (isset($_POST['ajax']) && (string)$_POST['ajax'] === '1') ||
    (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower((string)$_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest')
);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    if ($isAjax) {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['success' => false, 'message' => 'Geçersiz istek.']);
        exit;
    }
    header('Location: /optik_panel/exams.php');
    exit;
}

$examId   = isset($_POST['exam_id']) ? (int)$_POST['exam_id'] : 0;
$useNeg   = isset($_POST['use_negative_scoring']) ? 1 : 0;
$wrongPer = isset($_POST['wrong_per_minus']) ? (int)$_POST['wrong_per_minus'] : 4;

if ($examId <= 0) {
    if ($isAjax) {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['success' => false, 'message' => 'Geçersiz deneme ID.']);
        exit;
    }
    die('Geçersiz deneme ID');
}

if ($wrongPer <= 0) $wrongPer = 4;

try {
    $stmt = $pdo->prepare('UPDATE exams SET use_negative_scoring = ?, wrong_per_minus = ? WHERE id = ?');
    $stmt->execute([$useNeg, $wrongPer, $examId]);

    if ($isAjax) {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['success' => true, 'message' => 'Net ayarı kaydedildi.']);
        exit;
    }

    header('Location: /optik_panel/exam_detail.php?id=' . $examId . '&scoring_updated=1');
    exit;
} catch (Exception $e) {
    if ($isAjax) {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['success' => false, 'message' => 'Hata: ' . $e->getMessage()]);
        exit;
    }
    die('Hata: ' . $e->getMessage());
}
