<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
require_once __DIR__ . '/../config.php';
require_login();
require_once __DIR__ . '/./../../vendor/autoload.php'; // PhpSpreadsheet

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

$exam_id = isset($_GET['exam_id']) ? (int)$_GET['exam_id'] : 0;
if ($exam_id <= 0) {
    die('Geçersiz deneme ID');
}

// Deneme var mı kontrol
$stmt = $pdo->prepare("SELECT * FROM exams WHERE id = ?");
$stmt->execute([$exam_id]);
$exam = $stmt->fetch();
if (!$exam) {
    die('Deneme bulunamadı.');
}

// Kitapçıklar
$stmt = $pdo->prepare("SELECT * FROM exam_booklets WHERE exam_id = ? ORDER BY id ASC");
$stmt->execute([$exam_id]);
$booklets = $stmt->fetchAll();

$spreadsheet = new Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();

// Başlıklar
$sheet->setCellValue('A1', 'Branş');
$sheet->setCellValue('B1', 'Alt Branş');
$sheet->setCellValue('C1', 'Kazanım Adı');
$sheet->setCellValue('D1', 'Kazanım Kodu');

$colOrd = ord('E');
foreach ($booklets as $b) {
    $qCol = chr($colOrd);
    $aCol = chr($colOrd + 1);

    $sheet->setCellValue($qCol . '1', 'Kitapçık ' . $b['code'] . ' Soru No');
    $sheet->setCellValue($aCol . '1', 'Kitapçık ' . $b['code'] . ' Cevap (A-E)');

    $colOrd += 2;
}

// Basit bir örnek satır (istersen boş da bırakabilirsin)
$sheet->setCellValue('A2', 'Sosyal Bilgiler');
$sheet->setCellValue('B2', 'Tarih');
$sheet->setCellValue('C2', 'İnkılap Tarihi');
$sheet->setCellValue('D2', 'SB-TAR-01');

$filename = 'kazanım_sablon_deneme_' . $exam_id . '.xlsx';

header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Cache-Control: max-age=0');

$writer = new Xlsx($spreadsheet);
$writer->save('php://output');
exit;
