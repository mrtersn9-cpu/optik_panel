<?php
require_once __DIR__ . '/../config.php';
require_login();
require_csrf_api();

header('Content-Type: application/json; charset=utf-8');

function jerr(string $msg): void {
    echo json_encode(['success' => false, 'message' => $msg], JSON_UNESCAPED_UNICODE);
    exit;
}

$exam_id = (int)($_POST['exam_id'] ?? 0);
$branch_id = (int)($_POST['branch_id'] ?? 0);
$question_no = (int)($_POST['question_no'] ?? 0);
$video_link = trim((string)($_POST['video_link'] ?? ''));

if ($exam_id <= 0 || $branch_id <= 0 || $question_no <= 0) {
    jerr('Eksik parametre.');
}

if ($video_link === '') {
    jerr('Link boş olamaz.');
}

// Link validasyonu (temel)
if (!filter_var($video_link, FILTER_VALIDATE_URL)) {
    jerr('Geçersiz URL formatı.');
}

// Sadece güvenli protokollere izin ver
$parsed = parse_url($video_link);
if (!isset($parsed['scheme']) || !in_array($parsed['scheme'], ['http', 'https'])) {
    jerr('Sadece HTTP/HTTPS linkleri kabul edilir.');
}

// Tabloda hangi kolonlar var kontrol et
function column_exists($pdo, $table, $column) {
    try {
        $stmt = $pdo->prepare("SHOW COLUMNS FROM `{$table}` LIKE ?");
        $stmt->execute([$column]);
        return $stmt->rowCount() > 0;
    } catch (Throwable $e) {
        return false;
    }
}

$hasCreatedAt = column_exists($pdo, 'exam_question_videos', 'created_at');
$hasUpdatedAt = column_exists($pdo, 'exam_question_videos', 'updated_at');

try {
    $pdo->beginTransaction();
    
    // Önce var mı kontrol et
    $stmt = $pdo->prepare("SELECT id FROM exam_question_videos WHERE exam_id=? AND branch_id=? AND question_no=? LIMIT 1");
    $stmt->execute([$exam_id, $branch_id, $question_no]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($row) {
        // Güncelle
        if ($hasUpdatedAt) {
            $upd = $pdo->prepare("UPDATE exam_question_videos SET video_link=?, video_path=NULL, updated_at=NOW() WHERE id=?");
        } else {
            $upd = $pdo->prepare("UPDATE exam_question_videos SET video_link=?, video_path=NULL WHERE id=?");
        }
        $upd->execute([$video_link, (int)$row['id']]);
    } else {
        // Yeni ekle
        if ($hasCreatedAt && $hasUpdatedAt) {
            $ins = $pdo->prepare("INSERT INTO exam_question_videos (exam_id, branch_id, question_no, video_link, created_at, updated_at) VALUES (?,?,?,?,NOW(),NOW())");
        } elseif ($hasCreatedAt) {
            $ins = $pdo->prepare("INSERT INTO exam_question_videos (exam_id, branch_id, question_no, video_link, created_at) VALUES (?,?,?,?,NOW())");
        } elseif ($hasUpdatedAt) {
            $ins = $pdo->prepare("INSERT INTO exam_question_videos (exam_id, branch_id, question_no, video_link, updated_at) VALUES (?,?,?,?,NOW())");
        } else {
            $ins = $pdo->prepare("INSERT INTO exam_question_videos (exam_id, branch_id, question_no, video_link) VALUES (?,?,?,?)");
        }
        $ins->execute([$exam_id, $branch_id, $question_no, $video_link]);
    }
    
    $pdo->commit();
    
    if (function_exists('log_security_event')) {
        log_security_event('video_link_saved', 'Video link saved', [
            'exam_id' => $exam_id,
            'branch_id' => $branch_id,
            'question_no' => $question_no,
            'link' => $video_link
        ]);
    }
    
    echo json_encode([
        'success' => true,
        'url' => $video_link,
        'message' => 'Link kaydedildi'
    ], JSON_UNESCAPED_UNICODE);
    
} catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    jerr('DB hatası: ' . $e->getMessage());
}
