<?php
require_once __DIR__ . '/config.php';
include __DIR__ . '/admin_header.php';

// ----------------- Yardımcı -----------------
function h($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

// Basit flash (opsiyonel)
if (session_status() === PHP_SESSION_NONE) session_start();
$flash_error = $_SESSION['flash_error'] ?? '';
unset($_SESSION['flash_error']);

// ----------------- İşlemler -----------------

// Aktiflik değiştirme
if (isset($_GET['toggle']) && ctype_digit($_GET['toggle'] ?? '')) {
    $id = (int)$_GET['toggle'];
    $stmt = $pdo->prepare("UPDATE exams SET is_active = 1 - is_active WHERE id = ?");
    $stmt->execute([$id]);
    header('Location: exams.php');
    exit;
}

if (
    $_SERVER['REQUEST_METHOD'] === 'POST' &&
    isset($_POST['action']) && $_POST['action'] === 'delete_exam'
) {
    $id = isset($_POST['exam_id']) ? (int)$_POST['exam_id'] : 0;
    $rawPass = (string)($_POST['panel_password'] ?? '');
    $rawPass = trim($rawPass);

    if ($id <= 0) {
        $_SESSION['flash_error'] = 'Geçersiz deneme ID.';
        header('Location: exams.php');
        exit;
    }

    if ($rawPass === '' || substr($rawPass, -1) !== '-') {
        $_SESSION['flash_error'] = 'Panel şifresi "-" ile bitmelidir. Örn: sifre-';
        header('Location: exams.php');
        exit;
    }

    $panelPass = substr($rawPass, 0, -1);

    $ok = false;

    if (function_exists('verify_admin_password')) {
        $ok = (bool)verify_admin_password($panelPass);
    } elseif (defined('ADMIN_PASSWORD')) {
        $ok = hash_equals((string)ADMIN_PASSWORD, $panelPass);
    } elseif (isset($ADMIN_PASSWORD)) {
        $ok = hash_equals((string)$ADMIN_PASSWORD, $panelPass);
    } else {
        $ok = false;
    }

    if (!$ok) {
        $_SESSION['flash_error'] = 'Panel şifresi hatalı. Silme işlemi iptal edildi.';
        header('Location: exams.php');
        exit;
    }

    $stmt = $pdo->prepare("DELETE FROM exams WHERE id = ?");
    $stmt->execute([$id]);

    header('Location: exams.php?deleted=1');
    exit;
}


// Denemeleri listele
$stmt = $pdo->query("SELECT * FROM exams ORDER BY created_at DESC");
$exams = $stmt->fetchAll();
?>

<h2>Denemeler</h2>

<div class="text-right mb-2">
    <a href="exam_add.php" class="btn-add-exam">+ Yeni Deneme Ekle</a>
</div>

<!-- DataTables CSS -->
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.8/css/jquery.dataTables.min.css">

<style>
/* --- Modern Tablo Tasarımı --- */
#exams-table_wrapper {
    background: #ffffff;
    padding: 20px;
    border-radius: 12px;
    box-shadow: 0 4px 16px rgba(0,0,0,0.08);
    margin-top: 10px;
}
#exams-table {
    border-collapse: separate !important;
    border-spacing: 0 8px !important;
    width: 100%;
}
#exams-table thead tr th {
    background: #1f4e79;
    color: #fff !important;
    border: none !important;
    padding: 12px;
    font-size: 14px;
}
#exams-table thead tr th:first-child { border-top-left-radius: 10px; }
#exams-table thead tr th:last-child  { border-top-right-radius: 10px; }

#exams-table tbody tr { background: #f9f9f9; }
#exams-table tbody tr td {
    padding: 14px 12px !important;
    border: none !important;
    font-size: 14px;
    border-top: 1px solid #e0e0e0 !important;
    border-bottom: 1px solid #e0e0e0 !important;
}
#exams-table tbody tr:hover { background: #eef4fb !important; }

.dataTables_filter { margin-bottom: 10px; }
.dataTables_filter input {
    padding: 8px 10px !important;
    border-radius: 6px;
    border: 1px solid #ccc;
}
.dataTables_length select {
    padding: 6px 10px;
    border-radius: 6px;
    border: 1px solid #ccc;
}
.dataTables_info { font-size: 12px; color: #555; }
.dataTables_paginate a { font-size: 12px; }

/* Rozetler */
.badge-success {
    background: #4caf50 !important;
    color: #fff;
    padding: 4px 10px;
    border-radius: 20px;
    font-size: 12px;
}
.badge-danger {
    background: #f44336 !important;
    color: #fff;
    padding: 4px 10px;
    border-radius: 20px;
    font-size: 12px;
}

/* Modern butonlar */
.btn-modern {
    padding: 6px 10px !important;
    border-radius: 6px;
    border: none;
    cursor: pointer;
    font-size: 12px;
    transition: 0.2s;
    text-decoration: none;
    display: inline-block;
    margin-right: 6px;
}
.btn-modern:hover { opacity: 0.85; }

/* Yeni Deneme Ekle butonu */
.btn-add-exam {
    display: inline-block;
    padding: 10px 18px;
    border-radius: 999px;
    background: linear-gradient(135deg, #1f4e79, #3f7cc9);
    color: #fff;
    font-size: 13px;
    font-weight: 600;
    text-decoration: none;
    box-shadow: 0 3px 10px rgba(0,0,0,0.15);
    transition: all 0.2s ease;
}
.btn-add-exam:hover {
    transform: translateY(-1px);
    box-shadow: 0 5px 14px rgba(0,0,0,0.20);
    opacity: 0.95;
}
</style>

<table id="exams-table" class="display nowrap">
    <thead>
        <tr>
            <th>ID</th>
            <th>Deneme Adı</th>
            <th>Deneme No</th>
            <th>Barkod</th>
            <th>Durum</th>
            <th>Oluşturma Tarihi</th>
            <th>İşlemler</th>
        </tr>
    </thead>
    <tbody>
        <?php if (!empty($exams)): ?>
            <?php foreach ($exams as $exam): ?>
                <tr>
                    <td><?= h($exam['id']) ?></td>
                    <td><?= h($exam['name']) ?></td>
                    <td><?= h($exam['exam_number']) ?></td>
                    <td><?= h($exam['barcode']) ?></td>
                    <td>
                        <?php if (!empty($exam['is_active'])): ?>
                            <span class="badge-success">Aktif</span>
                        <?php else: ?>
                            <span class="badge-danger">Pasif</span>
                        <?php endif; ?>
                    </td>
                    <td><?= h($exam['created_at']) ?></td>
                    <td>
                        <!-- ✅ YENİ: DÜZENLE -->
                        <a class="btn-modern" style="background:#2563eb; color:#fff;"
                           href="exam_edit.php?id=<?= (int)$exam['id'] ?>">Düzenle</a>

                        <a class="btn-modern" style="background:#607d8b; color:#fff;"
                           href="exam_detail.php?id=<?= (int)$exam['id'] ?>">Detay</a>

                        <a class="btn-modern"
                           style="background:<?= !empty($exam['is_active']) ? '#c62828' : '#2e7d32' ?>; color:#fff;"
                           href="exams.php?toggle=<?= (int)$exam['id'] ?>">
                            <?= !empty($exam['is_active']) ? 'Pasif Yap' : 'Aktif Yap' ?>
                        </a>

                        <a class="btn-modern btn-delete-exam"
                           style="background:#111827; color:#fff;"
                           href="#"
                           data-exam-id="<?= (int)$exam['id'] ?>"
                           data-exam-name="<?= h($exam['name']) ?>">
                            Sil
                        </a>
                    </td>
                </tr>
            <?php endforeach; ?>
        <?php endif; ?>
    </tbody>
</table>

<!-- Silme için POST formu -->
<form id="deleteExamForm" method="post" action="exams.php" style="display:none;">
    <input type="hidden" name="action" value="delete_exam">
    <input type="hidden" name="exam_id" id="delete_exam_id" value="">
    <input type="hidden" name="panel_password" id="delete_panel_password" value="">
</form>

<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<!-- DataTables JS -->
<script src="https://cdn.datatables.net/1.13.8/js/jquery.dataTables.min.js"></script>
<!-- SweetAlert2 -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
$(function() {
    // DataTables: JS alert hatalarını kapat (mesaj çıkmasın)
    $.fn.dataTable.ext.errMode = 'none';

    // MOBİL RESPONSIVE: CSS'e dokunmadan tabloyu yatay kaydırılabilir bir wrapper'a sar
    if (!$('#exams-table').parent().hasClass('dt-xwrap')) {
        $('#exams-table').wrap('<div class="dt-xwrap" style="width:100%;overflow-x:auto;-webkit-overflow-scrolling:touch;"></div>');
    }

    // Datatable
    if (!$.fn.DataTable.isDataTable('#exams-table')) {
        $('#exams-table').DataTable({
            language: {
                url: 'https://cdn.datatables.net/plug-ins/1.13.8/i18n/tr.json',
                emptyTable: "Henüz deneme eklenmemiş.",
                zeroRecords: "Kayıt bulunamadı."
            },
            order: [[0, 'desc']],
            pageLength: 100,
            scrollX: true,
            autoWidth: false
        });
    }

    // URL paramlarıyla toast
    const params = new URLSearchParams(window.location.search);
    if (params.get('deleted') === '1') {
        Swal.fire({
            toast: true, position: 'top-end', icon: 'success',
            title: 'Deneme silindi', showConfirmButton: false,
            timer: 2200, timerProgressBar: true
        });
    }

    // PHP flash error
    <?php if (!empty($flash_error)): ?>
    Swal.fire({
        icon: 'error',
        title: 'Hata',
        text: <?= json_encode($flash_error, JSON_UNESCAPED_UNICODE) ?>
    });
    <?php endif; ?>

    // Silme popup + panel şifresi iste
    $(document).on('click', '.btn-delete-exam', async function(e) {
        e.preventDefault();

        const examId = $(this).data('exam-id');
        const name   = $(this).data('exam-name') || 'Bu deneme';

        const first = await Swal.fire({
            title: 'Emin misiniz?',
            html: '<b>' + name + '</b> denemesini silmek üzeresiniz.<br>Bu işlem geri alınamaz.',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Devam et',
            cancelButtonText: 'Vazgeç',
            reverseButtons: true,
            didOpen: () => {
                const popup = Swal.getPopup();
                if (popup) {
                    popup.style.maxWidth = 'calc(100vw - 24px)';
                    popup.style.boxSizing = 'border-box';
                }
            }
        });

        if (!first.isConfirmed) return;

        const passAsk = await Swal.fire({
            title: 'Panel Şifresi',
            input: 'password',
            inputLabel: 'Silme işlemini onaylamak için panel şifresini girin',
            inputPlaceholder: '************',
            inputAttributes: { autocapitalize: 'off', autocorrect: 'off' },
            showCancelButton: true,
            confirmButtonText: 'Sil',
            cancelButtonText: 'Vazgeç',
            reverseButtons: true,
            didOpen: () => {
                const popup = Swal.getPopup();
                const input = Swal.getInput();
                if (popup) {
                    popup.style.maxWidth = 'calc(100vw - 24px)';
                    popup.style.boxSizing = 'border-box';
                }
                if (input) {
                    input.style.width = '90%';
                    input.style.maxWidth = '100%';
                    input.style.boxSizing = 'border-box';
                    input.style.marginLeft = '0';
                    input.style.marginRight = '0';
                    input.style.margin = '5%';
                }
            },
            preConfirm: (val) => {
                const v = String(val || '').trim();
                if (!v) {
                    Swal.showValidationMessage('Şifre boş olamaz.');
                    return false;
                }
                if (!v.endsWith('-')) {
                    Swal.showValidationMessage('Girdiğiniz Şifre Hatalı');
                    return false;
                }
                return v;
            }
        });

        if (!passAsk.isConfirmed) return;

        $('#delete_exam_id').val(examId);
        $('#delete_panel_password').val(passAsk.value);
        $('#deleteExamForm')[0].submit();
    });
});
</script>

<?php include __DIR__ . '/admin_footer.php'; ?>
