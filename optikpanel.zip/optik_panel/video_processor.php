<?php
/**
 * Video Compression Module
 * FFmpeg tabanlı video optimizasyonu
 */

class VideoProcessor {
    
    private $ffmpegPath;
    private $ffprobePath;
    
    public function __construct() {
        // FFmpeg yolu (sistemde kurulu olmalı)
        $this->ffmpegPath = '/usr/bin/ffmpeg';
        $this->ffprobePath = '/usr/bin/ffprobe';
        
        // FFmpeg kurulu mu kontrol et
        if (!file_exists($this->ffmpegPath)) {
            throw new Exception('FFmpeg bulunamadı. Lütfen önce FFmpeg kurun: sudo apt install ffmpeg');
        }
    }
    
    /**
     * Video'yu sıkıştır
     * 
     * @param string $inputPath Input video path
     * @param string $outputPath Output video path
     * @param array $options ['quality' => 'low|medium|high', 'target_percentage' => 50-90]
     * @return array ['success' => bool, 'original_size' => int, 'compressed_size' => int, ...]
     */
    public function compressVideo(string $inputPath, string $outputPath, array $options = []): array {
        
        if (!file_exists($inputPath)) {
            return ['success' => false, 'error' => 'Input file not found'];
        }
        
        $originalSize = filesize($inputPath);
        $quality = $options['quality'] ?? 'medium';
        $targetPercentage = $options['target_percentage'] ?? 80;
        
        try {
            // Kalite ayarlarını al
            $settings = $this->getQualitySettings($quality, $targetPercentage);
            
            // FFmpeg komutunu oluştur
            $command = $this->buildFFmpegCommand($inputPath, $outputPath, $settings);
            
            // Komutu çalıştır
            $output = [];
            $returnCode = 0;
            exec($command . ' 2>&1', $output, $returnCode);
            
            if ($returnCode !== 0) {
                return [
                    'success' => false,
                    'error' => 'FFmpeg error: ' . implode("\n", $output)
                ];
            }
            
            // Dosya oluştu mu kontrol et
            if (!file_exists($outputPath)) {
                return ['success' => false, 'error' => 'Output file not created'];
            }
            
            // Sonuç hesaplama
            $compressedSize = filesize($outputPath);
            $savedPercentage = round((($originalSize - $compressedSize) / $originalSize) * 100, 2);
            
            return [
                'success' => true,
                'original_size' => $originalSize,
                'compressed_size' => $compressedSize,
                'saved_percentage' => $savedPercentage,
                'original_mb' => round($originalSize / 1024 / 1024, 2),
                'compressed_mb' => round($compressedSize / 1024 / 1024, 2)
            ];
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }
    
    /**
     * Kalite ayarlarını hesapla
     */
    private function getQualitySettings(string $quality, int $targetPercentage): array {
        // Base ayarlar
        $baseSettings = [
            'low' => [
                'width' => 640,
                'height' => 480,
                'bitrate' => 500,  // kbps
                'preset' => 'fast'
            ],
            'medium' => [
                'width' => 1280,
                'height' => 720,
                'bitrate' => 1000,
                'preset' => 'medium'
            ],
            'high' => [
                'width' => 1920,
                'height' => 1080,
                'bitrate' => 2000,
                'preset' => 'slow'
            ]
        ];
        
        $settings = $baseSettings[$quality] ?? $baseSettings['medium'];
        
        // Target percentage'e göre bitrate'i ayarla
        // %50 = daha yüksek bitrate, %90 = daha düşük bitrate
        $bitrateMultiplier = 1 - ($targetPercentage / 100) + 0.2; // 0.7 - 0.6
        $settings['bitrate'] = (int)($settings['bitrate'] * $bitrateMultiplier);
        
        return $settings;
    }
    
    /**
     * FFmpeg komutunu oluştur
     */
    private function buildFFmpegCommand(string $input, string $output, array $settings): string {
        $cmd = escapeshellcmd($this->ffmpegPath);
        $input = escapeshellarg($input);
        $output = escapeshellarg($output);
        
        // Komut parçaları
        $parts = [
            $cmd,
            '-i', $input,
            '-c:v', 'libx264',                                    // Video codec
            '-b:v', $settings['bitrate'] . 'k',                   // Video bitrate
            '-vf', "scale={$settings['width']}:{$settings['height']}", // Çözünürlük
            '-preset', $settings['preset'],                       // Encoding hızı
            '-crf', '23',                                         // Kalite (18-28 arası, düşük=iyi)
            '-c:a', 'aac',                                        // Audio codec
            '-b:a', '128k',                                       // Audio bitrate
            '-ar', '44100',                                       // Audio sample rate
            '-ac', '2',                                           // Audio channels (stereo)
            '-movflags', '+faststart',                            // Web streaming için optimize
            '-y',                                                 // Overwrite output
            $output
        ];
        
        return implode(' ', $parts);
    }
    
    /**
     * Video bilgilerini al (FFprobe ile)
     */
    public function getVideoInfo(string $path): array {
        if (!file_exists($path)) {
            return ['error' => 'File not found'];
        }
        
        $cmd = escapeshellcmd($this->ffprobePath);
        $path = escapeshellarg($path);
        
        $command = "$cmd -v quiet -print_format json -show_format -show_streams $path";
        
        $output = shell_exec($command);
        
        if (!$output) {
            return ['error' => 'Could not read video info'];
        }
        
        $data = json_decode($output, true);
        
        if (!$data) {
            return ['error' => 'Invalid video data'];
        }
        
        return [
            'duration' => (float)($data['format']['duration'] ?? 0),
            'size' => (int)($data['format']['size'] ?? 0),
            'bitrate' => (int)($data['format']['bit_rate'] ?? 0),
            'format' => $data['format']['format_name'] ?? 'unknown'
        ];
    }
    
    /**
     * FFmpeg kurulu mu kontrol et
     */
    public static function isFFmpegAvailable(): bool {
        $output = shell_exec('which ffmpeg 2>/dev/null');
        return !empty(trim($output));
    }
}
