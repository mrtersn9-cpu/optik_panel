<?php
require_once __DIR__ . '/config.php';
header('Location: ' . (is_logged_in() ? 'exams.php' : 'login.php'));
exit;
