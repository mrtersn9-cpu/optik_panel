<?php
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Pragma: no-cache");
header("Expires: 0");
// Config ve bağımlılıklar
require_once __DIR__ . '/optik_panel/config.php';

// Business logic
require_once __DIR__ . '/includes/exam_logic.php';
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title><?php echo h($exam['name']); ?> - Optik İşaretleme</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <base href="<?php echo rtrim($base_url, '/'); ?>/">
    
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="assets/css/exam_view.css?v=<?= filemtime(__DIR__ . '/assets/css/exam_view.css') ?>">
</head>
<body>

<!-- Cihaz bazlı tekrar uyarısı (Bootstrap Modal) -->
<div class="modal fade" id="repeatModal" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content" style="border-radius:16px; overflow:hidden;">
      <div class="modal-header" style="border-bottom:1px solid #eef2ff;">
        <h5 class="modal-title" style="font-weight:700;">Bu deneme bu cihazda daha önce çözüldü</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Kapat">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <p class="mb-2">İsterseniz önceki sonucu görüntüleyebilir veya optiği sıfırdan doldurabilirsiniz.</p>
        <small class="text-muted">Not: Yeni optik doldur seçerseniz, bu cihaz için kaydedilmiş eski sonuçlar silinir ve yeniden değerlendirme yapılır.</small>
      </div>
      <div class="modal-footer" style="border-top:1px solid #eef2ff;">
        <button type="button" class="btn btn-light" data-dismiss="modal">Vazgeç</button>
        <button type="button" id="btnShowPrev" class="btn btn-primary">Önceki Sonucu Göster</button>
        <button type="button" id="btnResetAttempt" class="btn btn-warning">Yeni Optik Doldur</button>
      </div>
    </div>
  </div>
</div>

<div class="exam-container">

    <!-- ÜST KART -->
    <div class="exam-card mb-4">
        <div class="d-flex justify-content-between align-items-center flex-wrap">
            <div>
                <div class="exam-title"><?php echo h($exam['name']); ?></div>

                <?php if ($isInactive): ?>
                    <div class="mt-2 text-danger font-weight-bold">
                       Optik form şu anda kullanılamıyor.
                    </div>
                <?php endif; ?>
            </div>
            <?php if ($booklets): ?>
                <div class="mt-md-0 text-right">
                    <span class="exam-sub">Kitapçık Seçimi:</span>
                    <span class="badge badge-primary ml-1">
                        <?php echo h($selectedBookletCode); ?>
                    </span>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <?php if ($isInactive): ?>

        <!-- Pasif deneme uyarısı -->
         <div class="exam-card">
           <p class="mb-0">
             Bu deneme şu anda yayında olmadığı için optik formu dolduramazsınız.
             Detaylı bilgi ve destek için
             <strong>sonucyayinlari@gmail.com</strong> adresinden bizimle iletişime geçebilirsiniz.
           </p>
         </div>


    <?php elseif ($results): ?>

        <?php if ($isPrevView): ?>
            <div class="alert alert-info" style="border-radius:12px;">
                <div class="d-flex justify-content-between align-items-center flex-wrap">
                    <div>
                        <strong>Önceki sonuç görüntüleniyor.</strong>
                        Bu cihazda daha önce çözülen denemenin kaydedilmiş sonucunu görüyorsunuz.
                    </div>
                    <button type="button" id="btnResetFromPrev" class="btn btn-warning mt-2 mt-md-0">Yeni Optik Doldur</button>
                </div>
            </div>
        <?php endif; ?>

        <!-- SONUÇ BÖLÜMÜ -->
        <div id="result-section">
            <?php require __DIR__ . '/views/partials/results_summary.php'; ?>
            <?php require __DIR__ . '/views/partials/results_branch.php'; ?>
            <?php require __DIR__ . '/views/partials/results_outcomes.php'; ?>
            <?php require __DIR__ . '/views/partials/results_topics.php'; ?>
            <?php require __DIR__ . '/views/partials/results_review.php'; ?>
        </div>

        <div class="text-right mb-4">
            <a href="<?php echo $_SERVER['PHP_SELF'] . '?id=' . $exam_id_encoded; ?>" class="btn btn-primary ml-2">
                Yeniden İşaretle
            </a>
        </div>

    <?php else: ?>
        <?php require __DIR__ . '/views/partials/optik_form.php'; ?>
    <?php endif; ?>
</div>

<div id="videoBackdrop" class="video-modal-backdrop" onclick="closeVideoSolution()"></div>
<div id="videoModal" class="video-modal" role="dialog" aria-modal="true" aria-hidden="true">
    <div class="video-modal-header">
        <div class="video-modal-title">Video Çözüm</div>
        <button type="button" class="video-modal-close" onclick="closeVideoSolution()">Kapat</button>
    </div>
    <div class="video-modal-body">
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>

<script>
window.EXAM_VIEW_CONFIG = {
    isResultsPage: <?php echo $results ? 'true' : 'false'; ?>,
    isPrevView: <?php echo $isPrevView ? 'true' : 'false'; ?>
};
</script>
<script src="assets/js/exam_view.js?vt=<?= filemtime(__DIR__ . '/assets/js/exam_view.js') ?>"></script>
</body>
</html>
