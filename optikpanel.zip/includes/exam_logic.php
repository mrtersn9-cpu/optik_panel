<?php
/**
 * Exam View Logic
 * Business mantığını içeren include dosyası
 */

// Yardımcı fonksiyon
function h($s) {
    return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
}

// Models ve Services
require_once __DIR__ . '/../models/ExamAttempt.php';
require_once __DIR__ . '/../services/ExamService.php';

// Service instance'ları
$examService = new ExamService($pdo);
$attemptModel = new ExamAttempt($pdo);

// QR'dan sınav ID'sini çöz
$exam_id_encoded = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$exam_id = $examService->decodeExamId($exam_id_encoded);

if ($exam_id <= 0) {
  ?>
  <!doctype html>
  <html lang="tr">
  <head>
    <meta charset="utf-8">
    <title>Geçersiz Sınav Bağlantısı</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 4 -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">

    <style>
      .exam-alert-wrapper{
        min-height: 100vh;
        display: flex;
        align-items: center;
        justify-content: center;
        background: #f8fafc;
        padding: 16px;
      }
      .exam-alert-card{
        max-width: 420px;
        width: 100%;
        border-radius: 14px;
        border: 1px solid #fecaca;
        background: #fff;
        box-shadow: 0 10px 25px rgba(0,0,0,.08);
      }
      .exam-alert-header{
        background: #fee2e2;
        color: #7f1d1d;
        font-weight: 700;
        padding: 14px 16px;
        border-bottom: 1px solid #fecaca;
        border-radius: 14px 14px 0 0;
        display: flex;
        align-items: center;
        gap: 10px;
      }
      .exam-alert-body{
        padding: 16px;
        color: #374151;
        font-size: 14px;
      }
      .exam-alert-actions{
        padding: 0 16px 16px;
      }
    </style>
  </head>
  <body>

  <div class="exam-alert-wrapper">
    <div class="exam-alert-card">

      <div class="exam-alert-header">
        ⚠️ Geçersiz Sınav Bağlantısı
      </div>

      <div class="exam-alert-body">
        Girdiğiniz bağlantı geçerli bir sınavı işaret etmiyor.<br>
        Bağlantı eksik, hatalı veya süresi dolmuş olabilir.
      </div>

      <div class="exam-alert-actions">
      </div>

    </div>
  </div>

  </body>
  </html>
  <?php
  exit;
}


// Cihaz ID
$device_id = '';
if (isset($_POST['device_id'])) {
    $device_id = trim((string)$_POST['device_id']);
}
if ($device_id === '' && isset($_GET['device_id'])) {
    $device_id = trim((string)$_GET['device_id']);
}
$device_id = preg_replace('/[^a-zA-Z0-9_-]/', '', $device_id);

// API istekleri için include
if (isset($_GET['api'])) {
    require __DIR__ . '/../api/exam_attempt_api.php';
    exit;
}

// Sınav bilgilerini çek
$exam = $examService->getExam($exam_id);
if (!$exam) {
  ?>
  <!doctype html>
  <html lang="tr">
  <head>
    <meta charset="utf-8">
    <title>Deneme Bulunamadı</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 4 -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">

    <style>
      .exam-alert-wrapper{
        min-height: 100vh;
        display: flex;
        align-items: center;
        justify-content: center;
        background: #f8fafc;
        padding: 16px;
      }
      .exam-alert-card{
        max-width: 420px;
        width: 100%;
        border-radius: 14px;
        border: 1px solid #fecaca;
        background: #fff;
        box-shadow: 0 10px 25px rgba(0,0,0,.08);
      }
      .exam-alert-header{
        background: #fee2e2;
        color: #7f1d1d;
        font-weight: 700;
        padding: 14px 16px;
        border-bottom: 1px solid #fecaca;
        border-radius: 14px 14px 0 0;
        display: flex;
        align-items: center;
        gap: 10px;
      }
      .exam-alert-body{
        padding: 16px;
        color: #374151;
        font-size: 14px;
      }
      .exam-alert-actions{
        padding: 0 16px 16px;
        display: flex;
        gap: 10px;
      }
    </style>
  </head>
  <body>

  <div class="exam-alert-wrapper">
    <div class="exam-alert-card">

      <div class="exam-alert-header">
        ❌ Deneme Bulunamadı
      </div>

      <div class="exam-alert-body">
        Girmiş olduğunuz bağlantıya ait tanımlı bir deneme bulunamadı.<br>
        Bağlantı hatalı olabilir ya da deneme yayından kaldırılmış olabilir.
      </div>

      <div class="exam-alert-actions">

      </div>

    </div>
  </div>

  </body>
  </html>
  <?php
  exit;
}


$isInactive = empty($exam['is_active']);
$useNegativeScoring = isset($exam['use_negative_scoring']) 
    ? (int)$exam['use_negative_scoring'] : 1;
$wrongPerMinus = isset($exam['wrong_per_minus']) && (int)$exam['wrong_per_minus'] > 0
    ? (int)$exam['wrong_per_minus'] : 4;

// Branşlar, Kitapçıklar, Video
$branches = $examService->getBranches($exam_id);
$booklets = $examService->getBooklets($exam_id);
$video_by_branch_q = $examService->getVideoSolutions($exam_id, $base_url);

// Kazanımlar
$outcomes = $examService->getOutcomes($exam_id);
$outcomeInfo = [];
foreach ($outcomes as $o) {
    $outcomeInfo[$o['id']] = $o;
}

// Kitapçık map
$bookletByCode = [];
foreach ($booklets as $b) {
    $bookletByCode[$b['code']] = $b;
}

// Cevap anahtarı ve kazanım eşlemesi
list($answerKey, $outcomeByQuestion) = $examService->prepareAnswerKeyAndOutcomes(
    $exam_id, 
    $booklets, 
    $outcomes
);

// Kitapçık seçimi
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $selectedBookletCode = isset($_POST['booklet_code']) 
        ? trim($_POST['booklet_code']) : null;
} else {
    $selectedBookletCode = !empty($booklets) ? $booklets[0]['code'] : null;
}

// Sonuç değişkenleri
$results  = null;
$errorMsg = null;
$chartLabels = $chartCorrect = $chartWrong = $chartBlank = $chartNet = [];
$isPrevView = false;

// Önceki sonucu göster
if (isset($_GET['show_prev']) && (string)$_GET['show_prev'] === '1' && $device_id !== '') {
    $row = $attemptModel->findByDevice($exam_id, $device_id);
    
    if ($row && !empty($row['results_json'])) {
        $decoded = json_decode((string)$row['results_json'], true);
        
        if (is_array($decoded)) {
            $savedResults = $decoded['results'] ?? $decoded;
            
            if (is_array($savedResults)) {
                $results = $savedResults;
                $selectedBookletCode = (string)($results['bookletCode'] ?? $selectedBookletCode);
                $isPrevView = true;

                // Grafik verilerini yeniden üret
                if (!empty($results['branchStats']) && is_array($results['branchStats'])) {
                    foreach ($results['branchStats'] as $bs) {
                        $chartLabels[]  = (string)($bs['name'] ?? '');
                        $chartCorrect[] = (int)($bs['correct'] ?? 0);
                        $chartWrong[]   = (int)($bs['wrong'] ?? 0);
                        $chartBlank[]   = (int)($bs['blank'] ?? 0);
                        $chartNet[]     = (float)($bs['net'] ?? 0);
                    }
                }
            }
        }
    } else {
        $errorMsg = "Bu cihaz için kayıtlı önceki sonuç bulunamadı.";
    }
}

// Yeni değerlendirme
if (!$isPrevView && !$isInactive && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_exam'])) {
    if (!$selectedBookletCode || !isset($bookletByCode[$selectedBookletCode])) {
        $errorMsg = "Lütfen kitapçık seçiniz.";
    } else {
        // Sonuç hesaplama
        $results = $examService->calculateResults(
            $exam,
            $branches,
            $_POST,
            $selectedBookletCode,
            $answerKey,
            $outcomeByQuestion,
            $outcomeInfo
        );

        // Cihaz bazlı kayıt
        if ($results['anyAnswered'] && $device_id !== '') {
            $answersPayload = [
                'bookletCode' => $selectedBookletCode,
                'answers'     => $results['questionReview'],
            ];
            
            $resultsPayload = [
                'computed_at' => date('c'),
                'results'     => $results,
            ];

            try {
                $attemptModel->save(
                    $exam_id, 
                    $device_id, 
                    $selectedBookletCode, 
                    $answersPayload, 
                    $resultsPayload,
                    client_ip_address()
                );
            } catch (Exception $e) {
                // sessiz geç
            }
        }

        // Log
        if ($results['anyAnswered'] && function_exists('log_exam_view_completed')) {
            log_exam_view_completed($exam_id);
        }
    }
}
