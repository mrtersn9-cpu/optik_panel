<?php
/**
 * Exam Attempt API
 * Cihaz bazlı deneme kontrol ve sıfırlama API'si
 */

require_once __DIR__ . '/../optik_panel/config.php';
require_once __DIR__ . '/../models/ExamAttempt.php';
require_once __DIR__ . '/../services/ExamService.php';

header('Content-Type: application/json; charset=utf-8');

// GET parametreleri
$api = isset($_GET['api']) ? (string)$_GET['api'] : '';
$exam_id_encoded = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$device_id = isset($_GET['device_id']) ? trim((string)$_GET['device_id']) : '';

// QR decode
$examService = new ExamService($pdo);
$exam_id = $examService->decodeExamId($exam_id_encoded);

if ($exam_id <= 0) {
    echo json_encode(['ok' => false, 'error' => 'Geçersiz sınav ID'], JSON_UNESCAPED_UNICODE);
    exit;
}

// Device ID sanitize
$device_id = preg_replace('/[^a-zA-Z0-9_-]/', '', $device_id);

if ($device_id === '') {
    echo json_encode(['ok' => false, 'error' => 'Geçersiz cihaz ID'], JSON_UNESCAPED_UNICODE);
    exit;
}

// Model
$attemptModel = new ExamAttempt($pdo);

// API Routes
switch ($api) {
    case 'check_attempt':
        $row = $attemptModel->findByDevice($exam_id, $device_id);
        $completed = false;
        $has = false;
        
        if ($row) {
            $has = true;
            $completed = !empty($row['results_json']);
        }
        
        echo json_encode([
            'ok'        => true,
            'exists'    => $has,
            'completed' => $completed,
            'updatedAt' => $row['updated_at'] ?? null,
        ], JSON_UNESCAPED_UNICODE);
        break;
        
    case 'reset_attempt':
        $ok = $attemptModel->reset($exam_id, $device_id, client_ip_address());
        echo json_encode(['ok' => (bool)$ok], JSON_UNESCAPED_UNICODE);
        break;
        
    default:
        echo json_encode(['ok' => false, 'error' => 'Bilinmeyen istek'], JSON_UNESCAPED_UNICODE);
}

exit;
