/**
 * Optik Panel - Exam View JavaScript
 * Cihaz bazlı takip, modal yönetimi ve form validasyonu
 */

document.addEventListener('DOMContentLoaded', function () {
  // Config
  var IS_RESULTS_PAGE = (window.EXAM_VIEW_CONFIG && window.EXAM_VIEW_CONFIG.isResultsPage) || false;
  var IS_PREV_VIEW = (window.EXAM_VIEW_CONFIG && window.EXAM_VIEW_CONFIG.isPrevView) || false;

  /**
   * Cihaz ID oluştur/getir
   */
  function getOrCreateDeviceId() {
    try {
      var key = 'optik_device_id';
      var existing = localStorage.getItem(key);
      if (existing && /^[a-zA-Z0-9_-]{8,}$/.test(existing)) {
        return existing;
      }

      var arr = new Uint8Array(16);
      (window.crypto || window.msCrypto).getRandomValues(arr);
      var hex = Array.from(arr).map(function (b) {
        return ('00' + b.toString(16)).slice(-2);
      }).join('');

      localStorage.setItem(key, hex);
      return hex;
    } catch (e) {
      // localStorage kapalıysa: yine de bir oturum id'si üret
      return 'anon_' + Math.random().toString(36).slice(2);
    }
  }

  var deviceId = getOrCreateDeviceId();

  /**
   * Tüm POST formlarına device_id ekle
   */
  document.querySelectorAll('form[method="post"]').forEach(function (f) {
    var inp = f.querySelector('input[name="device_id"]');
    if (!inp) {
      inp = document.createElement('input');
      inp.type = 'hidden';
      inp.name = 'device_id';
      f.appendChild(inp);
    }
    inp.value = deviceId;
  });

  /**
   * Form validasyonu
   */
  var form = document.getElementById('exam-form');
  if (form) {
    form.addEventListener('submit', function (e) {
      var checked = form.querySelector('input[type="radio"]:checked');
      if (!checked) {
        var ok = confirm('Hiç işaretleme yapmadınız. Sınavı boş geçmek istediğinize emin misiniz?');
        if (!ok) e.preventDefault();
      }
    });
  }

  /**
   * Önceki deneme kontrolü
   */
  if (!IS_RESULTS_PAGE && !IS_PREV_VIEW) {
    checkPreviousAttempt();
  }

  function checkPreviousAttempt() {
    try {
      var u = new URL(window.location.href);
      u.searchParams.set('api', 'check_attempt');
      u.searchParams.set('device_id', deviceId);

      fetch(u.toString(), { credentials: 'same-origin' })
        .then(function (r) { return r.json(); })
        .then(function (data) {
          if (data && data.ok && data.completed) {
            showRepeatModal();
          }
        })
        .catch(function () { /* sessiz */ });
    } catch (e) {
      // sessiz
    }
  }

  /**
   * Tekrar modal göster
   */
  function showRepeatModal() {
    if (window.jQuery && jQuery.fn && typeof jQuery.fn.modal === 'function') {
      jQuery('#repeatModal').modal('show');
    } else {
      // Fallback: basit confirm
      var goPrev = confirm('Bu deneme bu cihazda daha önce çözüldü. Önceki sonucu görmek ister misiniz?');
      if (goPrev) {
        var up = new URL(window.location.href);
        up.searchParams.set('show_prev', '1');
        up.searchParams.set('device_id', deviceId);
        window.location.href = up.toString();
      }
    }
  }

  /**
   * Modal buton event'leri
   */
  var btnPrev = document.getElementById('btnShowPrev');
  if (btnPrev) {
    btnPrev.addEventListener('click', function () {
      var up = new URL(window.location.href);
      up.searchParams.set('show_prev', '1');
      up.searchParams.set('device_id', deviceId);
      window.location.href = up.toString();
    });
  }

  var btnReset = document.getElementById('btnResetAttempt');
  if (btnReset) {
    btnReset.addEventListener('click', function () {
      resetAttemptAndReload();
    });
  }

  var btnResetPrev = document.getElementById('btnResetFromPrev');
  if (btnResetPrev) {
    btnResetPrev.addEventListener('click', function () {
      resetAttemptAndReload();
    });
  }

  /**
   * Denemeyi sıfırla ve yeniden yükle
   */
  function resetAttemptAndReload() {
    try {
      var u = new URL(window.location.href);
      u.searchParams.set('api', 'reset_attempt');
      u.searchParams.set('device_id', deviceId);

      fetch(u.toString(), { method: 'POST', credentials: 'same-origin' })
        .then(function (r) { return r.json(); })
        .then(function () { reloadWithoutPrev(); })
        .catch(function () { reloadWithoutPrev(); });
    } catch (e) {
      window.location.reload();
    }
  }

  function reloadWithoutPrev() {
    var base = new URL(window.location.href);
    base.searchParams.delete('show_prev');
    base.searchParams.set('device_id', deviceId);
    window.location.href = base.toString();
  }
});

/**
 * PDF Export (iframe print)
 */
function printInIframe(html, addPageBreak) {
  var iframe = document.createElement('iframe');
  iframe.style.position = 'fixed';
  iframe.style.right = '0';
  iframe.style.bottom = '0';
  iframe.style.width = '0';
  iframe.style.height = '0';
  iframe.style.border = '0';
  document.body.appendChild(iframe);

  var doc = iframe.contentWindow || iframe.contentDocument;
  if (doc.document) doc = doc.document;

  var headHtml = document.querySelector('head').innerHTML;
  var extraStyle = addPageBreak
    ? '<style>@media print { .results-card { page-break-after: always; } }</style>'
    : '';

  doc.open();
  doc.write('<html><head>' + headHtml + extraStyle + '</head><body>' + html + '</body></html>');
  doc.close();

  iframe.onload = function () {
    iframe.contentWindow.focus();
    iframe.contentWindow.print();
    setTimeout(function () {
      document.body.removeChild(iframe);
    }, 1000);
  };
}

function downloadPDF() {
    var section = document.getElementById('result-section');
    if (!section) return;
    printInIframe(section.innerHTML, true);
}

/**
 * Video çözüm modal - TÜM PLATFORMLARI DESTEKLER
 * Desteklenen platformlar:
 * - Google Drive
 * - YouTube (youtube.com, youtu.be)
 * - Vimeo
 * - Dailymotion
 * - Doğrudan video dosyaları (mp4, webm, ogg)
 */
function openVideoSolution(url) {
  var backdrop = document.getElementById('videoBackdrop');
  var modal = document.getElementById('videoModal');
  var modalBody = document.querySelector('.video-modal-body');

  if (!backdrop || !modal || !modalBody) return;

  // Önceki içeriği temizle
  modalBody.innerHTML = '';

  // Video türünü tespit et
  var isGoogleDrive = url.indexOf('drive.google.com') > -1;
  var isYouTube = url.indexOf('youtube.com') > -1 || url.indexOf('youtu.be') > -1;
  var isVimeo = url.indexOf('vimeo.com') > -1;
  var isDailymotion = url.indexOf('dailymotion.com') > -1 || url.indexOf('dai.ly') > -1;

  var iframe = document.createElement('iframe');
  iframe.style.width = '100%';
  iframe.style.height = '500px';
  iframe.style.border = 'none';
  iframe.style.borderRadius = '12px';
  iframe.setAttribute('allowfullscreen', 'true');
  iframe.setAttribute('allow', 'accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture');

  if (isGoogleDrive) {
    // Google Drive embed URL'sine çevir
    var embedUrl = url;
    if (url.indexOf('/file/d/') > -1) {
      var fileId = url.match(/\/file\/d\/([^/]+)/);
      if (fileId && fileId[1]) {
        embedUrl = 'https://drive.google.com/file/d/' + fileId[1] + '/preview';
      }
    } else if (url.indexOf('/view') > -1 && url.indexOf('/preview') === -1) {
      embedUrl = url.replace('/view', '/preview');
    }
    iframe.src = embedUrl;
    modalBody.appendChild(iframe);

  } else if (isYouTube) {
    // YouTube embed URL'sine çevir
    var videoId = '';
    
    if (url.indexOf('youtu.be/') > -1) {
      // Kısa link: youtu.be/VIDEO_ID
      videoId = url.split('youtu.be/')[1].split('?')[0].split('&')[0];
    } else if (url.indexOf('youtube.com/watch?v=') > -1) {
      // Normal link: youtube.com/watch?v=VIDEO_ID
      videoId = url.split('v=')[1].split('&')[0];
    } else if (url.indexOf('youtube.com/embed/') > -1) {
      // Zaten embed linki
      iframe.src = url;
      modalBody.appendChild(iframe);
      backdrop.style.display = 'block';
      modal.style.display = 'block';
      modal.setAttribute('aria-hidden', 'false');
      return;
    }

    if (videoId) {
      iframe.src = 'https://www.youtube.com/embed/' + videoId + '?autoplay=1&rel=0';
      modalBody.appendChild(iframe);
    } else {
      modalBody.innerHTML = '<div class="alert alert-danger m-3">YouTube video ID bulunamadı.</div>';
    }

  } else if (isVimeo) {
    // Vimeo embed URL'sine çevir
    var vimeoId = url.match(/vimeo\.com\/(\d+)/);
    if (vimeoId && vimeoId[1]) {
      iframe.src = 'https://player.vimeo.com/video/' + vimeoId[1] + '?autoplay=1';
      modalBody.appendChild(iframe);
    } else {
      modalBody.innerHTML = '<div class="alert alert-danger m-3">Vimeo video ID bulunamadı.</div>';
    }

  } else if (isDailymotion) {
    // Dailymotion embed URL'sine çevir
    var dmId = '';
    if (url.indexOf('dai.ly/') > -1) {
      dmId = url.split('dai.ly/')[1].split('?')[0];
    } else {
      var match = url.match(/dailymotion\.com\/video\/([^_?]+)/);
      if (match && match[1]) dmId = match[1];
    }
    
    if (dmId) {
      iframe.src = 'https://www.dailymotion.com/embed/video/' + dmId + '?autoplay=1';
      modalBody.appendChild(iframe);
    } else {
      modalBody.innerHTML = '<div class="alert alert-danger m-3">Dailymotion video ID bulunamadı.</div>';
    }

  } else {
    // Doğrudan video dosyası (mp4, webm, ogg vb.)
    var video = document.createElement('video');
    video.id = 'videoPlayer';
    video.controls = true;
    video.playsinline = true;
    video.autoplay = true;
    video.src = url;
    video.style.width = '100%';
    video.style.height = 'auto';
    video.style.borderRadius = '12px';
    video.style.background = '#000';
    modalBody.appendChild(video);

    video.addEventListener('error', function() {
      modalBody.innerHTML = '<div class="alert alert-danger m-3">Video yüklenemedi. Dosya yolu kontrol edin: <br><small>' + url + '</small></div>';
    });

    video.addEventListener('loadeddata', function () {
      try { video.play(); } catch (e) {}
    });
  }

  backdrop.style.display = 'block';
  modal.style.display = 'block';
  modal.setAttribute('aria-hidden', 'false');
}

function closeVideoSolution() {
  var backdrop = document.getElementById('videoBackdrop');
  var modal = document.getElementById('videoModal');
  var modalBody = document.querySelector('.video-modal-body');

  if (modalBody) {
    modalBody.innerHTML = '';
  }

  if (backdrop) {
    backdrop.style.display = 'none';
  }

  if (modal) {
    modal.style.display = 'none';
    modal.setAttribute('aria-hidden', 'true');
  }
}

// ESC tuşu ile video kapat
document.addEventListener('keydown', function (e) {
  if (e.key === 'Escape') {
    closeVideoSolution();
  }
});
