<?php
/**
 * ExamAttempt Model
 * Cihaz bazlı deneme kayıtlarını yönetir
 */

declare(strict_types=1);

class ExamAttempt
{
    private PDO $pdo;

    public function __construct(PDO $pdo)
    {
        $this->pdo = $pdo;
    }

    /**
     * Cihaz bazlı deneme bulma
     */
    public function findByDevice(int $examId, string $deviceId): ?array
    {
        if ($examId <= 0 || $deviceId === '') {
            return null;
        }
        
        $stmt = $this->pdo->prepare(
            "SELECT * FROM exam_attempts 
             WHERE exam_id = ? AND device_id = ? 
             ORDER BY id DESC LIMIT 1"
        );
        $stmt->execute([$examId, $deviceId]);
        $row = $stmt->fetch();
        
        return $row ?: null;
    }

    /**
     * Deneme sıfırlama
     */
    public function reset(int $examId, string $deviceId, string $ipAddress): bool
    {
        if ($examId <= 0 || $deviceId === '') {
            return false;
        }
        
        $existing = $this->findByDevice($examId, $deviceId);
        
        if ($existing) {
            $stmt = $this->pdo->prepare(
                "UPDATE exam_attempts 
                 SET booklet_code = NULL, answers_json = NULL, 
                     results_json = NULL, ip_address = ? 
                 WHERE id = ?"
            );
            return $stmt->execute([$ipAddress, (int)$existing['id']]);
        }
        
        $stmt = $this->pdo->prepare(
            "INSERT INTO exam_attempts 
             (exam_id, device_id, ip_address, booklet_code, answers_json, results_json) 
             VALUES (?, ?, ?, NULL, NULL, NULL)"
        );
        return $stmt->execute([$examId, $deviceId, $ipAddress]);
    }

    /**
     * Deneme kaydetme/güncelleme
     */
    public function save(
        int $examId, 
        string $deviceId, 
        ?string $bookletCode, 
        array $answersPayload, 
        array $resultsPayload,
        string $ipAddress
    ): bool {
        if ($examId <= 0 || $deviceId === '') {
            return false;
        }
        
        $answersJson = json_encode($answersPayload, JSON_UNESCAPED_UNICODE);
        $resultsJson = json_encode($resultsPayload, JSON_UNESCAPED_UNICODE);
        
        $existing = $this->findByDevice($examId, $deviceId);
        
        if ($existing) {
            $stmt = $this->pdo->prepare(
                "UPDATE exam_attempts 
                 SET ip_address = ?, booklet_code = ?, 
                     answers_json = ?, results_json = ? 
                 WHERE id = ?"
            );
            return $stmt->execute([
                $ipAddress, 
                $bookletCode, 
                $answersJson, 
                $resultsJson, 
                (int)$existing['id']
            ]);
        }
        
        $stmt = $this->pdo->prepare(
            "INSERT INTO exam_attempts 
             (exam_id, device_id, ip_address, booklet_code, answers_json, results_json) 
             VALUES (?, ?, ?, ?, ?, ?)"
        );
        return $stmt->execute([
            $examId, 
            $deviceId, 
            $ipAddress, 
            $bookletCode, 
            $answersJson, 
            $resultsJson
        ]);
    }

    /**
     * Tamamlandı mı kontrolü
     */
    public function isCompleted(int $examId, string $deviceId): bool
    {
        $attempt = $this->findByDevice($examId, $deviceId);
        return $attempt && !empty($attempt['results_json']);
    }
}
